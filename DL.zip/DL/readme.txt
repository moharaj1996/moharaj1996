This file accompanies DataLoad Classic and DataLoad Professional.

The 'help' directory contains a large number of HTML files and these make up the User Guide.
Open index.htm in any browser to view the User Guide or press F1 from within DataLoad.

The full license and terms and conditions for DataLoad Classic and Professional are set out
in the file license.htm, which is supplied with the help files and can also be viewed on the DataLoad web site.
Please read and understand the license before using DataLoad.

The latest version of DataLoad can always be downloaded from the following web site:

	http://www.dataload.com

DataLoad is Copyright JD Stuart Ltd, 1998-2010. All rights reserved.


