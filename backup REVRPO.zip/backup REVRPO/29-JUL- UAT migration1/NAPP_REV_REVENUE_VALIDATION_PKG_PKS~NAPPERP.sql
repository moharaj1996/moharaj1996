CREATE OR REPLACE PACKAGE napperp.napp_rev_revenue_validation_pkg AS
/*
|====================================================================================================================|
|               NetApp Inc. Sunnyvale California                                                                     |
|====================================================================================================================|
|                                                                                                                    |
|    File Name   : NAPP_REV_REVENUE_VALIDATION_PKG.pks                                                               |
|    Object Name : NAPP_REV_REVENUE_VALIDATION_PKG                                                                   |
|                                                                                                                    |
|    Description : Package used for validating the data in the STAGING table and UPDATE the PROCESSED_FLAG as Y or F |
|    Revision History:                                                                                               |
|                                                                                                                    |
|  Ver  Date          Modified By         Revision Description                                                       |
|  ===  ============  ==============      ========================--=================================================|
|  1.0  22-JUL-2024   Shreepathi Bhat     JIRA# CO-XXX Initial Development                                           |
|====================================================================================================================|*/
   PROCEDURE napp_rev_revenue_log_err_proc (
      p_module_name              IN       VARCHAR2
     ,p_pkg_name                 IN       VARCHAR2
     ,p_prc_name                 IN       VARCHAR2
     ,p_entity_name              IN       VARCHAR2
     ,p_entity_id                IN       VARCHAR2
     ,p_msg_typ                  IN       VARCHAR2
     ,p_msg_txt                  IN       VARCHAR2);

   PROCEDURE napp_rev_revenue_validate_proc (
      p_integration_instance_id  IN       VARCHAR2 DEFAULT NULL
     ,p_err_status               OUT      VARCHAR2
     ,p_err_msg                  OUT      VARCHAR2);

   PROCEDURE napp_insert_group_id_proc (
      p_integration_instance_id  IN       VARCHAR2 DEFAULT NULL
     ,p_err_status               OUT      VARCHAR2
     ,p_err_msg                  OUT      VARCHAR2);

   PROCEDURE napp_insert_reserve_code_proc (
      p_integration_instance_id  IN       VARCHAR2 DEFAULT NULL
     ,p_err_status               OUT      VARCHAR2
     ,p_err_msg                  OUT      VARCHAR2);
END napp_rev_revenue_validation_pkg;
/
