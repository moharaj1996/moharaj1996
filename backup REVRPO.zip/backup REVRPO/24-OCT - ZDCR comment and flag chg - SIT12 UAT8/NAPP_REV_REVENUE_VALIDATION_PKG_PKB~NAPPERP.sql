create or replace PACKAGE BODY  NAPPERP.NAPP_REV_REVENUE_VALIDATION_PKG AS
/*
|====================================================================================================================|
|               NetApp Inc. Sunnyvale California                                                                     |
|====================================================================================================================|
|                                                                                                                    |
|    File Name   : NAPP_REV_REVENUE_VALIDATION_PKG.pkb                                                                       |
|    Object Name : NAPP_REV_REVENUE_VALIDATION_PKG                                                                           |
|                                                                                                                    |
|    Description : Package used for validating the data in the STAGING table and UPDATE the PROCESSED_FLAG as Y or F |
|    Revision History:                                                                                               |
|                                                                                                                    |
|  Ver  Date          Modified By         Revision Description                                                       |
|  ===  ============  ==============      ===========================================================================|
|  1.0  22-JUL-2024   Shreepathi Bhat     JIRA# CO-XXX Initial Development                                           |
|====================================================================================================================|*/
   PROCEDURE napp_rev_revenue_log_err_proc (
      p_module_name              IN       VARCHAR2
     ,p_pkg_name                 IN       VARCHAR2
     ,p_prc_name                 IN       VARCHAR2
     ,p_entity_name              IN       VARCHAR2
     ,p_entity_id                IN       VARCHAR2
     ,p_msg_typ                  IN       VARCHAR2
     ,p_msg_txt                  IN       VARCHAR2) IS
/*
|====================================================================================================================|
This procedure will be called to insert the log and error messages
|====================================================================================================================|*/
      PRAGMA AUTONOMOUS_TRANSACTION;
      c_created_by         CONSTANT VARCHAR2 (100) := 'NAPPERP';
      c_creation_date      CONSTANT DATE := SYSDATE;
   BEGIN
      INSERT INTO napperp.napp_rev_revenue_log
                  (module_name
                  ,pkg_name
                  ,prc_name
                  ,entity_name
                  ,entity_id
                  ,msg_typ
                  ,msg_txt
                  ,created_by
                  ,creation_date)
           VALUES (p_module_name
                  ,p_pkg_name
                  ,p_prc_name
                  ,p_entity_name
                  ,p_entity_id
                  ,p_msg_typ
                  ,p_msg_txt
                  ,c_created_by
                  ,c_creation_date);

      COMMIT;
   EXCEPTION
      WHEN OTHERS THEN
         NULL;
   END;

   PROCEDURE napp_rev_revenue_validate_proc (
      p_integration_instance_id  IN       VARCHAR2 DEFAULT NULL
     ,p_err_status               OUT      VARCHAR2
     ,p_err_msg                  OUT      VARCHAR2) IS
/*
|====================================================================================================================|
This procedure will be called from the Integration - INT-REV-013
The Integration will INSERT the records into the stafing table - napp_rev_revenue_raw_extract_stg with PROCESSED_FLAG = U
This procedure is to UPDATE the records in the stafing table
The records will be validated for 19 filter conditions
If any 1 of the filter condition fails, the record will be updated with PROCESSED_FLAG = F with respective comments
19 Cursors are created for the 19 filter conditions.
If the records get validated for all 19 filter conditions, the record will be updated with PROCESSED_FLAG = Y
The 20th Cursor will pick the records that got validated for all 19 filter conditions
|====================================================================================================================|*/
      l_processed_flag              napp_rev_revenue_raw_extract_stg.processed_flag%TYPE;
      l_comments                    napp_rev_revenue_raw_extract_stg.comments%TYPE;
      l_success_message             VARCHAR2 (32767);
      l_group_id_status             VARCHAR2 (20);
      l_group_id_msg                VARCHAR2 (32767);
      l_revenue_code_status         VARCHAR2 (20);
      l_revenue_code_msg            VARCHAR2 (32767);
      c_last_updated_by    CONSTANT VARCHAR2 (100) := 'NAPPERP';
      c_last_update_date   CONSTANT DATE := SYSDATE;
      c_bulk_collect_limit          NUMBER := 5000;
      c_master_org_id      CONSTANT NUMBER := 300000004058004;
      c_cost_org_name               VARCHAR2 (200) := 'NTAP NL Cost Org 630 (REVENUE)';

      TYPE rt_fc IS RECORD (
         recordid                      NUMBER
      );

      TYPE t_fc IS TABLE OF rt_fc
         INDEX BY BINARY_INTEGER;

      -- cursor for filter condition 1
      -- 1. Order is not Booked
      -- 2. No Invoice Associated
      CURSOR c_fc_01 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
          WHERE 1 = 1
            AND INSTR (UPPER (nrrres.status_code)
                      ,'DRAFT'
                      ,1
                      ,1) > 0
            AND nrrres.invoice_num IS NULL
            AND nrrres.processed_flag = 'U';

      tab_fc_01                     t_fc;
      l_fc_01_count                 NUMBER := 0;

      -- cursor for filter condition 2
      -- Pre-Build Hold Applied
      CURSOR c_fc_02 IS
         SELECT DISTINCT nrrres.recordid
                    FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
                        , (SELECT flvb.lookup_code
                             FROM napperp.fnd_lookup_values_b flvb
                            WHERE 1 = 1
                              AND flvb.lookup_type = 'NTAP_REVREC_HOLD'
                              AND flvb.enabled_flag = 'Y'
                              AND SYSDATE BETWEEN NVL (flvb.start_date_active, SYSDATE - 1) AND NVL (flvb.end_date_active, SYSDATE + 1)) flvb
                       /* commented on 07-10-2025
                        , (SELECT dfla.header_id
                                 ,dfla.line_id
                                 ,dfla.fulfill_line_id
                                 ,dfla.source_schedule_id
                                 ,dfla.source_order_system
                                 ,dhcb.hold_code
                             FROM napperp.doo_hold_codes_b dhcb
                                 ,napperp.doo_hold_instances dhi
                                 ,napperp.doo_fulfill_lines_all dfla
                            WHERE 1 = 1
                              AND dhi.hold_code_id = dhcb.hold_code_id
                              AND (   (    dhi.transaction_entity_name1 = 'DOO_ORDER_HEADERS_V'
                                       AND dhi.transaction_entity_id1 = dfla.header_id)
                                   OR (    dhi.transaction_entity_name1 = 'DOO_ORDER_LINES_V'
                                       AND dhi.transaction_entity_id1 = dfla.line_id)
                                   OR (    dhi.transaction_entity_name1 = 'DOO_ORDER_FLINES_V'
                                       AND dhi.transaction_entity_id1 = dfla.fulfill_line_id))
                              AND dhi.release_date IS NULL
                              AND dhi.active_flag = 'Y'
                              AND 1 = 1) holds
                        */
                        , (WITH holds AS (
                                SELECT
                                    dfla.header_id,
                                    dfla.line_id,
                                    dfla.fulfill_line_id,
                                    dfla.source_schedule_id,
                                    dfla.source_order_system,
                                    dhcb.hold_code
                                FROM
                                    napperp.doo_hold_codes_b       dhcb,
                                    napperp.doo_hold_instances     dhi,
                                    napperp.doo_fulfill_lines_all  dfla
                                WHERE
                                      dhi.hold_code_id = dhcb.hold_code_id
                                  AND (
                                        (dhi.transaction_entity_name1 = 'DOO_ORDER_HEADERS_V' AND dhi.transaction_entity_id1 = dfla.header_id)
                                     OR (dhi.transaction_entity_name1 = 'DOO_ORDER_LINES_V'   AND dhi.transaction_entity_id1 = dfla.line_id)
                                     OR (dhi.transaction_entity_name1 = 'DOO_ORDER_FLINES_V'  AND dhi.transaction_entity_id1 = NVL(dfla.root_parent_fulfill_line_id, dfla.fulfill_line_id))
                                      )
                                  AND dhi.release_date IS NULL
                                  AND dhi.active_flag = 'Y'
                            )
                            SELECT
                                    dfla.header_id,
                                    dfla.line_id,
                                    dfla.fulfill_line_id,
                                    dfla.source_schedule_id,
                                    dfla.source_order_system,
                                    h.hold_code
                            FROM holds h,
                                 napperp.doo_document_references ddr,
                                 napperp.doo_fulfill_lines_all  dfla
                            WHERE
                              TO_CHAR(h.fulfill_line_id) = ddr.doc_subline_id
                              AND h.header_id = ddr.header_id
                              AND dfla.header_id = ddr.header_id
                              AND dfla.fulfill_line_id = ddr.fulfill_line_id
                              AND ddr.doc_ref_type = 'COVERAGE_COVERED_ASSOCIATION'
                            UNION ALL
                            SELECT
                                    h.header_id,
                                    h.line_id,
                                    h.fulfill_line_id,
                                    h.source_schedule_id,
                                    h.source_order_system,
                                    h.hold_code
                            FROM holds h) holds
                   WHERE 1 = 1
                     AND holds.header_id = nrrres.so_header_id
                 --    AND TO_CHAR (holds.line_id) = nrrres.sales_order_line_id         -- Commented on 18-Sep-2025
                     AND ( TO_CHAR (holds.fulfill_line_id) = nrrres.sales_order_line_id
                          OR ( UPPER (holds.source_order_system) LIKE '%EBS%'
                               AND holds.source_schedule_id = nrrres.sales_order_line_id )
                      )
                     AND holds.hold_code = flvb.lookup_code
                     AND nrrres.processed_flag = 'U';

      tab_fc_02                     t_fc;
      l_fc_02_count                 NUMBER := 0;

      -- cursor for filter condition 3
      -- Invoice Number Already Processed
      CURSOR c_fc_03 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
          WHERE 1 = 1
            AND nrrres.processed_flag = 'U'
            AND nrrres.invoice_num is not null
            AND (   EXISTS (SELECT 1
                              FROM napperp.napp_revenue_valid_data_stg nrvds
                             WHERE nrvds.invoice_num = nrrres.invoice_num
                               AND nrvds.processed_flag = 'Y'
                               AND nrvds.ou_id = nrrres.ou_id) -- Added on 24-Jul-2025 for code review comment for OU_ID check
                 OR EXISTS (SELECT 1
                              FROM napperp.napp_revenue_valid_data_hist nrvdh
                             WHERE nrvdh.invoice_num = nrrres.invoice_num
                               AND nrvdh.processed_flag = 'Y'
                               AND nrvdh.ou_id = nrrres.ou_id)); -- Added on 24-Jul-2025 for code review comment for OU_ID check

      tab_fc_03                     t_fc;
      l_fc_03_count                 NUMBER := 0;

      -- cursor for filter condition 4
      -- Item Category Set Name = NAPP_REV_606
      CURSOR c_fc_04 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
          WHERE 1 = 1
            AND INSTR (UPPER (nrrres.exclude_item_flag)
                      ,'Y'
                      ,1
                      ,1) > 0
            AND nrrres.processed_flag = 'U';

      tab_fc_04                     t_fc;
      l_fc_04_count                 NUMBER := 0;

      -- cursor for filter condition 5
      -- Line Type NOT in LOOKUP_TYPE = NAPP_ORA_DOO_LINE_TYPE , NAPP_ORA_DOO_RETURN_LINE_TYPES
      CURSOR c_fc_05 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
          WHERE 1 = 1
            AND nrrres.line_type_ntap NOT IN (
                   SELECT flvb.lookup_code
                     FROM napperp.fnd_lookup_values_b flvb
                    WHERE 1 = 1
                      AND flvb.lookup_type IN ('NAPP_ORA_DOO_LINE_TYPE', 'NAPP_ORA_DOO_RETURN_LINE_TYPES') -- Lookup Name updated with NAPP% on 16/Jun/2025
                      AND flvb.enabled_flag = 'Y'
                      AND SYSDATE BETWEEN NVL (flvb.start_date_active, SYSDATE - 1) AND NVL (flvb.end_date_active, SYSDATE + 1))
            AND nrrres.processed_flag = 'U';

      tab_fc_05                     t_fc;
      l_fc_05_count                 NUMBER := 0;

      -- cursor for filter condition 6
      -- Order Type NOT in LOOKUP_TYPE = NAPP_ORA_DOO_ORDER_TYPES
      CURSOR c_fc_06 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
          WHERE 1 = 1
            AND nrrres.order_type NOT IN (
                   SELECT flvb.lookup_code
                     FROM napperp.fnd_lookup_values_b flvb
                    WHERE 1 = 1
                      AND flvb.lookup_type = 'NAPP_ORA_DOO_ORDER_TYPES'
                      AND flvb.enabled_flag = 'Y'
                      AND SYSDATE BETWEEN NVL (flvb.start_date_active, SYSDATE - 1) AND NVL (flvb.end_date_active, SYSDATE + 1))
            AND nrrres.processed_flag = 'U';

      tab_fc_06                     t_fc;
      l_fc_06_count                 NUMBER := 0;

      -- cursor for filter condition 7
      -- Manual Debit Memos
      CURSOR c_fc_07 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
               ,napperp.ra_customer_trx_all rcta
               ,napperp.ra_customer_trx_lines_all rctla
          WHERE 1 = 1
            AND rcta.trx_number = nrrres.invoice_num
            AND rcta.customer_trx_id = rctla.customer_trx_id
            AND rctla.customer_trx_line_id = nrrres.invoice_line_id
            AND rctla.sales_order IS NULL
            AND UPPER (rcta.trx_class) = 'DM'
            AND nrrres.processed_flag = 'U';

      tab_fc_07                     t_fc;
      l_fc_07_count                 NUMBER := 0;

      -- cursor for filter condition 8
      -- Manual Invoices (Credit Memos)
      CURSOR c_fc_08 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
               ,napperp.ra_customer_trx_all rcta
               ,napperp.ra_customer_trx_lines_all rctla
          WHERE 1 = 1
            AND rcta.trx_number = nrrres.invoice_num
            AND rcta.customer_trx_id = rctla.customer_trx_id
            AND rctla.customer_trx_line_id = nrrres.invoice_line_id
            AND rctla.sales_order IS NULL
            AND UPPER (rcta.trx_class) = 'CM'
            AND nrrres.processed_flag = 'U';

      tab_fc_08                     t_fc;
      l_fc_08_count                 NUMBER := 0;

      -- cursor for filter condition 9
      -- Item Number Contains Hat
      CURSOR c_fc_09 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
          WHERE 1 = 1
            AND (   INSTR (nrrres.line_item_num
                          ,'^'
                          ,1
                          ,1) > 0
                 OR INSTR (nrrres.line_item_num
                          ,'*'
                          ,1
                          ,1) > 0)
            AND nrrres.processed_flag = 'U';

      tab_fc_09                     t_fc;
      l_fc_09_count                 NUMBER := 0;

      -- cursor for filter condition 10
      -- Items with
      --    BOM Item Type = "Option Class"
      --    and in LOOKUP_TYPE = NAPP_REVREC_EX_BOM_ITEM
      -- BOM_ITEM_TYPE will be 2 for Option Class
      CURSOR c_fc_10 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
               , (SELECT flvb.lookup_code
                    FROM napperp.fnd_lookup_values_b flvb
                   WHERE 1 = 1
                     AND flvb.lookup_type = 'NAPP_REVREC_EX_BOM_ITEM'
                     AND flvb.enabled_flag = 'Y'
                     AND SYSDATE BETWEEN NVL (flvb.start_date_active, SYSDATE - 1) AND NVL (flvb.end_date_active, SYSDATE + 1)) flvb
          WHERE 1 = 1
            AND nrrres.bom_item_type = flvb.lookup_code
--            AND nrrres.bom_item_type = '2'   -- Option Class
            AND nrrres.processed_flag = 'U';

      tab_fc_10                     t_fc;
      l_fc_10_count                 NUMBER := 0;

      -- cursor for filter condition 11
      -- 1. BOM item type <> MODEL
      -- 2. BOM item type in LOOKUP_TYPE  = EGP_BOM_ITEM_TYPE
      -- 3. Unit List Price = 0
      -- 4. Unit Selling Price = 0
      -- 5. Frozen Cost = 0 / NULL
      -- BOM_ITEM_TYPE will be 1 for Model
      CURSOR c_fc_11 IS
         SELECT DISTINCT nrrres.recordid
                    FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
                        ,napperp.egp_system_items_b esib
--                        ,napperp.egp_item_classes_b_v eicb  -- commenting for defect CON0002775-716477
                       /* , (SELECT flvb.lookup_code
                             FROM napperp.fnd_lookup_values_b flvb
                            WHERE 1 = 1
                              AND flvb.lookup_type = 'EGP_BOM_ITEM_TYPE'
                              AND flvb.enabled_flag = 'Y'
                              AND SYSDATE BETWEEN NVL (flvb.start_date_active, SYSDATE - 1) AND NVL (flvb.end_date_active, SYSDATE + 1)) flvb
                       */
                        , (SELECT csc.inventory_item_id
                                 ,csc.inventory_org_id
                                 ,csc.total_cost
                             FROM napperp.cst_std_costs csc
                            WHERE 1 = 1
                              AND SYSDATE BETWEEN NVL (csc.effective_start_date, SYSDATE - 1) AND NVL (csc.effective_end_date, SYSDATE + 1)
                              AND csc.previous_effective_start_date IS NULL
                              AND csc.status_code = 'PUBLISHED'
                              AND 1 = 1) csc
                   WHERE 1 = 1
--                     AND nrrres.bom_item_type = flvb.lookup_code
                     AND nrrres.bom_item_type != '1'   -- Model
                     AND NVL (nrrres.unit_sell_price, 0) = 0
                     AND NVL (nrrres.unit_list_price, 0) = 0
                     AND csc.inventory_item_id (+) = nrrres.inventory_item_id
                     AND csc.inventory_org_id (+) = nrrres.inventory_org_id
                     AND NVL (csc.total_cost, 0) = 0
                     AND esib.inventory_item_id = nrrres.inventory_item_id
                     AND esib.organization_id = nrrres.inventory_org_id
--                     AND esib.item_catalog_group_id = eicb.item_class_id  -- commenting for defect CON0002775-716477
--                     AND eicb.item_class_code NOT IN ('Support_Services')  -- commenting for defect CON0002775-716477
--                     AND 1 = 2
                     AND nrrres.processed_flag = 'U';

      tab_fc_11                     t_fc;
      l_fc_11_count                 NUMBER := 0;

      -- cursor for filter condition 12
      -- 1. transaction type in LOOKUP_TYPE = NAPP_ORA_DOO_RETURN_LINE_TYPES
      -- 2. Unit List Price = 0
      -- 3. Unit Selling Price = 0
      -- 4. Frozen Cost = 0 / NULL
      CURSOR c_fc_12 IS
         SELECT DISTINCT nrrres.recordid
                    FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
                        , (SELECT flvb.lookup_code
                             FROM napperp.fnd_lookup_values_b flvb
                            WHERE 1 = 1
                              AND flvb.lookup_type = 'NAPP_ORA_DOO_RETURN_LINE_TYPES' -- 'NAPP_ORA_DOO_LINE_TYPE'
--                              AND flvb.tag = 'SRA'
                              AND flvb.enabled_flag = 'Y'
                              AND SYSDATE BETWEEN NVL (flvb.start_date_active, SYSDATE - 1) AND NVL (flvb.end_date_active, SYSDATE + 1)) flvb
                        , (SELECT csc.inventory_item_id
                                 ,csc.inventory_org_id
                                 ,csc.total_cost
                             FROM napperp.cst_std_costs csc
                            WHERE 1 = 1
                              AND SYSDATE BETWEEN NVL (csc.effective_start_date, SYSDATE - 1) AND NVL (csc.effective_end_date, SYSDATE + 1)
                              AND csc.previous_effective_start_date IS NULL
                              AND csc.status_code = 'PUBLISHED'
                              AND 1 = 1) csc
                   WHERE 1 = 1
                    -- added on 9-Jul-2025
                     AND nrrres.bom_item_type != '1'   -- Model
                    --
                     AND flvb.lookup_code = nrrres.line_type_ntap
                     AND NVL (nrrres.unit_sell_price, 0) = 0
                     AND NVL (nrrres.unit_list_price, 0) = 0
                     AND csc.inventory_item_id (+) = nrrres.inventory_item_id
                     AND csc.inventory_org_id (+) = nrrres.inventory_org_id
                     AND NVL (csc.total_cost, 0) = 0
--                     AND 1 = 2
                     AND nrrres.processed_flag = 'U';

      tab_fc_12                     t_fc;
      l_fc_12_count                 NUMBER := 0;

      -- cursor for filter condition 13
      -- 1. Invoice Type = 'CM'
      -- 2. Unit List Price = 0
      -- 3. Unit Selling Price = 0
      -- 4. Frozen Cost = 0 / NULL
      CURSOR c_fc_13 IS
         SELECT DISTINCT nrrres.recordid
                    FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
                        ,napperp.ra_customer_trx_all rcta
                        , (SELECT csc.inventory_item_id
                                 ,csc.inventory_org_id
                                 ,csc.total_cost
                             FROM napperp.cst_std_costs csc
                            WHERE 1 = 1
                              AND SYSDATE BETWEEN NVL (csc.effective_start_date, SYSDATE - 1) AND NVL (csc.effective_end_date, SYSDATE + 1)
                              AND csc.previous_effective_start_date IS NULL
                              AND csc.status_code = 'PUBLISHED'
                              AND 1 = 1) csc
                   WHERE 1 = 1
                    -- added on 9-Jul-2025
                     AND nrrres.bom_item_type != '1'   -- Model
                    --
                     AND rcta.trx_number = nrrres.invoice_num
                     AND UPPER (rcta.trx_class) = 'CM'
                     AND NVL (nrrres.unit_sell_price, 0) = 0
                     AND NVL (nrrres.unit_list_price, 0) = 0
                     AND csc.inventory_item_id (+) = nrrres.inventory_item_id
                     AND csc.inventory_org_id (+) = nrrres.inventory_org_id
                     AND NVL (csc.total_cost, 0) = 0
--                     AND 1 = 2
                     AND nrrres.processed_flag = 'U';

      tab_fc_13                     t_fc;
      l_fc_13_count                 NUMBER := 0;

      -- cursor for filter condition 14
      -- 1. Invoice Type = 'CM'
      -- 2. Batch Source = 'OKS_CONTRACTS'
      -- 3. REASON_CODE in LOOKUP_TYPE = NTAP_REVREC_REASON_CODES_EX
      CURSOR c_fc_14 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
               ,napperp.ra_customer_trx_all rcta
               ,napperp.ra_batch_sources_all rbsa
               , (SELECT flvb.lookup_code
                    FROM napperp.fnd_lookup_values_b flvb
                   WHERE 1 = 1
                --     AND flvb.lookup_type = 'NAPP_REVREC_REASON_CODES_EX'  -- commented on 4-Jul-25
                     AND flvb.lookup_type = 'NTAP_REVREC_REASON_CODES_EX'    -- added on 4-Jul-25
                     AND flvb.enabled_flag = 'Y'
                     AND SYSDATE BETWEEN NVL (flvb.start_date_active, SYSDATE - 1) AND NVL (flvb.end_date_active, SYSDATE + 1)) flvb
          WHERE 1 = 1
            AND flvb.lookup_code = nrrres.reason_code
            AND rcta.trx_number = nrrres.invoice_num
            AND UPPER (rcta.trx_class) = 'CM'
            AND rbsa.batch_source_seq_id = nrrres.batch_source_seq_id
            AND rbsa.NAME = 'OKS_CONTRACTS'
            AND nrrres.processed_flag = 'U';

      tab_fc_14                     t_fc;
      l_fc_14_count                 NUMBER := 0;

      -- cursor for filter condition 15
      -- 1. SO/SRA/SC line GL posted date is in current period
      -- 2. INV/CM accounted in a prior quarter

     CURSOR c_fc_15 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
               ,napperp.ra_customer_trx_all rcta
          WHERE 1 = 1
            AND rcta.trx_number = nrrres.invoice_num
            AND UPPER (rcta.trx_class) IN ('CM', 'INV')
            AND nrrres.sales_order_num IS NOT NULL
            AND nrrres.posted_date  < (SELECT a.qtr_start_dt
                                                    FROM napp_cl_rpro_calendar_g a,
                                                         napp_cl_rpro_period_g b
                                                   WHERE a.ID = b.ID
                                                     AND b.status='OPEN')
            AND nrrres.processed_flag = 'U';
      /*
      CURSOR c_fc_15 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
               ,napperp.ra_customer_trx_all rcta
               ,napperp.gl_je_headers gjh
          WHERE 1 = 1
            AND gjh.ledger_id = nrrres.rc_line_num13
            AND rcta.trx_number = nrrres.invoice_num
            AND UPPER (rcta.trx_class) IN ('CM', 'INV')
            AND TO_CHAR (nrrres.posted_date, 'Q') != TO_CHAR (gjh.posted_date, 'Q')
            AND nrrres.processed_flag = 'U';
     */




      tab_fc_15                     t_fc;
      l_fc_15_count                 NUMBER := 0;

      -- cursor for filter condition 16
      -- 1. INV/CM line GL posted date is in current period
      -- 2. INV/CM accounted in a prior quarter

     CURSOR c_fc_16 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
               ,napperp.ra_customer_trx_all rcta
          WHERE 1 = 1
            AND rcta.trx_number = nrrres.invoice_num
            AND UPPER (rcta.trx_class) IN ('CM', 'INV')
            AND nrrres.sales_order_num IS NULL
            AND nrrres.posted_date  < (SELECT a.qtr_start_dt
                                                    FROM napp_cl_rpro_calendar_g a,
                                                         napp_cl_rpro_period_g b
                                                   WHERE a.ID = b.ID
                                                     AND b.status='OPEN')
            AND nrrres.processed_flag = 'U';

       /*
      CURSOR c_fc_16 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
               ,napperp.ra_customer_trx_all rcta
               ,napperp.gl_je_headers gjh
          WHERE 1 = 1
            AND gjh.ledger_id = nrrres.rc_line_num13
            AND rcta.trx_number = nrrres.invoice_num
            AND UPPER (rcta.trx_class) IN ('CM', 'INV')
            AND TO_CHAR (nrrres.posted_date, 'Q') != TO_CHAR (gjh.posted_date, 'Q')
            AND nrrres.processed_flag = 'U';
      */


      tab_fc_16                     t_fc;
      l_fc_16_count                 NUMBER := 0;

      -- cursor for filter condition 17
      -- 1. KIT Items (Sales Order)
      -- 2. Items labeled as "Not Eligible For Invoice"
      CURSOR c_fc_17 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
               , (SELECT flvb.lookup_code
                    FROM napperp.fnd_lookup_values_tl flvt
                        ,napperp.fnd_lookup_values_b flvb
                   WHERE 1 = 1
                     AND flvb.lookup_type = flvt.lookup_type
                     AND flvb.lookup_code = flvt.lookup_code
                     AND flvb.enabled_flag = 'Y'
                     AND SYSDATE BETWEEN NVL (flvb.start_date_active, SYSDATE - 1) AND NVL (flvb.end_date_active, SYSDATE + 1)
                     AND flvb.lookup_type = 'EGP_ITEM_TYPE'
                     AND flvt.LANGUAGE = 'US'
                     AND INSTR (UPPER (flvt.meaning)
                               ,'KIT'
                               ,1
                               ,1) > 0) flvb_kit
               , (SELECT flvb.lookup_code
                    FROM napperp.fnd_lookup_values_b flvb
                   WHERE 1 = 1
                     AND flvb.enabled_flag = 'Y'
                     AND SYSDATE BETWEEN NVL (flvb.start_date_active, SYSDATE - 1) AND NVL (flvb.end_date_active, SYSDATE + 1)
                     AND flvb.lookup_type = 'NAPP_ORA_RETURN_LINE_TYPE') flvb_rma
          WHERE 1 = 1
            AND flvb_kit.lookup_code = nrrres.item_type
            AND NVL (nrrres.invoice_enabled_flag, 'N') = 'N'
            AND nrrres.line_type_ntap <> flvb_rma.lookup_code
            AND nrrres.processed_flag = 'U';

      tab_fc_17                     t_fc;
      l_fc_17_count                 NUMBER := 0;

      -- cursor for filter condition 18
      -- 1. KIT Items (SRA)
      -- 2. Items labeled as "Not Eligible For Invoice"
      CURSOR c_fc_18 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
               , (SELECT flvb.lookup_code
                    FROM napperp.fnd_lookup_values_tl flvt
                        ,napperp.fnd_lookup_values_b flvb
                   WHERE 1 = 1
                     AND flvb.lookup_type = flvt.lookup_type
                     AND flvb.lookup_code = flvt.lookup_code
                     AND flvb.enabled_flag = 'Y'
                     AND SYSDATE BETWEEN NVL (flvb.start_date_active, SYSDATE - 1) AND NVL (flvb.end_date_active, SYSDATE + 1)
                     AND flvb.lookup_type = 'EGP_ITEM_TYPE'
                     AND flvt.LANGUAGE = 'US'
                     AND INSTR (UPPER (flvt.meaning)
                               ,'KIT'
                               ,1
                               ,1) > 0) flvb_kit
               , (SELECT flvb.lookup_code
                    FROM napperp.fnd_lookup_values_b flvb
                   WHERE 1 = 1
                     AND flvb.enabled_flag = 'Y'
                     AND SYSDATE BETWEEN NVL (flvb.start_date_active, SYSDATE - 1) AND NVL (flvb.end_date_active, SYSDATE + 1)
                     AND flvb.lookup_type = 'NAPP_ORA_RETURN_LINE_TYPE') flvb_rma
          WHERE 1 = 1
            AND flvb_kit.lookup_code = nrrres.item_type
            AND NVL (nrrres.invoice_enabled_flag, 'N') = 'N'
            AND nrrres.line_type_ntap = flvb_rma.lookup_code
            AND nrrres.processed_flag = 'U';

      tab_fc_18                     t_fc;
      l_fc_18_count                 NUMBER := 0;

      -- cursor for filter condition 19
      -- 0$ PVR Orders Filtered due to Circular reference of GROUP_ID
CURSOR c_fc_19 IS
     WITH nrrres_cr AS
-- get records from staging table
     (SELECT DISTINCT 
             nrrres.sales_order_num
            ,nrrres.quote_number
            ,nrrres.zero_pvr_linked_quotes
            ,nrrres.oic_instance_id        oic_id
        FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
       WHERE 1 = 1
         AND UPPER(nrrres.zero_pvr_flag) IN ('Y','YES')
         AND nrrres.processed_flag = 'U'
         )
-- split the zero_pvr_linked_quotes from above query
     , orig_q_det AS
      (SELECT  
              nrrres_cr.sales_order_num orig_so
             ,nrrres_cr.quote_number orig_q
             ,regexp_substr (nrrres_cr.zero_pvr_linked_quotes
                            ,'[^~]+'
                            ,1
                            ,column_value) orig_zplq
             ,nrrres_cr.oic_id                       
         FROM nrrres_cr CROSS JOIN TABLE (CAST (MULTISET (SELECT     LEVEL
                                                                FROM DUAL
                                                          CONNECT BY LEVEL <= regexp_count (nrrres_cr.zero_pvr_linked_quotes, '~') + 1) AS SYS.odcivarchar2list)))
     ,linked_q_det AS
      (SELECT oqd.orig_so
             ,oqd.orig_q
             ,oqd.orig_zplq
             ,oqd.oic_id        
       FROM orig_q_det oqd
           ,orig_q_det oqd1
       WHERE 
             oqd.orig_zplq = oqd1.orig_q
         AND oqd.orig_q = oqd1.orig_zplq) 
  SELECT DISTINCT
            nrrres.recordid
        FROM
            linked_q_det,
            napperp.napp_rev_revenue_raw_extract_stg nrrres
        WHERE
            linked_q_det.orig_so = nrrres.sales_order_num
        AND linked_q_det.oic_id = nrrres.oic_instance_id;
            
  /*           
   CURSOR c_fc_19 IS
      WITH orig_q AS (
        SELECT DISTINCT
            nrrres.sales_order_num,
            nrrres.quote_number,
            nrrres.zero_pvr_linked_quotes zplq,
            nrrres.oic_instance_id        oic_id
        FROM
            napperp.napp_rev_revenue_raw_extract_stg nrrres
        WHERE
            1 = 1
            AND UPPER(nrrres.zero_pvr_flag) IN ('Y','YES')
            AND nrrres.processed_flag = 'U'
        ), linked_q AS (
            SELECT
                orig_q.sales_order_num        orig_so,
                nrrres.sales_order_num        linked_so,
                orig_q.quote_number           orig_quote,
                nrrres.quote_number           linked_quote,
                orig_q.zplq                   orig_zplq,
                nrrres.zero_pvr_linked_quotes linked_zplq
            FROM
                napperp.napp_rev_revenue_raw_extract_stg nrrres,
                orig_q
            WHERE
                    orig_q.zplq = nrrres.quote_number
                AND orig_q.quote_number = nrrres.zero_pvr_linked_quotes
                AND orig_q.oic_id = nrrres.oic_instance_id
        )
        SELECT DISTINCT
            nrrres.recordid
        FROM
            linked_q,
            napperp.napp_rev_revenue_raw_extract_stg nrrres
        WHERE
            linked_q.orig_so = nrrres.sales_order_num ;
/*
    /*  CURSOR c_fc_19 IS
WITH nrrres_cr AS
-- get records from staging table
     (SELECT nrrres.recordid
            ,nrrres.sales_order_num
            ,nrrres.zero_pvr_linked_quotes
        FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
       WHERE 1 = 1
         AND nrrres.zero_pvr_flag = 'Y'
         AND nrrres.mq_id_flag = 'N'
         AND nrrres.processed_flag = 'U')
-- split the zero_pvr_linked_quotes from above query
     , linked_quotes AS
      (SELECT nrrres_cr.recordid
             ,nrrres_cr.sales_order_num
             ,regexp_substr (nrrres_cr.zero_pvr_linked_quotes
                            ,'[^,]+'
                            ,1
                            ,column_value) lq_split
         FROM nrrres_cr CROSS JOIN TABLE (CAST (MULTISET (SELECT     LEVEL
                                                                FROM DUAL
                                                          CONNECT BY LEVEL <= regexp_count (nrrres_cr.zero_pvr_linked_quotes, ',') + 1) AS SYS.odcivarchar2list)))
-- get the sales order number which is one of the split zero_pvr_linked_quotes and the zplq for current sales order
     ,linked_sos AS
      (SELECT linked_quotes.recordid
             ,linked_quotes.sales_order_num org_so
             ,dha.order_number lnkd_so
             ,dheb.attribute_char9 zplq
         FROM napperp.doo_headers_all dha
             ,napperp.doo_headers_eff_b dheb
             ,linked_quotes
        WHERE 1 = 1
          AND dha.header_id = dheb.header_id
          AND dheb.context_code = 'Revenue'
          AND dha.order_number = TRIM (linked_quotes.lq_split))
-- split the zplq for current sales order from above query
     ,linked_so_zplq AS
      (SELECT linked_sos.recordid
             ,linked_sos.org_so
             ,linked_sos.lnkd_so
             ,regexp_substr (linked_sos.zplq
                            ,'[^,]+'
                            ,1
                            ,column_value) zplq_split
         FROM linked_sos CROSS JOIN TABLE (CAST (MULTISET (SELECT     LEVEL
                                                                 FROM DUAL
                                                           CONNECT BY LEVEL <= regexp_count (linked_sos.zplq, ',') + 1) AS SYS.odcivarchar2list)))
-- get the record where split zplq is the original SO
     ,crclr_lnk AS
      (SELECT linked_so_zplq.recordid
             ,linked_so_zplq.org_so
             ,linked_so_zplq.lnkd_so
         FROM linked_so_zplq
        WHERE TRIM (linked_so_zplq.zplq_split) = linked_so_zplq.org_so)
         SELECT crclr_lnk.recordid
           FROM crclr_lnk;
*/


      tab_fc_19                     t_fc;
      l_fc_19_count                 NUMBER := 0;

      -- cursor for filter condition 20
      -- Mark the records with Y
      CURSOR c_fc_20 IS
         SELECT nrrres.recordid
           FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
          WHERE 1 = 1
            AND nrrres.processed_flag = 'U';

      tab_fc_20                     t_fc;
      l_fc_20_count                 NUMBER := 0;
   BEGIN
      -- intialisation
      l_processed_flag := 'Y';
      l_comments := NULL;
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'Start of the Validation Procedure for 19 filter conditions');                                    
                                    
      -- filter condition 1
      -- 1. Order is not Booked
      -- 2. No Invoice Associated
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 1');

      BEGIN
      
         l_processed_flag := 'F';
         l_comments := 'OM Booked Filter';

         OPEN c_fc_01;

         LOOP
            FETCH c_fc_01
            BULK COLLECT INTO tab_fc_01 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_01.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_01 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 1 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_01_count := l_fc_01_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_01%NOTFOUND;
         END LOOP;

         CLOSE c_fc_01;

         l_success_message := 'filter condition 1 - Updated ' || l_fc_01_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_01%ISOPEN THEN
               CLOSE c_fc_01;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 1 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 1 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 2
      -- Pre-Build Hold Applied
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 2');

      BEGIN
         l_processed_flag := 'F';
         l_comments := 'OM Cascaded Hold Flag';

         OPEN c_fc_02;

         LOOP
            FETCH c_fc_02
            BULK COLLECT INTO tab_fc_02 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_02.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_02 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 2 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_02_count := l_fc_02_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_02%NOTFOUND;
         END LOOP;

         CLOSE c_fc_02;

         l_success_message := l_success_message || ' filter condition 2 - Updated ' || l_fc_02_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_02%ISOPEN THEN
               CLOSE c_fc_02;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 2 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 2 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 3
      -- Invoice Number Already Processed
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 3');

      BEGIN
         l_processed_flag := 'F';
         l_comments := 'Existing Invoice/CM Filter';

         OPEN c_fc_03;

         LOOP
            FETCH c_fc_03
            BULK COLLECT INTO tab_fc_03 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_03.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_03 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 3 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_03_count := l_fc_03_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_03%NOTFOUND;
         END LOOP;

         CLOSE c_fc_03;

         l_success_message := l_success_message || ' filter condition 3 - Updated ' || l_fc_03_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_03%ISOPEN THEN
               CLOSE c_fc_03;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 3 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 3 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 4
      -- Item Category Set Name = NAPP_REV_606
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 4');

      BEGIN
         /*
         As per Venkat Munaga, if the Category Filter condition fails, the record should be marked as N instead of F
         so, that, the record gets picked in the next run if there are any changes
         */
         l_processed_flag := 'N';
         l_comments := 'Category Filter';

         OPEN c_fc_04;

         LOOP
            FETCH c_fc_04
            BULK COLLECT INTO tab_fc_04 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_04.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_04 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 4 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_04_count := l_fc_04_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_04%NOTFOUND;
         END LOOP;

         CLOSE c_fc_04;

         l_success_message := l_success_message || ' filter condition 4 - Updated ' || l_fc_04_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_04%ISOPEN THEN
               CLOSE c_fc_04;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 4 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 4 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 5
      -- Line Type NOT in LOOKUP_TYPE = NAPP_REVREC_LINE_TYPES
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 5');

      BEGIN
         l_processed_flag := 'F';
         l_comments := 'Line Type Filter';

         OPEN c_fc_05;

         LOOP
            FETCH c_fc_05
            BULK COLLECT INTO tab_fc_05 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_05.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_05 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 5 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_05_count := l_fc_05_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_05%NOTFOUND;
         END LOOP;

         CLOSE c_fc_05;

         l_success_message := l_success_message || ' filter condition 5 - Updated ' || l_fc_05_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_05%ISOPEN THEN
               CLOSE c_fc_05;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 5 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 5 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 6
      -- Order Type NOT in LOOKUP_TYPE = NAPP_REVREC_ORDER_TYPES
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 6');

      BEGIN
         l_processed_flag := 'F';
         l_comments := 'Order Type Filter';

         OPEN c_fc_06;

         LOOP
            FETCH c_fc_06
            BULK COLLECT INTO tab_fc_06 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_06.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_06 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 6 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_06_count := l_fc_06_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_06%NOTFOUND;
         END LOOP;

         CLOSE c_fc_06;

         l_success_message := l_success_message || ' filter condition 6 - Updated ' || l_fc_06_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_06%ISOPEN THEN
               CLOSE c_fc_06;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 6 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 6 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 7
      -- Manual Debit Memos
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 7');

      BEGIN
         l_processed_flag := 'F';
         l_comments := 'DM Invoice Filter';

         OPEN c_fc_07;

         LOOP
            FETCH c_fc_07
            BULK COLLECT INTO tab_fc_07 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_07.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_07 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 7 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_07_count := l_fc_07_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_07%NOTFOUND;
         END LOOP;

         CLOSE c_fc_07;

         l_success_message := l_success_message || ' filter condition 7 - Updated ' || l_fc_07_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_07%ISOPEN THEN
               CLOSE c_fc_07;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 7 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 7 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 8
      -- Manual Invoices (Credit Memos)
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 8');

      BEGIN
         l_processed_flag := 'F';
         l_comments := 'Manual Invoice Filter';

         OPEN c_fc_08;

         LOOP
            FETCH c_fc_08
            BULK COLLECT INTO tab_fc_08 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_08.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_08 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 8 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_08_count := l_fc_08_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_08%NOTFOUND;
         END LOOP;

         CLOSE c_fc_08;

         l_success_message := l_success_message || ' filter condition 8 - Updated ' || l_fc_08_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_08%ISOPEN THEN
               CLOSE c_fc_08;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 8 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 8 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 9
      -- Item Number Contains Hat
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 9');

      BEGIN
         l_processed_flag := 'F';
         l_comments := 'Hat Item Filter';

         OPEN c_fc_09;

         LOOP
            FETCH c_fc_09
            BULK COLLECT INTO tab_fc_09 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_09.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_09 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 9 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_09_count := l_fc_09_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_09%NOTFOUND;
         END LOOP;

         CLOSE c_fc_09;

         l_success_message := l_success_message || ' filter condition 9 - Updated ' || l_fc_09_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_09%ISOPEN THEN
               CLOSE c_fc_09;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 9 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 9 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 10
      -- Items with BOM Item Type = "Option Class" in LOOKUP_TYPE = NAPP_REVREC_EX_BOM_ITEM
      -- BOM_ITEM_TYPE will be 2 for Option Class
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 10');

      BEGIN
         l_processed_flag := 'F';
         l_comments := 'BOM Item Type Filter';

         OPEN c_fc_10;

         LOOP
            FETCH c_fc_10
            BULK COLLECT INTO tab_fc_10 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_10.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_10 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 10 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_10_count := l_fc_10_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_10%NOTFOUND;
         END LOOP;

         CLOSE c_fc_10;

         l_success_message := l_success_message || ' filter condition 10 - Updated ' || l_fc_10_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_10%ISOPEN THEN
               CLOSE c_fc_10;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 10 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 10 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 11
      -- 1. BOM item type <> MODEL
      -- 2. BOM item type in LOOKUP_TYPE  = BOM_ITEM_TYPE
      -- 3. Unit List Price = 0
      -- 4. Unit Selling Price = 0
      -- 5. Frozen Cost = 0 / NULL
      -- BOM_ITEM_TYPE will be 1 for Model
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 11');

      BEGIN
         l_processed_flag := 'F';
         l_comments := 'Zero LP SP Frozen cost Filter';

         OPEN c_fc_11;

         LOOP
            FETCH c_fc_11
            BULK COLLECT INTO tab_fc_11 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_11.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_11 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 11 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_11_count := l_fc_11_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_11%NOTFOUND;
         END LOOP;

         CLOSE c_fc_11;

         l_success_message := l_success_message || ' filter condition 11 - Updated ' || l_fc_11_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_11%ISOPEN THEN
               CLOSE c_fc_11;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 11 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 11 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 12
      -- 1. transaction type in LOOKUP_TYPE = NAPP_REVREC_LINE_TYPES and TAG = SRA
      -- 2. Unit List Price = 0
      -- 3. Unit Selling Price = 0
      -- 4. Frozen Cost = 0 / NULL
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 12');

      BEGIN
         l_processed_flag := 'F';
         l_comments := 'SRA Zero LP SP Frozen cost Filter';

         OPEN c_fc_12;

         LOOP
            FETCH c_fc_12
            BULK COLLECT INTO tab_fc_12 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_12.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_12 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 12 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_12_count := l_fc_12_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_12%NOTFOUND;
         END LOOP;

         CLOSE c_fc_12;

         l_success_message := l_success_message || ' filter condition 12 - Updated ' || l_fc_12_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_12%ISOPEN THEN
               CLOSE c_fc_12;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 12 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 12 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 13
      -- 1. Invoice Type = 'CM'
      -- 2. Unit List Price = 0
      -- 3. Unit Selling Price = 0
      -- 4. Frozen Cost = 0 / NULL
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 13');

      BEGIN
         l_processed_flag := 'F';
         l_comments := 'CM-RO Zero LP SP Frozen cost Filter';

         OPEN c_fc_13;

         LOOP
            FETCH c_fc_13
            BULK COLLECT INTO tab_fc_13 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_13.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_13 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 13 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_13_count := l_fc_13_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_13%NOTFOUND;
         END LOOP;

         CLOSE c_fc_13;

         l_success_message := l_success_message || ' filter condition 13 - Updated ' || l_fc_13_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_13%ISOPEN THEN
               CLOSE c_fc_13;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 13 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 13 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 14
      -- 1. Invoice Type = 'CM'
      -- 2. Batch Source = 'OKS_CONTRACTS'
      -- 3. REASON_CODE in LOOKUP_TYPE = NAPP_REVREC_REASON_CODES_EX
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 14');

      BEGIN
         l_processed_flag := 'F';
         l_comments := 'Filter CM-RO terminated reason code';

         OPEN c_fc_14;

         LOOP
            FETCH c_fc_14
            BULK COLLECT INTO tab_fc_14 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_14.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_14 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 14 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_14_count := l_fc_14_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_14%NOTFOUND;
         END LOOP;

         CLOSE c_fc_14;

         l_success_message := l_success_message || ' filter condition 14 - Updated ' || l_fc_14_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_14%ISOPEN THEN
               CLOSE c_fc_14;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 14 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 14 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 15
      -- 1. SO/SRA/SC line GL posted date is in current period
      -- 2. INV/CM accounted in a prior quarter
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 15');

      BEGIN
         l_processed_flag := 'F';
         l_comments := 'OM/SRA Non-Current RevPro Period';

         OPEN c_fc_15;

         LOOP
            FETCH c_fc_15
            BULK COLLECT INTO tab_fc_15 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_15.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_15 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 15 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_15_count := l_fc_15_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_15%NOTFOUND;
         END LOOP;

         CLOSE c_fc_15;

         l_success_message := l_success_message || ' filter condition 15 - Updated ' || l_fc_15_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_15%ISOPEN THEN
               CLOSE c_fc_15;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 15 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 15 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 16
      -- 1. INV/CM line GL posted date is in current period
      -- 2. INV/CM accounted in a prior quarter
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 16');

      BEGIN
         l_processed_flag := 'F';
         l_comments := 'INV/CM Non-Current RevPro Period';

         OPEN c_fc_16;

         LOOP
            FETCH c_fc_16
            BULK COLLECT INTO tab_fc_16 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_16.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_16 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 16 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_16_count := l_fc_16_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_16%NOTFOUND;
         END LOOP;

         CLOSE c_fc_16;

         l_success_message := l_success_message || ' filter condition 16 - Updated ' || l_fc_16_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_16%ISOPEN THEN
               CLOSE c_fc_16;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 16 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 16 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 17
      -- 1. KIT Items (Sales Order)
      -- 2. Items labeled as "Not Eligible For Invoice"
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 17');

      BEGIN
         l_processed_flag := 'F';
         l_comments := 'Not Eligible for Invoice OM';

         OPEN c_fc_17;

         LOOP
            FETCH c_fc_17
            BULK COLLECT INTO tab_fc_17 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_17.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_17 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 17 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_17_count := l_fc_17_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_17%NOTFOUND;
         END LOOP;

         CLOSE c_fc_17;

         l_success_message := l_success_message || ' filter condition 17 - Updated ' || l_fc_17_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_17%ISOPEN THEN
               CLOSE c_fc_17;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 17 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 17 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- filter condition 18
      -- 1. KIT Items (SRA)
      -- 2. Items labeled as "Not Eligible For Invoice"
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 18');

      BEGIN
         l_processed_flag := 'F';
         l_comments := 'Not Eligible for Invoice SRA';

         OPEN c_fc_18;

         LOOP
            FETCH c_fc_18
            BULK COLLECT INTO tab_fc_18 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_18.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_18 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 18 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_18_count := l_fc_18_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_18%NOTFOUND;
         END LOOP;

         CLOSE c_fc_18;

         l_success_message := l_success_message || ' filter condition 18 - Updated ' || l_fc_18_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_18%ISOPEN THEN
               CLOSE c_fc_18;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 18 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 18 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

     -- filter condition 19
      -- 0$ PVR Orders Filtered due to Circular reference of GROUP_ID
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 19');

      BEGIN
      /*As per Venkat Munaga, if the Group Id Filter condition fails, the record should be marked as Y instead of F */

 --      l_processed_flag := 'F'; --Commented on 01/07/25
 --      l_processed_flag := 'CR';  --Commented on 17/10/25
 --      l_comments := 'Group id filter';  --Commented on 17/10/25
 
 -- Added on 17/10/25
         l_processed_flag := 'Y';
         l_comments := 'ZD Circular Reference Group Id filter';
 --
         OPEN c_fc_19;

         LOOP
            FETCH c_fc_19
            BULK COLLECT INTO tab_fc_19 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_19.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_19 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 19 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_19_count := l_fc_19_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_19%NOTFOUND;
         END LOOP;

         CLOSE c_fc_19;

         l_success_message := l_success_message || ' filter condition 19 - Updated ' || l_fc_19_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_19%ISOPEN THEN
               CLOSE c_fc_19;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 19 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 19 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;                                


      -- filter condition 20
      -- Mark the records with Y
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'entering filter condition 20');

      BEGIN
         l_processed_flag := 'Y';
         l_comments := 'Processed';

         OPEN c_fc_20;

         LOOP
            FETCH c_fc_20
            BULK COLLECT INTO tab_fc_20 LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_fc_20.COUNT
               UPDATE napperp.napp_rev_revenue_raw_extract_stg nrrres
                  SET nrrres.processed_flag = l_processed_flag
                     ,nrrres.comments = l_comments
                     ,nrrres.last_updated_by = c_last_updated_by
                     ,nrrres.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrres.recordid = tab_fc_20 (loop_index).recordid;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'filter condition 20 - Updated ' || SQL%ROWCOUNT || ' records');
            l_fc_20_count := l_fc_20_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_fc_20%NOTFOUND;
         END LOOP;

         CLOSE c_fc_20;

         l_success_message := l_success_message || ' filter condition 20 - Updated ' || l_fc_20_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_fc_20%ISOPEN THEN
               CLOSE c_fc_20;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'filter condition 20 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' filter condition 20 - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'End of the Validation Procedure for 19 filter conditions');

      -- Updating the OUT variables with SUCCESS
      IF p_err_status IS NULL THEN
         p_err_status := 'SUCCESS';
         p_err_msg := l_success_message;
      END IF;

/*
      -- calling the GROUP_ID procedure
      napp_insert_group_id_proc (p_integration_instance_id =>     p_integration_instance_id
                                ,p_err_status =>                  l_group_id_status
                                ,p_err_msg =>                     l_group_id_msg);
      p_err_status := l_group_id_status;
      p_err_msg := p_err_msg || ' ' || l_group_id_msg;
*/    -- calling the RESERVE_CODE procedure
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_INSERT_GROUP_ID_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'Calling RESERVE_CODE procedure');

      napp_insert_reserve_code_proc (p_integration_instance_id =>     p_integration_instance_id
                                    ,p_err_status =>                  l_revenue_code_status
                                    ,p_err_msg =>                     l_revenue_code_msg);
      p_err_status := l_revenue_code_status;
      p_err_msg := p_err_msg || ' ' || l_revenue_code_msg;

      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_INSERT_GROUP_ID_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'Finished Processing RESERVE_CODE procedure');

      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_INSERT_GROUP_ID_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'Calling GROUP_ID_DERIVATION procedure');

      napp_rev_revenue_extract_pkg.napp_rev_group_id_derivation_proc (p_err_status
                                                                     ,p_err_msg
                                                                     ,p_integration_instance_id);

       napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_INSERT_GROUP_ID_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'Finished Processing GROUP_ID_DERIVATION procedure');

   EXCEPTION
      WHEN OTHERS THEN
         NULL;
         -- Insert the SQLCODE and SQLERRM into a error log table
         napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                       ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                       ,p_prc_name =>                    'NAPP_REV_REVENUE_VALIDATE_PROC'
                                       ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                       ,p_entity_id =>                   p_integration_instance_id
                                       ,p_msg_typ =>                     'ERROR'
                                       ,p_msg_txt =>                     'Validate proc - Main Block - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

         IF p_err_status IS NULL THEN
            p_err_status := 'FAILURE';
         END IF;

         p_err_msg := p_err_msg || ' Validate proc - Main Block - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
   END napp_rev_revenue_validate_proc;

   PROCEDURE napp_insert_group_id_proc (
      p_integration_instance_id  IN       VARCHAR2 DEFAULT NULL
     ,p_err_status               OUT      VARCHAR2
     ,p_err_msg                  OUT      VARCHAR2) IS
/*
|====================================================================================================================|
This procedure will be called from the Integration - INT-REV-013
This procedure will be called after the call to NAPP_REV_REVENUE_VALIDATE_PROC
This procedure is to INSERT to and/or UPDATE the records in the GROUP_ID table - NAPP_REV_REVENUE_GROUP_ID
|====================================================================================================================|*/
      l_last_success_run_date       DATE;   -- get the value from Run History table
      l_current_run_date            DATE;   -- get the value from Run History table
      l_success_message             VARCHAR2 (32767);
      c_created_by         CONSTANT VARCHAR2 (100) := 'NAPPERP';
      c_creation_date      CONSTANT DATE := SYSDATE;
      c_last_updated_by    CONSTANT VARCHAR2 (100) := 'NAPPERP';
      c_last_update_date   CONSTANT DATE := SYSDATE;

      CURSOR c_group_id IS
         SELECT DISTINCT -- nrrres.so_header_id     -- commented on 29/06/25
                         nrrres.sales_order_num     -- added on 29/06/25
                        ,nrrres.GROUP_ID
                    FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
                        ,napperp.napp_rev_revenue_group_id nrrgi
                   WHERE 1 = 1
                     AND nrrres.GROUP_ID != nrrgi.GROUP_ID
               --      AND nrrres.so_header_id = nrrgi.so_header_id   -- commented on 29/06/25
                     AND nrrres.sales_order_num = nrrgi.so_number     -- added on 29/06/25
--                     AND nrrres.processed_flag = 'Y'
                     AND 1 = 1;

      TYPE rt_group_id IS RECORD (
     --    so_header_id                  NUMBER               -- commented on 29/06/25
         sales_order_num               VARCHAR2 (150)         -- added on 29/06/25
        ,GROUP_ID                      VARCHAR2 (150)
      );

      TYPE t_group_id IS TABLE OF rt_group_id
         INDEX BY BINARY_INTEGER;

      tab_group_id                  t_group_id;
      l_grp_id_count                NUMBER := 0;
      c_bulk_collect_limit          NUMBER := 1000;
   BEGIN
      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_INSERT_GROUP_ID_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'Start of the GROUP_ID procedure');

      BEGIN
         -- INSERT new records
         INSERT INTO napperp.napp_rev_revenue_group_id
                     (so_header_id
                     ,so_number
                     ,cust_po_num
                     ,GROUP_ID
                     ,mq_id
                     ,opportunity_num
                     ,invoice_to_org_id
                     ,zero_pvr_flag      --added on 10/06/2025
                     ,created_by
                     ,creation_date
                     ,last_updated_by
                     ,last_update_date)
            SELECT DISTINCT nrrres.so_header_id
                           ,nrrres.sales_order_num
                           ,nrrres.po_number
                           ,nrrres.GROUP_ID
                           ,nrrres.mq_id
                           ,nrrres.opportunity_num
                           ,nrrres.billto_cust_number
                           ,zero_pvr_flag --added on 10/06/2025
                           ,c_created_by
                           ,c_creation_date
                           ,c_last_updated_by
                           ,c_last_update_date
                       FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
                      WHERE 1 = 1
--                        AND nrrres.processed_flag = 'Y'
                        AND nrrres.GROUP_ID IS NOT NULL
                        /*AND nrrres.so_header_id NOT IN (SELECT nrrgi.so_header_id
                                                          FROM napperp.napp_rev_revenue_group_id nrrgi)*/
/*
                          AND NOT EXISTS (SELECT nrrgi.so_header_id
                                                          FROM napperp.napp_rev_revenue_group_id nrrgi
                                                          where nrrres.so_header_id=nrrgi.so_header_id)
*/
                          AND NOT EXISTS (SELECT nrrgi.so_number
                                                          FROM napperp.napp_rev_revenue_group_id nrrgi
                                                          where nrrres.sales_order_num=nrrgi.so_number)
                        AND 1 = 1;

         napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                       ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                       ,p_prc_name =>                    'NAPP_INSERT_GROUP_ID_PROC'
                                       ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                       ,p_entity_id =>                   p_integration_instance_id
                                       ,p_msg_typ =>                     'LOG'
                                       ,p_msg_txt =>                     'GROUP_ID proc - Inserted ' || SQL%ROWCOUNT || ' records');
--         l_success_message := ' GROUP_ID proc - Inserted ' || SQL%ROWCOUNT || ' records';
         COMMIT;
      EXCEPTION
         WHEN OTHERS THEN
            NULL;
            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_INSERT_GROUP_ID_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'GROUP_ID - Insert - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' GROUP_ID - Insert - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- UPDATE existing records
      BEGIN
         OPEN c_group_id;

         LOOP
            FETCH c_group_id
            BULK COLLECT INTO tab_group_id LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_group_id.COUNT
               UPDATE napperp.napp_rev_revenue_group_id nrrgi
                  SET nrrgi.GROUP_ID = tab_group_id (loop_index).GROUP_ID
                     ,nrrgi.last_updated_by = c_last_updated_by
                     ,nrrgi.last_update_date = c_last_update_date
              --  WHERE nrrgi.so_header_id = tab_group_id (loop_index).so_header_id;   -- commented on 29/06/25
              WHERE nrrgi.so_number = tab_group_id (loop_index).sales_order_num;       -- added on 29/06/25
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_INSERT_GROUP_ID_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'GROUP_ID proc - Updated ' || SQL%ROWCOUNT || ' records');
            l_grp_id_count := l_grp_id_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_group_id%NOTFOUND;
         END LOOP;

         CLOSE c_group_id;
--         l_success_message := l_success_message || ' GGROUP_ID proc - Updated ' || l_grp_id_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_group_id%ISOPEN THEN
               CLOSE c_group_id;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_INSERT_GROUP_ID_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'GROUP_ID proc - Update - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' GROUP_ID proc - Update - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_INSERT_GROUP_ID_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'End of the GROUP_ID procedure');

      -- Updating the OUT variables with SUCCESS
      IF p_err_status IS NULL THEN
         p_err_status := 'SUCCESS';
         p_err_msg := l_success_message;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
         -- Insert the SQLCODE and SQLERRM into a error log table
         napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                       ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                       ,p_prc_name =>                    'NAPP_INSERT_GROUP_ID_PROC'
                                       ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                       ,p_entity_id =>                   p_integration_instance_id
                                       ,p_msg_typ =>                     'ERROR'
                                       ,p_msg_txt =>                     'GROUP_ID proc - Main Block - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

         IF p_err_status IS NULL THEN
            p_err_status := 'ERROR';
         END IF;

         p_err_msg := p_err_msg || ' GROUP_ID proc - Main Block - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
   END napp_insert_group_id_proc;

   PROCEDURE napp_insert_reserve_code_proc (
      p_integration_instance_id  IN       VARCHAR2 DEFAULT NULL
     ,p_err_status               OUT      VARCHAR2
     ,p_err_msg                  OUT      VARCHAR2) IS
/*
|====================================================================================================================|
This procedure will be called from the Integration - INT-REV-013
This procedure will be called after the call to NAPP_INSERT_GROUP_ID_PROC
This procedure is to INSERT to and/or UPDATE the records in the RESERVE_CODE table - NAPP_REV_REVENUE_RESERVE_CODE
|====================================================================================================================|*/
      l_last_success_run_date       DATE;   -- get the value from Run History table
      l_current_run_date            DATE;   -- get the value from Run History table
      l_success_message             VARCHAR2 (32767);
      c_created_by         CONSTANT VARCHAR2 (100) := 'NAPPERP';
      c_creation_date      CONSTANT DATE := SYSDATE;
      c_last_updated_by    CONSTANT VARCHAR2 (100) := 'NAPPERP';
      c_last_update_date   CONSTANT DATE := SYSDATE;

      CURSOR c_reserve_code IS
         SELECT DISTINCT nrrres.sales_order_num
                        ,nrrres.sales_order_line_id
                        ,nrrres.reserve_code
                    FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
                        ,napperp.napp_rev_revenue_reserve_code nrrrs
                   WHERE 1 = 1
                     AND nrrres.sales_order_num = nrrrs.sales_order_num
                     AND nrrres.sales_order_line_id = nrrrs.sales_order_line_id
                     AND nrrres.reserve_code != nrrrs.atr57_new
                     AND nrrres.processed_flag = 'Y';

      TYPE rt_reserve_code IS RECORD (
         sales_order_num               VARCHAR2 (100)
        ,sales_order_line_id           NUMBER
        ,reserve_code                  VARCHAR2 (100)
      );

      TYPE t_reserve_code IS TABLE OF rt_reserve_code
         INDEX BY BINARY_INTEGER;

      tab_reserve_code              t_reserve_code;
      l_reserve_code_count          NUMBER := 0;
      c_bulk_collect_limit          NUMBER := 1000;
   BEGIN
     napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_INSERT_RESERVE_CODE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'Start of the RESERVE_CODE procedure');
      -- INSERT new records
      BEGIN
         INSERT INTO napperp.napp_rev_revenue_reserve_code
                     (sales_order_num
                     ,sales_order_line_id
                     ,atr57_old
                     ,atr57_new
--                     ,flag_type
                     ,fob_released
                     ,concurrent_program_id
                     ,created_by
                     ,creation_date
                     ,last_updated_by
                     ,last_update_date)
            SELECT nrrres.sales_order_num
                  ,nrrres.sales_order_line_id
                  ,NULL
                  ,nrrres.reserve_code
--                  ,nrrres.flag_type
                  ,'N'                  -- changed from 'Y' to 'N' (20-Aug-2025)
                  ,p_integration_instance_id
                  ,c_created_by
                  ,c_creation_date
                  ,c_last_updated_by
                  ,c_last_update_date
              FROM napperp.napp_rev_revenue_raw_extract_stg nrrres
             WHERE 1 = 1
               AND nrrres.processed_flag = 'Y'
               AND nrrres.reserve_code IS NOT NULL
               AND (nrrres.sales_order_num, nrrres.sales_order_line_id) NOT IN (SELECT nerc.sales_order_num
                                                                                      ,sales_order_line_id
                                                                                  FROM napperp.napp_rev_revenue_reserve_code nerc);

         napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                       ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                       ,p_prc_name =>                    'NAPP_INSERT_RESERVE_CODE_PROC'
                                       ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                       ,p_entity_id =>                   p_integration_instance_id
                                       ,p_msg_typ =>                     'LOG'
                                       ,p_msg_txt =>                     'RESERVE_CODE proc - Inserted ' || SQL%ROWCOUNT || ' records');
--         l_success_message := 'RESERVE_CODE  proc - Inserted ' || SQL%ROWCOUNT || ' records';
         COMMIT;
      EXCEPTION
         WHEN OTHERS THEN
            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_INSERT_RESERVE_CODE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'RESERVE_CODE proc - Insert - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' RESERVE_CODE proc - Insert - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      -- UPDATE existing records
      BEGIN
         OPEN c_reserve_code;

         LOOP
            FETCH c_reserve_code
            BULK COLLECT INTO tab_reserve_code LIMIT c_bulk_collect_limit;

            FORALL loop_index IN 1 .. tab_reserve_code.COUNT
               UPDATE napperp.napp_rev_revenue_reserve_code nrrrs
                  SET nrrrs.atr57_old = nrrrs.atr57_new
                     ,nrrrs.atr57_new = tab_reserve_code (loop_index).reserve_code
                     ,nrrrs.concurrent_program_id = p_integration_instance_id
                     ,nrrrs.last_updated_by = c_last_updated_by
                     ,nrrrs.last_update_date = c_last_update_date
                WHERE 1 = 1
                  AND nrrrs.sales_order_num = tab_reserve_code (loop_index).sales_order_num
                  AND nrrrs.sales_order_line_id = tab_reserve_code (loop_index).sales_order_line_id;
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_INSERT_RESERVE_CODE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'LOG'
                                          ,p_msg_txt =>                     'RESERVE_CODE proc - Updated ' || SQL%ROWCOUNT || ' records');
            l_reserve_code_count := l_reserve_code_count + SQL%ROWCOUNT;
            COMMIT;
            EXIT WHEN c_reserve_code%NOTFOUND;
         END LOOP;

         CLOSE c_reserve_code;
--         l_success_message := l_success_message || ' RESERVE_CODE proc - Updated ' || l_reserve_code_count || ' records';
      EXCEPTION
         WHEN OTHERS THEN
            IF c_reserve_code%ISOPEN THEN
               CLOSE c_reserve_code;
            END IF;

            -- Insert the SQLCODE and SQLERRM into a error log table
            napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                          ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                          ,p_prc_name =>                    'NAPP_INSERT_RESERVE_CODE_PROC'
                                          ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                          ,p_entity_id =>                   p_integration_instance_id
                                          ,p_msg_typ =>                     'ERROR'
                                          ,p_msg_txt =>                     'RESERVE_CODE proc - Update - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

            IF p_err_status IS NULL THEN
               p_err_status := 'ERROR';
            END IF;

            p_err_msg := p_err_msg || ' RESERVE_CODE proc - Update - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
      END;

      napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                    ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                    ,p_prc_name =>                    'NAPP_INSERT_RESERVE_CODE_PROC'
                                    ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                    ,p_entity_id =>                   p_integration_instance_id
                                    ,p_msg_typ =>                     'LOG'
                                    ,p_msg_txt =>                     'End of the RESERVE_CODE procedure');

      -- Updating the OUT variables with SUCCESS
      IF p_err_status IS NULL THEN
         p_err_status := 'SUCCESS';
         p_err_msg := l_success_message;
      END IF;
   EXCEPTION
      WHEN OTHERS THEN
         -- Insert the SQLCODE and SQLERRM into a error log table
         napp_rev_revenue_log_err_proc (p_module_name =>                 'REV-EXT-001'
                                       ,p_pkg_name =>                    'NAPP_REV_REVENUE_VALIDATION_PKG'
                                       ,p_prc_name =>                    'NAPP_INSERT_RESERVE_CODE_PROC'
                                       ,p_entity_name =>                 'INTEGRATION_INSTANCE_ID'
                                       ,p_entity_id =>                   p_integration_instance_id
                                       ,p_msg_typ =>                     'ERROR'
                                       ,p_msg_txt =>                     'RESERVE_CODE proc - Main Block - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM);

         IF p_err_status IS NULL THEN
            p_err_status := 'ERROR';
         END IF;

         p_err_msg := p_err_msg || ' RESERVE_CODE proc - Main Block - Error Code - ' || SQLCODE || ' - Error Message - ' || SQLERRM;
   END napp_insert_reserve_code_proc;
END napp_rev_revenue_validation_pkg;
/