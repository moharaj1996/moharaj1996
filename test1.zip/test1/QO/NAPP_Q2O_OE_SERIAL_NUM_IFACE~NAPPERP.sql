/*
   |=============================================================================|
   |               NETWORK APPLIANCE INC. SUNNYVALE CALIFORNIA                   |
   |=============================================================================|
   |   OBJECT NAME   : NAPPERP.NAPP_Q2O_OE_SERIAL_NUM_IFACE                      |
   |                                                                             |
   |   PARAMETERS    : NONE                                                      |
   |                                                                             |
   |   DESCRIPTION   : Query used to create table for serial details of Quotes   | 
   |                                                                             |
   |   NOTES         :                                                           |
   |                                                                             |
   |                                                                             |
   |   20-May-2024   : Initial version					                         |
   | Ver  Date       Name           Revision Description                         |
   | ===  =========  ============== ===========================================  |
   | 1.0  20-May-24  Sunny Bajaj  Initial Creation.                              |
   | 2.0  19-May-24  Nepal Reddy  CON0002775-716584                              |
   |=============================================================================|
 */

CREATE TABLE napperp.napp_q2o_oe_serial_num_iface (
    id                   VARCHAR2(100 BYTE),
    created_at           TIMESTAMP(6),
    last_modify_at       TIMESTAMP(6),
    created_by           VARCHAR2(100 BYTE),
    last_modify_by       VARCHAR2(100 BYTE),
    transaction_id       VARCHAR2(100 BYTE)
        NOT NULL ENABLE,
    trx_num              VARCHAR2(100 BYTE),
    quote_number         VARCHAR2(100 BYTE)
        NOT NULL ENABLE,
    virtual_line_id      NUMBER,
    cpq_config_id        NUMBER,
    linked_quote_number  VARCHAR2(100 BYTE),
    linked_quote_line_id VARCHAR2(100 BYTE),
    serial_number        VARCHAR2(100 BYTE),
    partner_flag         VARCHAR2(1 BYTE),
    quote_line_id        NUMBER,
    do_not_send_flag     VARCHAR2(6 BYTE),
    linked_sw_line_id    NUMBER,
    creation_date        TIMESTAMP(6),
    creation_by          VARCHAR2(100 BYTE),
    last_update_date     TIMESTAMP(6),
    last_update_by       VARCHAR2(100 BYTE),
    attribute1           VARCHAR2(4000 BYTE),
    attribute2           VARCHAR2(4000 BYTE),
    attribute3           VARCHAR2(4000 BYTE),
    attribute4           VARCHAR2(4000 BYTE),
    attribute5           VARCHAR2(4000 BYTE),
    attribute6           VARCHAR2(4000 BYTE),
    attribute7           VARCHAR2(4000 BYTE),
    attribute8           VARCHAR2(4000 BYTE),
    attribute9           VARCHAR2(4000 BYTE),
    attribute10          VARCHAR2(4000 BYTE),
    oic_instance_id      VARCHAR2(100 BYTE),
    status               VARCHAR2(100 BYTE)
);
/
-- V2.0 Added
ALTER TABLE napperp.napp_q2o_oe_serial_num_iface MODIFY (
    created_by VARCHAR2(1000),
    last_modify_by VARCHAR2(1000)
);