create or replace PACKAGE  napperp.napp_q2o_so_process_pkg AS
/*
|======================================================================================================================|
|               NetApp Inc. Sunnyvale California			                                                           |
|======================================================================================================================|
|                                                                                                                      |
|    File Name   : napp_q2o_so_process_pkg.pks                                                                         |
|    Object Name : napp_q2o_so_process_pkg                                                                             |
|                                                                                                                      |
|    Description : Package used for validating the data and creating the the sales Orders                              |
|    Revision History:                                                                                                 |
|                                                                                                                      |
|  Ver  Date          Modified By     		Revision Description                                                       |
|  ===  ============  ==============  		===========================================================================|
|  1.0  29-APR-2024   Nepal Bhumireddy  	CON0002775-4228 Initial Development                                        |
|  1.6  17-SEP-2025   Nepal Bhumireddy      CON0002775-783077 Consider Converted Orders for ADDON Services and Renewals|
|  1.8  19-SEP-2025   Nepal Bhumireddy      CON0002775-783385 fix for quote Line Id parameter as text                  |
|  2.7  01-OCT-2025   Nepal Bhumireddy      CON0002775-783946, 775801 fix for Capturing unique Serials at Top Model    |
|  4.2  24-OCT-2025   Nepal Bhumireddy      CON0002775-788028 fix for Customer Retry mechanism for 30 mins             |
|  4.8  03-NOV-2025   Nepal Bhumireddy      CON0002775-754458 CR for Attachments                                       |
|  5.2  07-NOV-2025   Nepal Bhumireddy      CON0002775-803483 fIX for ADDon Service, Renewal for qty greater than 1    |
|  6.4  30-DEC-2025   Shabbir Hussain       INC4410842 / USER STORY 906238 - Added Logic for Expansion Storage         |
|  6.7  08-JAN-2026   Rajendra Kona         USER STORY 907827 - Host Based Software Support Renewal                    |
|  6.8  04-FEB-2026   Feroz Pathan          USER STORY 910092 - Fix to Exclude Trade-In E-Series parts for SerialNumber|
|                                           Check                                                                      |
|  7.1  03-FEB-2026   Rajendra Kona         USER STORY 909914 - Fix for Shelf RTN quote failure due to multiple assets |
|                                                               against a serial number                                |
|  7.6  02-MAR-2026   Darshan P             USER STORY 915236 - Fix for updating acknowledge flag to exclude OSV for   |
|                                           Autobooking                                                                |
|  7.7  31-MAR-2026   Nepal Bhumireddy      USER STORY 910141 - Fix for Cross Org Validation                           |
|  7.9  23-MAR-2026   Vamsi Boyalla/Feroz P USER STORY 910134 - Fix for Quotes Batch failures (1 bad quote causing     |
|                                                               whole FBDI batch failure)                              |
|  8.0  18-MAR-2026   Feroz Pathan          USER STORY 914303 - Client Software Renewal/Add on Ordered Quantity doesn't| 
                                                                match with provided Serial Numbers Total IB Quantity   |
|  8.3  03-APR-2026   Nepal/Rajendra        USER STORY 906196, 914305 - Fixes for HBS Items and VAS Items              |
|  8.9  07-MAY-2026   Nepal Bhumireddy      USER STPRY 935249 - Fix for Trade In Quotes processing without error when  |
|                                                               multiple controllers or no controller derived          |
|  9.0  18-AUG-2026   Darshan P             USER STORY 947908 - Success Edge QTOP changes for Renewal/Addon Use-Cases  |
|======================================================================================================================|*/

    -- V7.0 Start of Code
    PROCEDURE napp_om_so_wrapper_item (
        p_quote_number   IN VARCHAR2,
        p_transaction_id IN VARCHAR2,
        p_status         OUT VARCHAR2
    );

	-- Procedure for populating the History Tables with the original Data
    PROCEDURE napp_om_so_populate_hist_proc (
        p_quote_number   IN VARCHAR2,
        p_transaction_id IN VARCHAR2,
        p_status         OUT VARCHAR2
    );

	-- Procedure for populating the History Tables with the Transformed Data
    PROCEDURE napp_om_so_populate_tranfmd_proc (
        p_quote_number   IN VARCHAR2,
        p_transaction_id IN VARCHAR2,
        p_instance_id    IN VARCHAR2,
        p_status         OUT VARCHAR2
    );

	-- Procedure for populating the Process Tables
    PROCEDURE napp_om_so_populate_fbdi_proc (
        p_quote_number   IN VARCHAR2,
        p_transaction_id IN VARCHAR2,
        p_status         OUT VARCHAR2
    );

	-- Procedure for real time validation updates
    PROCEDURE napp_om_so_realtime_update_proc (
        p_quote_number             IN VARCHAR2,
        p_transaction_id           IN VARCHAR2,
        p_oic_batch_id             IN VARCHAR2,
        p_billto_contact_cmat_id   IN NUMBER,
        p_billto_contact_point_id  IN NUMBER,
        p_shipto_contact_cmat_id   IN NUMBER,
        p_shipto_contact_point_id  IN NUMBER,
        p_soldto_contact_cmat_id   IN NUMBER,
        p_soldto_contact_point_id  IN NUMBER,
        p_billto_cust_cmat_id      IN NUMBER,
        p_billto_cust_cmat_site_id IN NUMBER,
        p_shipto_acc_cmat_site_id  IN NUMBER,
        p_cust_acct_name           IN VARCHAR2,
        p_error_code               IN VARCHAR2,
        p_error_msg                IN VARCHAR2
    );

	-- Procedure for reprocess the quotes
    PROCEDURE napp_om_so_reprocess_proc (
        p_quote_number   IN VARCHAR2,
        p_transaction_id IN VARCHAR2
    );

	-- Procedure for deriving the controller or Facilitating part
    PROCEDURE napp_om_so_derive_cntlr_item_proc (
        p_quote_number         IN VARCHAR2, -- V5.2 Added
        p_transaction_id       IN VARCHAR2, -- V5.2 Added
        p_quote_line_id        IN VARCHAR2, -- V5.2 Added
        p_serial_number        IN VARCHAR2,
        p_customer             IN NUMBER,
        p_sr_line_flag         IN VARCHAR2,
        p_config_type          IN VARCHAR2,
        p_linked_quote_line_id IN VARCHAR2,
        p_linked_quote_number  IN VARCHAR2,
        p_trade_in_flag        IN VARCHAR2,
        p_item                 IN VARCHAR2,
        p_controller_item      OUT VARCHAR2,
        p_asset_number         OUT VARCHAR2,
        p_asset_id             OUT NUMBER,
        p_error_msg            OUT VARCHAR2,
        p_warning_msg          OUT VARCHAR2 -- V7.1 Added
    );

	-- Procedure to derive the serial numbers for the given linked quote Number and Linked QUote Line ID combination for ADD On Software
    PROCEDURE napp_om_so_derive_serial_num_proc (
        p_linked_quote_line_id IN VARCHAR2,
        p_linked_quote_number  IN VARCHAR2,
        p_quantity             IN NUMBER,
        p_serial_number        OUT VARCHAR2,
        p_item_id              OUT VARCHAR2,
        p_org_id               OUT VARCHAR2,
        p_error_msg            OUT VARCHAR2
    );

	-- Procedute to derive the service dates for ADD ON and Renewals
    PROCEDURE napp_om_so_derive_service_dates (
        p_quote_number   IN napp_q2o_oe_headers_iface_all.quote_number%TYPE,
        p_transaction_id IN napp_q2o_oe_headers_iface_all.transaction_id%TYPE,
        p_ps_flag        IN napp_q2o_oe_headers_iface_all.ps_flag%TYPE,
        p_federal_flag   IN napp_q2o_oe_headers_iface_all.federal_flag%TYPE,
        p_error_msg      OUT VARCHAR2
    );

	-- Procedure for fetching the Node Value for SSP Renewals
    PROCEDURE napp_om_so_ssprnwl_get_qty_proc (
        p_serial_number        IN VARCHAR2,
        p_linked_quote_line_id IN VARCHAR2,
        p_customer             IN NUMBER,
        p_asset_number         IN VARCHAR2, -- V8.3 Added
        p_asset_pct            OUT VARCHAR2,
        p_asset                OUT VARCHAR2,
        p_asset_id             OUT NUMBER,
        p_node_value           OUT NUMBER,
        p_item_type            OUT VARCHAR2, -- Added for v6.7
        p_perpetual_license    OUT VARCHAR2, -- Added for v6.7
        p_error_msg            OUT VARCHAR2
    );

	-- Procedure for INC and TOT validation -- Commented the code as part V8.0 ADO#914303
/*     PROCEDURE napp_om_so_inc_tot_validate_proc (
        p_quote_number         IN VARCHAR2,
        p_transaction_id       IN VARCHAR2,
        -- p_quote_line_id        IN NUMBER, -- Commented for V1.8
        p_quote_line_id        IN VARCHAR2, -- Added for V1.8
        p_item_type            IN VARCHAR2,
        p_sw_order_type        IN VARCHAR2,
        p_sw_workflow          IN VARCHAR2,
        p_pct                  IN VARCHAR2,
        p_sw_mccpline          IN VARCHAR2,
        p_linked_quote_line_id IN VARCHAR2,
        p_linked_quote_number  IN VARCHAR2,
        p_serial_number        IN VARCHAR2,
        p_error_code           OUT VARCHAR2,
        p_error_msg            OUT VARCHAR2
    ); */

	-- Procedure to process the SRA Quotes
    PROCEDURE napp_om_so_sra_proc (
        p_quote_number   IN VARCHAR2,
        p_transaction_id IN VARCHAR2,
        p_order_source   IN VARCHAR2,
        p_oic_batch_id   IN VARCHAR2,
        p_error_msg      OUT VARCHAR2
    );

    PROCEDURE napp_om_so_validation_proc (
        p_quote_number   IN VARCHAR2,
        p_transaction_id IN VARCHAR2,
        p_status         OUT VARCHAR2,
        p_error_code     OUT VARCHAR2,
        p_error_msg      OUT VARCHAR2
    );

	-- Procedure to update the Batch_id for quotes validation
    PROCEDURE napp_om_so_update_oic_batch_id (
        p_records_per_batch IN NUMBER,
        p_max_batches       IN NUMBER,
        p_oic_instance_id   IN VARCHAR2,
        p_status            OUT VARCHAR2,
        p_message           OUT VARCHAR2
    );

    PROCEDURE main_proc (
        p_oic_batch_id IN VARCHAR2
    );

	-- Procedure for Scheduling
    PROCEDURE napp_om_so_schedule_main_proc (
        p_oic_batch_id IN VARCHAR2,
        p_status       OUT VARCHAR2
    );

	-- Procedure for Status Update
    PROCEDURE napp_om_so_status_log_proc (
        p_quote_number   IN VARCHAR2,
        p_transaction_id IN VARCHAR2,
        p_status         IN VARCHAR2,
        p_error_msg      IN VARCHAR2,
        p_last_update_by IN VARCHAR2,
        p_prc_status     OUT VARCHAR2
    );

	-- Procedure for deleting the processed data
    PROCEDURE napp_om_so_delete_prc_tbl_proc (
        p_quote_number IN VARCHAR2,
        p_error_msg    OUT VARCHAR2,
        p_prc_status   OUT VARCHAR2
    );

	-- Procedure for updating the warning status
    PROCEDURE napp_om_so_process_log_status_proc (
        p_quote_number   IN VARCHAR2,
        p_transaction_id IN VARCHAR2,
        p_update_warning IN VARCHAR2,
        p_prc_status     OUT VARCHAR2
    );

	-- Procedure to check for EBS Converted Orders
    PROCEDURE napp_om_so_check_ebs_proc (
        p_quote_number   IN VARCHAR2,
        p_transaction_id IN VARCHAR2,
        p_prc_status     OUT VARCHAR2
    );

	-- Procedure to insert data into Process LOG
    PROCEDURE napp_om_so_insert_process_log (
        p_insert_record IN napp_om_so_process_log_typ,
        p_prc_status    OUT VARCHAR2
    );

	-- Procedure to Split the lines
    PROCEDURE napp_om_so_split_quantity (
        p_quote_number   IN VARCHAR2,
        p_transaction_id IN VARCHAR2,
        p_status         OUT VARCHAR2
    );

	-- procedure to insert the data to History table and delete the data from iface and Process tables.
    PROCEDURE napp_om_so_populate_final_proc (
        p_quote_number   IN VARCHAR2,
        p_transaction_id IN VARCHAR2,
        p_instance_id    IN VARCHAR2,
        p_record_type    IN VARCHAR2,
        p_status         OUT VARCHAR2
    );

	-- Function to check if the item is Model or option Class
    FUNCTION is_submodel_qty_eligibl_item (
        p_item_number IN VARCHAR2
    ) RETURN VARCHAR2;

    PROCEDURE napp_q2o_validate_proc_db_job_status_proc (
        p_status          OUT VARCHAR2,
        p_completion_flag OUT VARCHAR2,
        p_msg             OUT VARCHAR2,
        p_job_name        IN VARCHAR2
    );

	-- Procedure to check if the linked quote number belongs to EBS Converted Order
    PROCEDURE napp_om_so_conv_order_check_proc (
        p_quote_number           IN VARCHAR2,
        p_linked_quote_number    IN VARCHAR2,
        p_linked_quote_line_id   IN VARCHAR2,
        p_ebs_conv_so_flag       OUT VARCHAR2,
        p_ebs_conv_so_number     OUT VARCHAR2,
        p_ebs_conv_so_status     OUT VARCHAR2,
        p_ebs_conv_so_bu         OUT VARCHAR2, -- V7.7 Added
        p_ebs_conv_so_sc_line_id OUT VARCHAR2,
        p_error                  OUT VARCHAR2
    ); -- Added for V1.6

	-- Proceduere to derive the unique serials for each model
    PROCEDURE napp_om_so_upd_model_serials_proc (
        p_quote_number      IN VARCHAR2,
        p_transaction_id    IN VARCHAR2,
        p_quote_line_id     IN VARCHAR2,
        p_top_model_line_id IN VARCHAR2,
        p_virtual_line_id   IN VARCHAR2,
        p_trx_sub_type      IN VARCHAR2,
        p_serial_numbers    OUT VARCHAR2,
        p_error_message     OUT VARCHAR2
    ); 	-- Added for V2.7

	-- Procedure for real time retry for CMAT issues
    PROCEDURE napp_om_so_realtime_retry_proc (
        p_quote_number       IN VARCHAR2,
        p_transaction_id     IN VARCHAR2,
        p_processing_counter IN NUMBER,
        p_error_code         IN VARCHAR2,
        p_error_msg          IN VARCHAR2
    ); -- Added for V4.2

	-- Procedure for inserting the quote Attachments
    PROCEDURE napp_om_so_populate_attachments_proc (
        p_oic_instance_id IN VARCHAR2,
        p_insert_record   IN napp_om_so_attachments_type,
        p_prc_status      OUT VARCHAR2,
        p_error_msg       OUT VARCHAR2
    ); -- Added for V4.8

	-- Procedure for Updating the quote Attachments
    PROCEDURE napp_om_so_update_attachments_proc (
        p_quote_number          IN VARCHAR2,
        p_transaction_id        IN VARCHAR2,
        p_order_number          IN VARCHAR2,
        p_header_id             IN NUMBER,
        p_source_system         IN VARCHAR2,
        p_source_transaction_id IN VARCHAR2,
        p_prc_status            OUT VARCHAR2,
        p_error_msg             OUT VARCHAR2
    ); -- Added for V4.8

   --Added conditions as part of ADO -910092
    FUNCTION is_tradein_eseries_part (
        p_item_number IN VARCHAR2
    ) RETURN VARCHAR2; -- V6.8 Added conditions as part of ADO -910092

    FUNCTION is_ontap_controller (
        p_item_id NUMBER
    ) RETURN BOOLEAN; -- -- Added for V6.4

    FUNCTION get_headswapped_srn (
        p_serial_number VARCHAR2
    ) RETURN VARCHAR2; -- Added for V6.4

    FUNCTION validate_serialnumber (
        p_serial_number VARCHAR2
    ) RETURN VARCHAR2; -- Added for V6.4

    FUNCTION is_expansion_storage_service (
        p_transaction_id NUMBER,
        p_quote_number   VARCHAR2,
        p_quote_line_id  VARCHAR2
    ) RETURN BOOLEAN; -- Added for V6.4

    	--V7.6 Added conditions as part of ADO - 915236
    PROCEDURE napp_om_so_update_published_flag_proc (
        p_quotes_tab IN napp_om_so_quote_tab,
        p_prc_status OUT VARCHAR2,
        p_error_msg  OUT VARCHAR2
    );

     -- V7.9 Procedure to reprocess QTOP sales orders failed with load interface file for import error
    PROCEDURE napp_qtop_so_load_intf_split_btches_proc (
        p_total_batch_count      IN NUMBER,
        p_batch_sequence_1       IN NUMBER,
        p_batch_sequence_2       IN NUMBER,
        p_integration_identifier IN VARCHAR2,
        p_oic_instance_id        IN VARCHAR2,
        p_parent_source_filename IN VARCHAR2,
        p_prc_status             OUT VARCHAR2,
        p_prc_error_msg          OUT VARCHAR2
    );
    -- V7.9 Procedure to update oicinstanceid in proc tbl for load interface error reprocessing
    PROCEDURE napp_qtop_load_reprs_upd_proc (
        p_quote_data        IN napp_qtop_sales_order_reprocess_tbl_type,
        p_in_status         IN VARCHAR2,
        p_in_batch_sequence IN NUMBER,
        p_oic_instance_id   IN VARCHAR2,
        p_status            OUT VARCHAR2,
        p_error_msg         OUT VARCHAR2
    );

	-- V8.9 record type to hold controller item and warning mesage
    TYPE napp_rtn_cntlr_details IS RECORD (
            controller_item VARCHAR2(300),
            warning_msg     VARCHAR2(32000)
    );

	-- V8.9 Function to check the serial number in 3B2IN table for Trade In Quotes
    FUNCTION rtn_serial_check_3b2in (
        p_serial_number VARCHAR2,
        p_item          VARCHAR2
    ) RETURN napp_rtn_cntlr_details;
    
    -- V9.0 Function to check if the covered item is capacity support
    FUNCTION is_capacity_support (
        p_quote_number VARCHAR2,
        p_item_number  VARCHAR2
    ) RETURN BOOLEAN;
    
    -- V9.0 Procedure to aggregate serials then update SN1/SN2 for a capacity-support line.
    PROCEDURE napp_update_sn_add_info_eff (
        p_quote_line_id      IN VARCHAR2,
        p_quote_number       IN VARCHAR2,
        p_transaction_id     IN VARCHAR2,
        p_linked_ref_line_id IN VARCHAR2,
		p_error_message      OUT VARCHAR2
    );

END napp_q2o_so_process_pkg;