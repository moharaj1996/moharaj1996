create or replace PACKAGE BODY         NAPPERP.napp_om_3b18_salesorder_075_pkg AS
/*******************************************************************************************************
                         NetApp Inc. Sunnyvale California
********************************************************************************************************
File Name : napperp.napp_om_3b18_salesorder_075_pkg.pks
Object Name : 	napperp.napp_om_3b18_salesorder_075_pkg
Description : To extract the serials from  3B2 serial geneology table & to sync napperp.napp_om_3b18_sales_order_details_075_retrofit_stg table
Revision History:
Version     Date         Modified By              Description
--------    ---------    ------------             -----------------------------------------------------
1.0         01-Mar-2025  Sagar Arora              Initial Version
1.1         04-Feb-2026  Amit Kumar               Added check for Duplicate revision issue and Exception handling, INC4438916
1.2         27-Feb-2026  Sagar Arora              Added join for order number in update query for Ci STG1 table, INC4458758
1.3         20-Mar-2026  Sagar Arora              Moved update statement out of for each loop, INC4490422
1.4         20-May-2026  Sagar Arora              Commented GTC Hold exception as part of ADO 936760
1.5         11-Sep-2026  Ashwin Pai               ADO#948669 Added new procedure to insert cancellation records to be sent to old DC for
                                                  manual DC change - as part of Laredo Phase 2 
*******************************************************************************************************/

   --++++++++++++++++++++ DBMS Scheduler Job for master procedure ++++++++++++++++++++--
    PROCEDURE napp_dbms_scheduler_master_procedure (
        p_in_job_name  IN VARCHAR2,
        p_instance_id  IN VARCHAR2,
        p_trigger_mode IN VARCHAR2,
        p_status       OUT VARCHAR2,
        p_message      OUT VARCHAR2
    ) IS

        l_single_quote VARCHAR2(1) := '''';
        l_err_msg      VARCHAR2(4000) := '';
        l_rec_count    NUMBER;
    BEGIN
        dbms_scheduler.create_job(job_name => p_in_job_name, job_type => 'PLSQL_BLOCK', job_action => 'BEGIN

	                          napperp.napp_om_3b18_salesorder_075_pkg.napp_run_master_procedure('
                                                                                                      || l_single_quote
                                                                                                      || p_instance_id
                                                                                                      || l_single_quote
                                                                                                      || ','
                                                                                                      || l_single_quote
                                                                                                      || p_trigger_mode
                                                                                                      || l_single_quote
                                                                                                      || ');

			                END;', start_date => systimestamp, job_class => 'DEFAULT_JOB_CLASS',
                                 enabled => TRUE, auto_drop => TRUE, comments => 'Invoke master procedure');

        SELECT
            COUNT(1)
        INTO l_rec_count
        FROM
            (
                (
                    SELECT
                        state
                    FROM
                        all_scheduler_jobs
                    WHERE
                        job_name = p_in_job_name
                )
                UNION
                (
                    SELECT
                        status
                    FROM
                        all_scheduler_job_run_details
                    WHERE
                        job_name = p_in_job_name
                )
            );

        IF l_rec_count > 0 THEN
            p_status := 'SUCCESS';
            p_message := NULL;
        ELSE
            SELECT
                errors
            INTO l_err_msg
            FROM
                all_scheduler_job_run_details
            WHERE
                job_name = p_in_job_name;

            p_status := 'ERROR';
            p_message := substr(l_err_msg, 1, 4000);
        END IF;

    EXCEPTION
        WHEN OTHERS THEN

         -- Return Error Details if something goes wrong.

            p_status := 'ERROR';
            p_message := substr(sqlerrm, 1, 4000);
    END napp_dbms_scheduler_master_procedure;

 --++++++++++++++++++++ Master Procedure ++++++++++++++++++++--

    PROCEDURE napp_run_master_procedure (
        p_instance_id  IN VARCHAR2,
        p_trigger_mode IN VARCHAR2
    ) IS
    BEGIN
        napperp.napp_om_3b18_salesorder_075_pkg.napp_update_ssd_cancelled_line(p_instance_id);
        napperp.napp_om_3b18_salesorder_075_pkg.napp_update_custom_line_num(p_instance_id);
        napperp.napp_om_3b18_salesorder_075_pkg.napp_get_non_controller_serials(p_instance_id);
        napperp.napp_om_3b18_salesorder_075_pkg.napp_get_controller_serials(p_instance_id);
        --napperp.napp_om_3b18_salesorder_075_pkg.napp_assign_ship_set(p_instance_id);
        napperp.napp_om_3b18_salesorder_075_pkg.napp_update_revision_line_detail(p_instance_id, p_trigger_mode);
        napperp.napp_om_3b18_salesorder_075_pkg.napp_process_dc_change(p_instance_id); --1.5
        napperp.napp_om_3b18_salesorder_075_pkg.napp_purge_abort_error_records(p_instance_id);
    END napp_run_master_procedure;

   --++++++++++++++++++++ Get Controller Serials ++++++++++++++++++++--

    PROCEDURE napp_get_controller_serials (
        p_instance_id IN VARCHAR2
    ) IS

        l_line_id        VARCHAR2(50) := '';
        l_parent_id      VARCHAR2(50) := '';
        l_serial_numbers VARCHAR2(2000) := '';
        CURSOR get_controller_items IS
        SELECT
            header_order_number,
            header_ship_set_num,
            line_item,
            line_number,
            line_line_number,
            line_isconfig,
            line_user_item_type,
            line_lineattribute1,
            line_item_sub_type_code,
            parent_line_id,
            line_line_id,
            root_parent_line_id,
            cust_line_number
        FROM
            napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
        WHERE
                oic_instance_id = p_instance_id
            AND status NOT IN ( 'ABORT', 'ERROR' )
            --AND upper(line_lineattribute1) = 'SYSTEM BASE AND SOFTWARE BUNDLE(ONTAP)'
            AND line_isconfig IN ( 'ATO', 'CTO' )
            AND ( upper(esg_check) NOT LIKE '%ESG%'
                  OR esg_check IS NULL );

        TYPE controller_rec_type IS
            TABLE OF get_controller_items%rowtype INDEX BY BINARY_INTEGER;
        l_controller_rec controller_rec_type;
    BEGIN
        OPEN get_controller_items;
        FETCH get_controller_items
        BULK COLLECT INTO l_controller_rec;
        CLOSE get_controller_items;
        IF l_controller_rec.count > 0 THEN
            FOR i IN 1..l_controller_rec.count LOOP
				--start of changes for 1.1
                BEGIN
                    SELECT
                        nvl(
                            LISTAGG(DISTINCT child_serialnumber, ',') WITHIN GROUP(
                            ORDER BY
                                child_serialnumber
                            ),
                            'No Serials') AS serial
                            --child_item
                    INTO l_serial_numbers
                            --NVL(l_item_number,'No Item')
                    FROM
                        napperp.napp_b2b_serial_genealogy_table
                    WHERE
                            child_item = l_controller_rec(i).line_item
                        AND order_no = l_controller_rec(i).header_order_number
                        AND so_line_number = l_controller_rec(i).cust_line_number;
					--AND rownum < 5;
                EXCEPTION
                    WHEN OTHERS THEN
                        DECLARE
                            l_err_msg VARCHAR2(4000);
                        BEGIN
                            l_err_msg := substr(('Select controller serial number details from 3B2 Serial Geneology Table -'
                                                 || sqlerrm), 1, 4000);
                            l_serial_numbers := NULL;
                            UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg s
                            SET
                                s.status = 'ERROR',
                                s.error_details = l_err_msg
                            WHERE
                                    s.oic_instance_id = p_instance_id
                                AND s.header_order_number = l_controller_rec(i).header_order_number
                                AND ( s.header_ship_set_num = l_controller_rec(i).header_ship_set_num
                                      OR s.header_ship_set_num IS NULL );

                            COMMIT;
                        END;
                END;
                 ---end of changes for 1.1

                --dbms_output.put_line('TEST SERIALS');
                --dbms_output.put_line(concat('SERIALS: ', l_serial_numbers));
                BEGIN
                    IF nvl(l_serial_numbers, 'No Serials') <> 'No Serials' THEN
                        --dbms_output.put_line('SERIALS FECTCHED');
                        UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
                        SET
                            line_serial_numbers = l_serial_numbers
                        WHERE
                                oic_instance_id = p_instance_id
                            AND status NOT IN ( 'ABORT', 'ERROR' )
                            AND header_order_number = l_controller_rec(i).header_order_number
                            AND cust_line_number = l_controller_rec(i).cust_line_number
                            AND upper(line_lineattribute1) IN ( 'SYSTEM BASE AND SOFTWARE BUNDLE(ONTAP)', 'SYSTEM BASE(SANTRICITY)', 'SYSTEM BASE'
                            , 'SYSTEM BASE WITH INTEGRATED STORAGE', 'CONTROLLER' );

                        COMMIT;
                    ELSE
                        --dbms_output.put_line('NO SERIALS FECTCHED');
                        UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
                        SET
                            error_details = ''
                        WHERE
                                oic_instance_id = p_instance_id
                            AND status NOT IN ( 'ABORT', 'ERROR' )
                            AND error_details IS NULL      --- Condition added for Box Label Flag and Printable Flag
                            AND line_line_id = l_controller_rec(i).line_line_id
                            AND root_parent_line_id = l_controller_rec(i).root_parent_line_id;

                        COMMIT;
                    --EXIT; ** Commented due to single model line processing right now, but need all lines **
                    END IF;
				--start of changes 1.1.
                EXCEPTION
                    WHEN OTHERS THEN
                        ROLLBACK;
                        DECLARE
                            l_err_msg VARCHAR2(4000);
                        BEGIN
                            l_err_msg := substr(('Update controller serial number details from 3B2 Serial Geneology Table - '
                                                 || sqlerrm), 1, 4000);
                            UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg s
                            SET
                                s.status = 'ERROR',
                                s.error_details = l_err_msg
                            WHERE
                                    s.oic_instance_id = p_instance_id
                                AND s.header_order_number = l_controller_rec(i).header_order_number
                                AND ( s.header_ship_set_num = l_controller_rec(i).header_ship_set_num
                                      OR s.header_ship_set_num IS NULL );

                            COMMIT;
                        END;

                END;
			  --End of changes 1.1
            END LOOP;
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
           -- add_order_ship_error(p_order_number => NULL, p_ship_set => NULL, p_step => 'BATCH_FATAL for napperp.napp_get_controller_serials', p_msg => sqlerrm);
    END napp_get_controller_serials;

    --++++++++++++++++++++ Non Controller Serials ++++++++++++++++++++--
    PROCEDURE napp_get_non_controller_serials (
        p_instance_id IN VARCHAR2
    ) IS

        l_serial_numbers     VARCHAR2(4000) := '';
        l_esg_check          VARCHAR2(50) := '';
        CURSOR non_controller_items IS
        SELECT
            header_order_number,
            header_ship_set_num,
            line_item,
            line_number,
            line_line_number,
            line_isconfig,
            line_user_item_type,
            line_lineattribute1,
            line_item_sub_type_code,
            parent_line_id,
            line_line_id,
            root_parent_line_id,
            esg_check,
            cust_line_number
        FROM
            napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
        WHERE
                oic_instance_id = p_instance_id
            AND status NOT IN ( 'ABORT', 'ERROR' )
            AND line_isconfig IN ( 'ATO', 'CTO' );
            /*AND ( ( upper(line_lineattribute1) LIKE '%SHELF%'
                    OR upper(line_lineattribute1) LIKE '%SWITCH%' )
                  OR ( upper(esg_check) NOT LIKE '%ESG%'
                       OR esg_check IS NULL ) );*/

        TYPE non_controller_type IS
            TABLE OF non_controller_items%rowtype INDEX BY BINARY_INTEGER;
        l_non_controller_rec non_controller_type;
    BEGIN
        OPEN non_controller_items;
        FETCH non_controller_items
        BULK COLLECT INTO l_non_controller_rec;
        CLOSE non_controller_items;
        IF l_non_controller_rec.count > 0 THEN
            l_esg_check := '';
            FOR i IN 1..l_non_controller_rec.count LOOP
                --dbms_output.put_line('INSIDE LOOP');
				--start of changes 1.1
                BEGIN
                    SELECT DISTINCT
                        esg_check
                    INTO l_esg_check
                    FROM
                        napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
                    WHERE
                            line_line_id = l_non_controller_rec(i).root_parent_line_id
                        AND oic_instance_id = p_instance_id;
                    --AND status <> 'ABORT';
                EXCEPTION
                    WHEN OTHERS THEN
                        DECLARE
                            l_err_msg VARCHAR2(4000);
                        BEGIN
                            l_err_msg := substr(('Select esg check value for line item for non controller items'
                                                 || sqlerrm), 1, 4000);
                            l_esg_check := NULL;
                            UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg s
                            SET
                                s.status = 'ERROR',
                                s.error_details = l_err_msg
                            WHERE
                                    s.oic_instance_id = p_instance_id
                                AND s.header_order_number = l_non_controller_rec(i).header_order_number
                                AND ( s.header_ship_set_num = l_non_controller_rec(i).header_ship_set_num
                                      OR s.header_ship_set_num IS NULL );

                            COMMIT;
                        END;
                END;
				 --end of changes 1.1
                --dbms_output.put_line(l_esg_check);
                IF (
                    l_esg_check LIKE '%ESG%'
                    AND upper(l_non_controller_rec(i).line_lineattribute1) LIKE '%CONTROLLER%'
                ) OR (
                    l_esg_check IS NULL
                    AND ( upper(l_non_controller_rec(i).line_lineattribute1) LIKE '%SHELF%' OR upper(l_non_controller_rec(i).line_lineattribute1
                    ) LIKE '%SWITCH%' )
                ) OR (
                    l_esg_check NOT LIKE '%ESG%'
                    AND ( upper(l_non_controller_rec(i).line_lineattribute1) LIKE '%SHELF%' OR upper(l_non_controller_rec(i).line_lineattribute1
                    ) LIKE '%SWITCH%' )
                ) THEN
                    --dbms_output.put_line('INSIDE IF');
                    --dbms_output.put_line(l_non_controller_rec(i).line_item);
					--start of changes 1.1
                    BEGIN
                        SELECT
                            nvl(
                                LISTAGG(child_serialnumber, ',') WITHIN GROUP(
                                ORDER BY
                                    child_serialnumber
                                ),
                                'No Serials') AS serial
                    --child_item
                        INTO l_serial_numbers
                    --l_item_number
                        FROM
                            napperp.napp_b2b_serial_genealogy_table
                        WHERE
                                child_item = l_non_controller_rec(i).line_item
                            AND order_no = l_non_controller_rec(i).header_order_number
                            AND so_line_number = l_non_controller_rec(i).cust_line_number;

                    EXCEPTION
                        WHEN OTHERS THEN
                            DECLARE
                                l_err_msg VARCHAR2(4000);
                            BEGIN
                                l_err_msg := substr(('Select non controller serial number details from 3B2 Serial Geneology Table - '
                                                     || sqlerrm), 1, 4000);
                                l_serial_numbers := NULL;
                                UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg s
                                SET
                                    s.status = 'ERROR',
                                    s.error_details = l_err_msg
                                WHERE
                                        s.oic_instance_id = p_instance_id
                                    AND s.header_order_number = l_non_controller_rec(i).header_order_number
                                    AND ( s.header_ship_set_num = l_non_controller_rec(i).header_ship_set_num
                                          OR s.header_ship_set_num IS NULL );

                                COMMIT;
                            END;
                    END;
                      ---end of changes 1.1
                    BEGIN
                        IF nvl(l_serial_numbers, 'No Serials') <> 'No Serials' THEN
                            --dbms_output.put_line('serial found');
                            UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
                            SET
                                line_serial_numbers = l_serial_numbers
                            WHERE
                                    oic_instance_id = p_instance_id
                            --AND status <> 'ABORT'
                                AND line_line_id = l_non_controller_rec(i).line_line_id
                                AND root_parent_line_id = l_non_controller_rec(i).root_parent_line_id;

                            COMMIT;
                        ELSE
                            --dbms_output.put_line('no serial');
                            UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
                            SET
                                error_details = ''
                            WHERE
                                    oic_instance_id = p_instance_id
                                AND status NOT IN ( 'ABORT', 'ERROR' )
                                AND error_details IS NULL       --- Condition added for Box Label Flag and Printable Flag
                                AND line_line_id = l_non_controller_rec(i).line_line_id
                                AND root_parent_line_id = l_non_controller_rec(i).root_parent_line_id;

                            COMMIT;
                        END IF;

                    EXCEPTION
                        WHEN OTHERS THEN
                            ROLLBACK;
                            DECLARE
                                l_err_msg VARCHAR2(4000);
                            BEGIN
                                l_err_msg := substr(('Update non controller serial number details from 3B2 Serial Geneology Table - '
                                                     || sqlerrm), 1, 4000);
                                UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg s
                                SET
                                    s.status = 'ERROR',
                                    s.error_details = l_err_msg
                                WHERE
                                        s.oic_instance_id = p_instance_id
                                    AND s.header_order_number = l_non_controller_rec(i).header_order_number
                                    AND ( s.header_ship_set_num = l_non_controller_rec(i).header_ship_set_num
                                          OR s.header_ship_set_num IS NULL );

                                COMMIT;
                            END;

                    END;

                END IF;

            END LOOP;

        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;
           -- add_order_ship_error(p_order_number => NULL, p_ship_set => NULL, p_step => 'BATCH_FATAL for napperp.napp_get_non_controller_serials', p_msg => sqlerrm);
    END napp_get_non_controller_serials;

   -- ++++++++++++++++++++++ Custome line number procedure ++++++++++++++++++++++
    PROCEDURE napp_update_custom_line_num (
        p_instance_id IN VARCHAR2
    ) IS

        CURSOR get_custom_line_number IS
        SELECT
            so_number,
            linenumber_sl,
            productidentificationproprietaryproductidentifier1_sl,
            documentlinereferencesourcelinenumber,
            solinenumvalidation,
            so_line_id,
            so_parent_line_id,
            additional_info3,
            comments
        FROM
            napperp.napp_p2p_3a4_master_records
        WHERE
            so_number IN (
                SELECT DISTINCT
                    header_order_number
                FROM
                    napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
                WHERE
                        oic_instance_id = p_instance_id
                    AND status NOT IN ( 'ABORT', 'ERROR' )
            );

        TYPE custom_line_type IS
            TABLE OF get_custom_line_number%rowtype INDEX BY BINARY_INTEGER;
        l_custom_line custom_line_type;
    BEGIN
        OPEN get_custom_line_number;
        FETCH get_custom_line_number
        BULK COLLECT INTO l_custom_line;
        CLOSE get_custom_line_number;
        IF l_custom_line.count > 0 THEN
            FOR i IN 1..l_custom_line.count LOOP
                BEGIN
                    UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
                    SET
                        cust_line_number = (
                            CASE
                                WHEN ( ( l_custom_line(i).so_line_id = l_custom_line(i).so_parent_line_id
                                         OR l_custom_line(i).comments = 'QS'
                                         AND l_custom_line(i).so_parent_line_id IS NULL )
                                       AND l_custom_line(i).additional_info3 NOT LIKE '%EBS%' ) THEN
                                    ( l_custom_line(i).linenumber_sl
                                      || '.1' )
                                ELSE
                                    l_custom_line(i).linenumber_sl
                            END
                        )
                    WHERE
                            line_line_id = l_custom_line(i).so_line_id
                        AND status NOT IN ( 'ABORT', 'ERROR' )
                        AND line_isconfig IN ( 'ATO', 'CTO' )
                        AND oic_instance_id = p_instance_id;

                    COMMIT;
                EXCEPTION
                    WHEN OTHERS THEN
                        ROLLBACK;
                        DECLARE
                            l_err_msg VARCHAR2(4000);
                        BEGIN
                            l_err_msg := substr(('Update custom line number fro 3A4 table - '
                                                 || sqlerrm), 1, 4000);
                            UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg s
                            SET
                                s.status = 'ERROR',
                                s.error_details = l_err_msg
                            WHERE
                                    s.oic_instance_id = p_instance_id
                                AND s.header_order_number = l_custom_line(i).so_number;

                            COMMIT;
                        END;

                END;
            END LOOP;
        END IF;

        BEGIN
            UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
            SET
                cust_line_number = custom_line_number
            WHERE
                cust_line_number IS NULL
                AND status NOT IN ( 'ABORT', 'ERROR' )
                AND oic_instance_id = p_instance_id;

            COMMIT;
        EXCEPTION
            WHEN OTHERS THEN
                ROLLBACK;
                dbms_output.put_line('Error in custom line number update for non CTO Lines ' || sqlerrm);
        END;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            dbms_output.put_line('Error in napperp.napp_update_custom_line_num ' || sqlerrm);
            RAISE;
    END napp_update_custom_line_num;

	--++++++++++++++++++++ Update Revision Number ++++++++++++++++++++--
    PROCEDURE napp_update_revision_line_detail (
        p_instance_id  IN VARCHAR2,
        p_trigger_mode IN VARCHAR2
    ) IS

        CURSOR get_max_revision_number IS
        SELECT
            so_stg.header_order_number,
            greatest(MAX(so_stg.order_revision_no),
                     MAX(ci1_stg.ci_revision)) ci_revision
        FROM
            napperp.napp_om_so_ci1_stg                                ci1_stg,
            napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_stg
        WHERE
                1 = 1
            --AND so_stg.oic_instance_id <> p_instance_id
            AND so_stg.header_header_id = ci1_stg.header_header_id
            AND so_stg.line_line_id = ci1_stg.line_line_id
            AND so_stg.oic_instance_id = ci1_stg.oic_instance_id
            AND ci1_stg.ci_revision IS NOT NULL
            AND so_stg.order_revision_no IS NOT NULL
            AND so_stg.header_order_number IN (
                SELECT
                    header_order_number
                FROM
                    napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
                WHERE
                    oic_instance_id = p_instance_id
            )
        GROUP BY
            so_stg.header_order_number;

        TYPE max_revision_type IS
            TABLE OF get_max_revision_number%rowtype INDEX BY BINARY_INTEGER;
        l_max_revision  max_revision_type;
        CURSOR get_latest_line_number IS
        SELECT
            header_order_number,
            header_header_id,
            header_ship_set_num,
            line_item,
            line_promise_date,
            line_quantity,
            line_hold_name,
            line_serial_numbers,
            header_shipping_instructions,
            order_revision_no,
            parent_line_id,
            line_line_id,
            root_parent_line_id,
            COUNT(*)
            OVER(PARTITION BY header_header_id, header_ship_set_num) number_of_lines
        FROM
            napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
        WHERE
                oic_instance_id = p_instance_id
            AND header_ship_set_num IS NOT NULL;

        TYPE latest_line_type IS
            TABLE OF get_latest_line_number%rowtype INDEX BY BINARY_INTEGER;
        l_latest_line   latest_line_type;

		---Changes done as part of INC4490422
        CURSOR get_distinct_ship_set IS
        SELECT
            so_stg1.header_order_number,
            so_stg1.header_header_id,
            so_stg1.header_ship_set_num
        FROM
            napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_stg1
        WHERE
                1 = 1
            AND so_stg1.oic_instance_id = p_instance_id
            AND so_stg1.header_ship_set_num IS NOT NULL
        GROUP BY
            so_stg1.header_order_number,
            so_stg1.header_header_id,
            so_stg1.header_ship_set_num;

        TYPE distinct_ship_set IS
            TABLE OF get_distinct_ship_set%rowtype INDEX BY BINARY_INTEGER;
        l_ship_set      distinct_ship_set;
		---Changes done as part of INC4490422

		---start of 1.1 changes
        CURSOR get_duplicate_revision (
            p_instance_id IN VARCHAR2
        ) IS
        SELECT DISTINCT
            header_order_number,
            header_ship_set_num,
            order_revision_no
        FROM
            (
                SELECT DISTINCT
                    nosodr.header_order_number,
                    nosodr.header_ship_set_num,
                    nosodr.order_revision_no,
                    nosodr.line_line_id,
                    nosodr.status
                FROM
                    napperp.napp_om_3b18_sales_order_details_075_retrofit_stg nosodr
                WHERE
                        1 = 1
                    AND upper(nosodr.status) IN ( 'IN PROGRESS' )
                    AND nosodr.header_order_number IN (
                        SELECT DISTINCT
                            header_order_number
                        FROM
                            napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
                        WHERE
                                oic_instance_id = p_instance_id
                            AND upper(status) IN ( 'IN PROGRESS' )
                    )
                GROUP BY
                    nosodr.header_order_number,
                    nosodr.header_ship_set_num,
                    nosodr.order_revision_no,
                    nosodr.status,
                    nosodr.line_line_id
                HAVING
                    COUNT(*) > 1
            ) a;

        CURSOR get_ci_new_status_lines IS
        SELECT
            ci1_stg.header_order_number,
            ci1_stg.header_header_id,
            ci1_stg.line_shippable_set,
            ci1_stg.oic_instance_id
        FROM
            napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_stg,
            napperp.napp_om_so_ci1_stg                                ci1_stg
        WHERE
                1 = 1
            AND so_stg.oic_instance_id <> p_instance_id
            AND so_stg.header_ship_set_num IS NOT NULL
            AND so_stg.header_header_id = ci1_stg.header_header_id
            AND so_stg.line_line_id = ci1_stg.line_line_id
            AND so_stg.oic_instance_id = ci1_stg.oic_instance_id
            AND ci1_stg.ci_revision IS NOT NULL
            AND so_stg.order_revision_no IS NOT NULL
            AND upper(so_stg.status) IN ( 'ABORT', 'ERROR' )
            AND ci1_stg.status = 'NEW'
            AND so_stg.header_order_number IN (
                SELECT
                    header_order_number
                FROM
                    napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
                WHERE
                    oic_instance_id = p_instance_id
            )
        GROUP BY
            ci1_stg.header_order_number,
            ci1_stg.header_header_id,
            ci1_stg.line_shippable_set,
            ci1_stg.oic_instance_id;

        TYPE ci_new_status_type IS
            TABLE OF get_ci_new_status_lines%rowtype INDEX BY BINARY_INTEGER;
        l_ci_new_status ci_new_status_type;
----
    BEGIN
	------Update Revision Number for each line of current instance run-----
        OPEN get_max_revision_number;
        FETCH get_max_revision_number
        BULK COLLECT INTO l_max_revision;
        CLOSE get_max_revision_number;
        IF l_max_revision.count > 0 THEN
            FOR i IN l_max_revision.first..l_max_revision.last LOOP
                BEGIN
			--LOOP
                    UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_3b18_stg
                    SET
                        order_revision_no = l_max_revision(i).ci_revision + 1,
                        so_3b18_stg.header_attribute3 = (
                            CASE
                                WHEN l_max_revision(i).ci_revision > 0
                                     AND p_trigger_mode IS NULL THEN
                                    'U'   --- Use case where somebody updated SSD to out of 7 day window, still GTM needs to screen that record
                                ELSE
                                    p_trigger_mode
                            END
                        )
                    WHERE
                            1 = 1
                        AND so_3b18_stg.oic_instance_id = p_instance_id
                        AND so_3b18_stg.header_order_number = l_max_revision(i).header_order_number;

                    COMMIT;
                    UPDATE napperp.napp_om_so_ci1_stg so_ci1_stg
                    SET
                        ci_revision = l_max_revision(i).ci_revision + 1
                    WHERE
                            1 = 1
                        AND so_ci1_stg.oic_instance_id = p_instance_id
                        AND so_ci1_stg.header_order_number = l_max_revision(i).header_order_number;

                    COMMIT;
                EXCEPTION
                    WHEN OTHERS THEN
                        ROLLBACK;
                        DECLARE
                            l_err_msg VARCHAR2(4000);
                        BEGIN
                            l_err_msg := substr(('Update max revision in 3B18 and CI STG1 table - '
                                                 || sqlerrm), 1, 4000);
                            UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg s
                            SET
                                s.status = 'ERROR',
                                s.error_details = l_err_msg
                            WHERE
                                    s.oic_instance_id = p_instance_id
                                AND s.header_order_number = l_max_revision(i).header_order_number;

                            COMMIT;
                        END;

                END;
            END LOOP;
        END IF;
		--start of changes 1.1

        FOR recs IN get_duplicate_revision(p_instance_id) LOOP
            BEGIN
                UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg x
                SET
                    x.order_revision_no = recs.order_revision_no + 1
                WHERE
                        1 = 1
                    AND upper(x.status) IN ( 'IN PROGRESS' )
                    AND ( x.oic_instance_id, x.header_order_number ) IN (
                        SELECT DISTINCT
                            FIRST_VALUE(oic_instance_id)
                            OVER(PARTITION BY header_order_number
                                 ORDER BY
                                     creation_date DESC
                            ) latest_instance, header_order_number
                        FROM
                            napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
                        WHERE
                                1 = 1
                            AND upper(status) IN ( 'IN PROGRESS' )
                            AND header_order_number = recs.header_order_number
                    );

                COMMIT;
				-----
                UPDATE napperp.napp_om_so_ci1_stg so_ci1_stg
                SET
                    ci_revision = recs.order_revision_no + 1
                WHERE
                        1 = 1
                    AND ( so_ci1_stg.oic_instance_id, so_ci1_stg.header_order_number ) IN (
                        SELECT DISTINCT
                            FIRST_VALUE(oic_instance_id)
                            OVER(PARTITION BY header_order_number
                                 ORDER BY
                                     creation_date DESC
                            ) latest_instance, header_order_number
                        FROM
                            napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
                        WHERE
                                1 = 1
                            AND upper(status) IN ( 'IN PROGRESS' )
                            AND header_order_number = recs.header_order_number
                    );

                COMMIT;
            EXCEPTION
                WHEN OTHERS THEN
                    ROLLBACK;
                    DECLARE
                        l_err_msg VARCHAR2(4000);
                    BEGIN
                        l_err_msg := substr(('Update duplicate revision in 3B18 and CI STG1 table - '
                                             || sqlerrm), 1, 4000);
                        UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg s
                        SET
                            s.status = 'ERROR',
                            s.error_details = l_err_msg
                        WHERE
                                s.oic_instance_id = p_instance_id
                            AND s.header_order_number = recs.header_order_number
                            AND ( s.header_ship_set_num = recs.header_ship_set_num
                                  OR s.header_ship_set_num IS NULL );

                        COMMIT;
                    END;

            END;
        END LOOP;

		---end of changes 1.1

		------Update all older versions to abort status-----

        OPEN get_latest_line_number;
        FETCH get_latest_line_number
        BULK COLLECT INTO l_latest_line;
        CLOSE get_latest_line_number;
        IF l_latest_line.count > 0 THEN
            FOR i IN l_latest_line.first..l_latest_line.last LOOP
                BEGIN
			--LOOP
                    UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_3b18_stg2
                    SET
                        status = 'ABORT',
                        error_details = 'Latest revision with updates found for this order.'
                    WHERE
                            1 = 1
                        AND so_3b18_stg2.oic_instance_id != p_instance_id
                        AND so_3b18_stg2.header_header_id = l_latest_line(i).header_header_id
                        AND so_3b18_stg2.header_ship_set_num = l_latest_line(i).header_ship_set_num
                        AND upper(so_3b18_stg2.status) NOT IN ( 'SUCCESS', 'ABORT', 'ERROR' )
                        AND ( p_trigger_mode IS NOT NULL
                              OR EXISTS (
                            SELECT
                                1
                            FROM
                                napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_3b18_stg3
                            WHERE
                                    1 = 1
                                AND so_3b18_stg3.header_header_id = l_latest_line(i).header_header_id
                                AND so_3b18_stg3.line_line_id = l_latest_line(i).line_line_id
                                AND so_3b18_stg3.header_ship_set_num = l_latest_line(i).header_ship_set_num
                                AND so_3b18_stg3.oic_instance_id != p_instance_id
                                AND ( upper(so_3b18_stg3.status) NOT IN ( 'SUCCESS', 'ABORT', 'ERROR' )
                                      AND ( so_3b18_stg3.line_promise_date != l_latest_line(i).line_promise_date
                                            OR so_3b18_stg3.line_quantity != l_latest_line(i).line_quantity
                                            OR ( nvl(so_3b18_stg3.line_hold_name, 'NULL') != nvl(l_latest_line(i).line_hold_name,
                                                                                                     'NULL')
                                                -- AND nvl(so_3b18_stg3.line_hold_name, 'NULL') <> 'GTC EPCI/HR Hold'     --Commented as part of ADO 936760
												 )
                                            OR nvl(so_3b18_stg3.header_shipping_instructions, 'NULL') != nvl(l_latest_line(i).header_shipping_instructions
                                            ,
                                                                                                             'NULL')
                                            OR nvl(so_3b18_stg3.line_serial_numbers, 'NULL') != nvl(l_latest_line(i).line_serial_numbers
                                            ,
                                                                                                    'NULL') ) )
                        )
                              OR l_latest_line(i).number_of_lines != (
                            SELECT
                                COUNT(*)
                            FROM
                                napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_3b18_stg4
                            WHERE
                                    1 = 1
                                AND so_3b18_stg4.header_header_id = l_latest_line(i).header_header_id
                                AND so_3b18_stg4.header_ship_set_num = l_latest_line(i).header_ship_set_num
                                AND so_3b18_stg4.oic_instance_id != p_instance_id
                                AND upper(so_3b18_stg4.status) NOT IN ( 'SUCCESS', 'ABORT', 'ERROR' )
                        ) );

                    COMMIT;
                EXCEPTION
                    WHEN OTHERS THEN
                        ROLLBACK;
                        DECLARE
                            l_err_msg VARCHAR2(4000);
                        BEGIN
                            l_err_msg := substr(('Update status as abort in 3B18 and CI STG1 table for older revisions - '
                                                 || sqlerrm), 1, 4000);
                            UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg s
                            SET
                                s.status = 'ERROR',
                                s.error_details = l_err_msg
                            WHERE
                                    s.oic_instance_id = p_instance_id
                                AND s.header_order_number = l_latest_line(i).header_order_number
                                AND ( s.header_ship_set_num = l_latest_line(i).header_ship_set_num
                                      OR s.header_ship_set_num IS NULL );

                            COMMIT;
                        END;

                END;
            END LOOP;
        END IF;

			--start of changes 1.3 (Below update statement was present inside the for each loop before, corrected it by moving it outside), INC4490422
				------Update Error Details if no update found in latest version-----
        OPEN get_distinct_ship_set;
        FETCH get_distinct_ship_set
        BULK COLLECT INTO l_ship_set;
        CLOSE get_distinct_ship_set;
        IF l_ship_set.count > 0 THEN
            FOR i IN l_ship_set.first..l_ship_set.last LOOP
                BEGIN
                    UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_3b18_stg4
                    SET
                        status = 'ABORT',
                        error_details = 'No updated value found in latest revision.'
                    WHERE
                            1 = 1
                        AND so_3b18_stg4.oic_instance_id = p_instance_id
                        AND so_3b18_stg4.header_header_id = l_ship_set(i).header_header_id
                        AND so_3b18_stg4.header_ship_set_num = l_ship_set(i).header_ship_set_num
                        AND p_trigger_mode IS NULL
                        AND EXISTS (
                            SELECT
                                1
                            FROM
                                napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_3b18_stg5
                            WHERE
                                    1 = 1
                                AND so_3b18_stg5.oic_instance_id != p_instance_id
                                --AND so_3b18_stg5.line_line_id = so_3b18_stg4.line_line_id
                                AND so_3b18_stg5.header_header_id = so_3b18_stg4.header_header_id
                                AND so_3b18_stg5.header_ship_set_num = so_3b18_stg4.header_ship_set_num
                                AND upper(so_3b18_stg5.status) NOT IN ( 'ABORT', 'SUCCESS', 'ERROR' )
                        );

                    COMMIT;
                EXCEPTION
                    WHEN OTHERS THEN
                        ROLLBACK;
                        DECLARE
                            l_err_msg VARCHAR2(4000);
                        BEGIN
                            l_err_msg := substr(('Update status as abort in 3B18 and CI STG1 table for curent revision - '
                                                 || sqlerrm), 1, 4000);
                            UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg s
                            SET
                                s.status = 'ERROR',
                                s.error_details = l_err_msg
                            WHERE
                                    s.oic_instance_id = p_instance_id
                                AND s.header_order_number = l_ship_set(i).header_order_number
                                AND ( s.header_ship_set_num = l_ship_set(i).header_ship_set_num
                                      OR s.header_ship_set_num IS NULL );

                            COMMIT;
                        END;

                END;
            END LOOP;
        END IF;
	----- end of change 1.3, INC4490422

	-------- Changes done for INC4458758 -------------------

        OPEN get_ci_new_status_lines;
        FETCH get_ci_new_status_lines
        BULK COLLECT INTO l_ci_new_status;
        CLOSE get_ci_new_status_lines;
        IF l_ci_new_status.count > 0 THEN
            FOR i IN l_ci_new_status.first..l_ci_new_status.last LOOP
                BEGIN
                    UPDATE napperp.napp_om_so_ci1_stg ci1_1
                    SET
                        status = 'A',
                        error_details = 'Latest revision with updates found for this order.'
                    WHERE
                            1 = 1
                        AND upper(ci1_1.status) = 'NEW'
                        AND ci1_1.header_header_id = l_ci_new_status(i).header_header_id
                        AND ci1_1.line_shippable_set = l_ci_new_status(i).line_shippable_set
                        AND ci1_1.oic_instance_id = l_ci_new_status(i).oic_instance_id;

                    COMMIT;
                EXCEPTION
                    WHEN OTHERS THEN
                        ROLLBACK;
                        DECLARE
                            l_err_msg VARCHAR2(4000);
                        BEGIN
                            l_err_msg := substr(('Update status as abort CI STG1 table where status is New - '
                                                 || sqlerrm), 1, 4000);
                            UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg s
                            SET
                                s.status = 'ERROR',
                                s.error_details = l_err_msg
                            WHERE
                                    s.oic_instance_id = p_instance_id
                                AND s.header_order_number = l_ci_new_status(i).header_order_number
                                AND ( s.header_ship_set_num = l_ci_new_status(i).line_shippable_set
                                      OR s.header_ship_set_num IS NULL );

                            COMMIT;
                        END;

                END;
            END LOOP;
        END IF;

		-------- Changes done for INC4458758 -------------------

		------------ Update B2B Record for Aborted records----------
        UPDATE napperp.napp_b2b_console_header_tbl
        SET
            status = 'E',
            error_message = 'This revision has been aborted. Latest revision with updates found for this order.'
        WHERE
            trd_id IN (
                SELECT DISTINCT
                    so_3b18_stg7.trd_id
                FROM
                    napperp.napp_b2b_console_header_tbl                       b2b_hdr1, napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_3b18_stg7
                WHERE
                        1 = 1
                    AND b2b_hdr1.document_number = so_3b18_stg7.header_order_number
                    AND b2b_hdr1.trd_id = so_3b18_stg7.trd_id
                    AND b2b_hdr1.status = 'I'
                    AND so_3b18_stg7.status = 'ABORT'
            );

        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            dbms_output.put_line('Error in napperp.napp_update_revision_line_detail' || sqlerrm);
            RAISE;
    END napp_update_revision_line_detail;

-- ++++++++++++++++++++++ Assign SSD to Cancelled Line procedure ++++++++++++++++++++++
    PROCEDURE napp_update_ssd_cancelled_line (
        p_instance_id IN VARCHAR2
    ) IS

        CURSOR get_ssd_cancelled_line IS
        SELECT DISTINCT
            a.header_order_number,
            a.header_ship_set_num,
            a.header_header_id,
            a.line_line_id,
            a.line_promise_date,
            a.line_request_date,
            a.header_carrier,
            a.header_transport_mode,
            a.header_service_type,
            d.line_scheduled_ship_date
        FROM
            napperp.napp_om_3b18_sales_order_details_075_retrofit_stg a,
            napperp.napp_om_so_ci1_stg                                d
        WHERE
                1 = 1
            AND EXISTS (
                SELECT
                    1
                FROM
                    napperp.napp_om_3b18_sales_order_details_075_retrofit_stg b
                WHERE
                        1 = 1
                    AND b.oic_instance_id = p_instance_id
                    AND b.header_header_id = a.header_header_id
                    AND b.line_line_id = a.line_line_id
                    AND b.line_cancelled_status = 'Cancelled'
                    AND b.line_promise_date IS NULL
            )
            AND a.line_promise_date IS NOT NULL
            AND a.header_carrier IS NOT NULL
            AND a.oic_instance_id <> p_instance_id
            AND a.order_revision_no = (
                SELECT
                    nvl(MAX(c.order_revision_no),
                        1)
                FROM
                    napperp.napp_om_3b18_sales_order_details_075_retrofit_stg c
                WHERE
                        1 = 1
                    AND a.header_header_id = c.header_header_id
                    AND a.line_line_id = c.line_line_id
                    AND c.oic_instance_id <> p_instance_id
                    AND c.status NOT IN ( 'ERROR' )
                    AND c.line_promise_date IS NOT NULL
                    AND c.header_carrier IS NOT NULL
                    AND c.order_revision_no IS NOT NULL
            )
            AND a.header_header_id = d.header_header_id
            AND a.line_line_id = d.line_line_id
            AND a.oic_instance_id = d.oic_instance_id;

        TYPE ssd_cancelled_lines IS
            TABLE OF get_ssd_cancelled_line%rowtype INDEX BY BINARY_INTEGER;
        l_sdd_cancelled_line ssd_cancelled_lines;
    BEGIN
        OPEN get_ssd_cancelled_line;
        FETCH get_ssd_cancelled_line
        BULK COLLECT INTO l_sdd_cancelled_line;
        CLOSE get_ssd_cancelled_line;
        IF l_sdd_cancelled_line.count > 0 THEN
            FOR i IN l_sdd_cancelled_line.first..l_sdd_cancelled_line.last LOOP
                BEGIN
					------Update SSD for cancelled lines-----
                    UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_3b18
                    SET
                        so_3b18.line_promise_date = l_sdd_cancelled_line(i).line_promise_date,
                        so_3b18.line_request_date = l_sdd_cancelled_line(i).line_request_date,
                        so_3b18.header_carrier = l_sdd_cancelled_line(i).header_carrier,
                        so_3b18.header_transport_mode = l_sdd_cancelled_line(i).header_transport_mode,
                        so_3b18.header_service_type = l_sdd_cancelled_line(i).header_service_type
                    WHERE
                            1 = 1
                        AND so_3b18.oic_instance_id = p_instance_id
                        AND so_3b18.header_header_id = l_sdd_cancelled_line(i).header_header_id
                        AND so_3b18.line_line_id = l_sdd_cancelled_line(i).line_line_id
                        AND so_3b18.line_cancelled_status = 'Cancelled';

                    COMMIT;

					--- Update CI stg1 table SSD-----	
                    UPDATE napperp.napp_om_so_ci1_stg ci_stg
                    SET
                        ci_stg.line_scheduled_ship_date = l_sdd_cancelled_line(i).line_scheduled_ship_date
                    WHERE
                            1 = 1
                        AND ci_stg.oic_instance_id = p_instance_id
                        AND ci_stg.header_header_id = l_sdd_cancelled_line(i).header_header_id
                        AND ci_stg.line_line_id = l_sdd_cancelled_line(i).line_line_id
                        AND ci_stg.line_scheduled_ship_date IS NULL;

                    COMMIT;
                EXCEPTION
                    WHEN OTHERS THEN
                        ROLLBACK;
                        DECLARE
                            l_err_msg VARCHAR2(4000);
                        BEGIN
                            l_err_msg := substr(('Update ssd for cancelled line in 3B18 and CI STG1 table - '
                                                 || sqlerrm), 1, 4000);
                            UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg s
                            SET
                                s.status = 'ERROR',
                                s.error_details = l_err_msg
                            WHERE
                                    s.oic_instance_id = p_instance_id
                                AND s.header_order_number = l_sdd_cancelled_line(i).header_order_number
                                AND ( s.header_ship_set_num = l_sdd_cancelled_line(i).header_ship_set_num
                                      OR s.header_ship_set_num IS NULL );

                            COMMIT;
                        END;

                END;
            END LOOP;
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            dbms_output.put_line('Error in napperp.napp_update_ssd_cancelled_line' || sqlerrm);
            RAISE;
			--add_order_ship_error(p_order_number => NULL, p_ship_set => NULL, p_step => 'BATCH_FATAL for napperp.napp_update_ssd_cancelled_line', p_msg => sqlerrm);
    END napp_update_ssd_cancelled_line;

--++++++++++++++++++++ Insert DC Change cancellation records ++++++++++++++++++++--v1.5
    PROCEDURE napp_process_dc_change (
    p_instance_id IN VARCHAR2
    )
    IS
        CURSOR cur_current_shipsets IS
            SELECT DISTINCT
                   header_header_id,
                   header_order_number,
                   header_ship_set_num,
                   dunsplus4,
                   header_location_identifier,
                   line_line_id
            FROM napp_om_3b18_sales_order_details_075_retrofit_stg
            WHERE oic_instance_id = p_instance_id
              AND NVL(status,'X') NOT IN ('SUCCESS','ABORT','ERROR');


        l_old_dunsplus4         VARCHAR2(50);
        l_old_location          VARCHAR2(200);
        l_duplicate_count       NUMBER;
        l_prev_record_found     BOOLEAN := FALSE;
        l_cancel_rec napp_om_3b18_sales_order_details_075_retrofit_stg%ROWTYPE;
        l_cancel_rec_CI1 napp_om_so_ci1_stg%ROWTYPE;
        l_cancel_rec_CI2 napp_om_so_ci2_stg%ROWTYPE;
    BEGIN

        FOR rec_current IN cur_current_shipsets LOOP

            /*
             * Find the previously 3B18 sent DC for the same Order/Shipset
             * where DC/location is different from the current record.
             */

            BEGIN

                SELECT dunsplus4,
                       header_location_identifier
                INTO   l_old_dunsplus4,
                       l_old_location      
                FROM
                (
                    SELECT dunsplus4,
                           header_location_identifier
                    FROM napp_om_3b18_sales_order_details_075_retrofit_stg
                    WHERE header_header_id = rec_current.header_header_id
                      AND header_ship_set_num = rec_current.header_ship_set_num
                      AND sent_to_dc_flag = 'Y'
                      AND dunsplus4 <> rec_current.dunsplus4
                      AND header_location_identifier <>
                          rec_current.header_location_identifier
                    ORDER BY creation_date DESC
                )
                WHERE ROWNUM = 1;

                l_prev_record_found := TRUE;

            EXCEPTION
                WHEN NO_DATA_FOUND THEN
                    l_prev_record_found := FALSE;
            END;

            IF l_prev_record_found THEN

                /*
                 * Create cancellation records for all lines
                 * belonging to the previously transmitted DC.
                 */

                FOR rec_old IN
                (
                    SELECT *
                    FROM napp_om_3b18_sales_order_details_075_retrofit_stg
                    WHERE header_header_id = rec_current.header_header_id
                      AND header_ship_set_num = rec_current.header_ship_set_num
                      AND dunsplus4 = l_old_dunsplus4
                      AND header_location_identifier = l_old_location
                      AND sent_to_dc_flag = 'Y'
                      AND status = 'SUCCESS'
                      AND line_line_id = rec_current.line_line_id
                )
                LOOP

                    SELECT COUNT(1)
                    INTO l_duplicate_count
                    FROM napp_om_3b18_sales_order_details_075_retrofit_stg
                    WHERE header_header_id = rec_old.header_header_id
                      AND header_ship_set_num = rec_old.header_ship_set_num
                      AND line_line_id = rec_old.line_line_id
                      AND dunsplus4 = rec_old.dunsplus4
                      AND header_location_identifier = rec_old.header_location_identifier
                      AND line_promise_date = '2099-12-31T00:00:00';
                    

                    IF l_duplicate_count = 0 THEN
                        l_cancel_rec := rec_old;
                        l_cancel_rec.line_promise_date := '2099-12-31T00:00:00';
                        l_cancel_rec.oic_instance_id := p_instance_id;
                        l_cancel_rec.sent_to_dc_flag := 'N';
                        l_cancel_rec.status := 'GTM SCREENING PASS';
                        l_cancel_rec.LINE_QUANTITY := 0;

                        INSERT INTO napp_om_3b18_sales_order_details_075_retrofit_stg
                        VALUES l_cancel_rec;
                        
                        -------------inserting into CI tables---------------------
                        FOR rec_old_CI1 IN
                        (
                            SELECT *
                            FROM napp_om_so_ci1_stg 
                            WHERE 
                                header_order_number = rec_old.header_order_number
                                AND line_shippable_set = rec_old.header_ship_set_num
                                AND line_line_id = rec_old.line_line_id
                                AND ci_revision = rec_old.order_revision_no
                                AND oic_instance_id = rec_old.oic_instance_id
                                AND line_ship_from_warehouse = rec_old.line_ship_from_warehouse
                        )
                        LOOP
                            l_cancel_rec_CI1 := rec_old_CI1;
                            l_cancel_rec_CI1.oic_instance_id := p_instance_id;
                            l_cancel_rec_CI1.LINE_ITEM_QUANTITY := 0;
                            
                            INSERT INTO napp_om_so_ci1_stg
                            VALUES l_cancel_rec_CI1;
                            
                        END LOOP;
                        
                        FOR rec_old_CI2 IN
                        (
                            SELECT *
                            FROM napp_om_so_ci2_stg 
                            WHERE 
                                header_order_number = rec_old.header_order_number
                                AND line_shippable_set = rec_old.header_ship_set_num
                                AND line_line_id = rec_old.line_line_id
                                AND ci_revision = rec_old.order_revision_no
                                AND oic_instance_id = rec_old.oic_instance_id
                                AND line_ship_from_warehouse = rec_old.line_ship_from_warehouse
                        )
                        LOOP
                            l_cancel_rec_CI2 := rec_old_CI2;
                            l_cancel_rec_CI2.oic_instance_id := p_instance_id;
                            l_cancel_rec_CI2.LINE_ITEM_QUANTITY := 0;
                            
                            INSERT INTO napp_om_so_ci2_stg
                            VALUES l_cancel_rec_CI2;
                            
                        END LOOP;

                    END IF;

                END LOOP;
                commit;

            END IF;

        END LOOP;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            RAISE;

END napp_process_dc_change;
--++++++++++++++++++++ Assign Ship Set Number ++++++++++++++++++++--
/*    PROCEDURE napp_assign_ship_set (
        p_instance_id IN VARCHAR2
    ) IS

        CURSOR get_ship_set_lines IS
        SELECT
            header_order_number,
            ( header_order_number
              || (
                CASE
                    WHEN ROW_NUMBER()
                         OVER(PARTITION BY header_order_number
                              ORDER BY
                                  TO_DATE(substr(line_promise_date, 1, 10),
                                          'YYYY-MM-DD')
                         ) = '1' THEN
                        'A'
                    WHEN ROW_NUMBER()
                         OVER(PARTITION BY header_order_number
                              ORDER BY
                                  TO_DATE(substr(line_promise_date, 1, 10),
                                          'YYYY-MM-DD')
                         ) = '2' THEN
                        'B'
                    WHEN ROW_NUMBER()
                         OVER(PARTITION BY header_order_number
                              ORDER BY
                                  TO_DATE(substr(line_promise_date, 1, 10),
                                          'YYYY-MM-DD')
                         ) = '3' THEN
                        'C'
                    WHEN ROW_NUMBER()
                         OVER(PARTITION BY header_order_number
                              ORDER BY
                                  TO_DATE(substr(line_promise_date, 1, 10),
                                          'YYYY-MM-DD')
                         ) = '4' THEN
                        'D'
                    ELSE
                        'E'
                END
            ) )                   header_ship_set_num,
            TO_DATE(substr(line_promise_date, 1, 10),
                    'YYYY-MM-DD') line_promise_date
        FROM
            napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
        WHERE
                oic_instance_id = p_instance_id
            AND status NOT IN ( 'ABORT', 'ERROR' )
            AND header_ship_set_num IS NULL
            AND header_order_type IN ( 'IN-TR' )
        GROUP BY
            header_order_number,
            TO_DATE(substr(line_promise_date, 1, 10),
                    'YYYY-MM-DD');

        TYPE ship_set_line_type IS
            TABLE OF get_ship_set_lines%rowtype INDEX BY BINARY_INTEGER;
        l_ship_set_line ship_set_line_type;
    BEGIN

		------Update ship set for lines where field is empty-----

        OPEN get_ship_set_lines;
        FETCH get_ship_set_lines
        BULK COLLECT INTO l_ship_set_line;
        CLOSE get_ship_set_lines;
        IF l_ship_set_line.count > 0 THEN
            FOR i IN 1..l_ship_set_line.count LOOP
                UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_3b18
                SET
                    header_ship_set_num = l_ship_set_line(i).header_ship_set_num
                WHERE
                        1 = 1
                    AND status NOT IN ( 'ABORT', 'ERROR' )
                    AND so_3b18.oic_instance_id = p_instance_id
                    AND so_3b18.header_ship_set_num IS NULL
                    AND so_3b18.header_order_number = l_ship_set_line(i).header_order_number
                    AND TO_DATE(substr(so_3b18.line_promise_date, 1, 10),
        'YYYY-MM-DD') = l_ship_set_line(i).line_promise_date;

                COMMIT;
            END LOOP;

            UPDATE napperp.napp_om_so_ci1_stg ci1_stg
            SET
                ci1_stg.line_shippable_set = (
                    SELECT DISTINCT
                        so_3b18.header_ship_set_num
                    FROM
                        napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_3b18
                    WHERE
                            1 = 1
                        AND so_3b18.oic_instance_id = p_instance_id
                        AND status NOT IN ( 'ABORT', 'ERROR' )
                        AND ci1_stg.header_header_id = so_3b18.header_header_id
                        AND ci1_stg.line_line_id = so_3b18.line_line_id
                )
            WHERE
                    1 = 1
                AND ci1_stg.oic_instance_id = p_instance_id
                AND ci1_stg.line_shippable_set IS NULL;

            COMMIT;
        END IF;

    END napp_assign_ship_set;
*/

		------Fetch error records in batches-----

    PROCEDURE napp_fetch_3b18_data_proc (
        p_fetchsize          IN NUMBER,
        p_offset             IN NUMBER,
        header_order_numberi IN VARCHAR2,
        header_ship_set_numi IN VARCHAR2,
        x_3b18_data          OUT SYS_REFCURSOR
    ) IS
    BEGIN
        OPEN x_3b18_data FOR SELECT
                                                      custom_line_number,
                                                      line_item,
                                                      line_quantity,
                                                      header_order_number,
                                                      header_ship_set_num
                                                  FROM
                                                      napperp.napp_om_3b18_sales_order_details_075_retrofit_stg
                             WHERE
                                     1 = 1
                                 AND header_order_number = header_order_numberi
                                 AND header_ship_set_num = header_ship_set_numi
                                 AND send_in_3b18_flag = 'Y'
                                 AND status NOT IN ( 'ERROR', 'ABORT' )
                             ORDER BY
                                 root_parent_line_id,
                                 trunc(itemordersequence)
                             OFFSET p_offset ROWS FETCH NEXT p_fetchsize ROWS ONLY;

    END napp_fetch_3b18_data_proc;

--++++++++++++++++++++Delete Aborted and Errored records ++++++++++++++++++++--
    PROCEDURE napp_purge_abort_error_records (
        p_instance_id IN VARCHAR2
    ) IS

        CURSOR get_abort_error_details IS
        SELECT
            MAX(
                CASE
                    WHEN status = 'ERROR' THEN
                        oic_instance_id
                END
            ) AS error_oic_instance_id,
            MAX(
                CASE
                    WHEN status = 'ABORT' THEN
                        oic_instance_id
                END
            ) AS abort_oic_instance_id,
            header_order_number,
            header_ship_set_num
        FROM
            (
                SELECT
                    so_3b18_1.rowid rid,
                    so_3b18_1.oic_instance_id,
                    so_3b18_1.header_order_number,
                    so_3b18_1.header_ship_set_num,
                    so_3b18_1.status,
                    DENSE_RANK()
                    OVER(PARTITION BY so_3b18_1.header_order_number, so_3b18_1.header_ship_set_num, so_3b18_1.status
                         ORDER BY
                             so_3b18_1.creation_date DESC NULLS LAST
                    )               dr
                FROM
                    napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_3b18_1
                WHERE
                        1 = 1
                    AND so_3b18_1.status IN ( 'ERROR', 'ABORT' )
                    AND so_3b18_1.header_order_number IN (
                        SELECT DISTINCT
                            so_3b18_2.header_order_number
                        FROM
                            napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_3b18_2
                        WHERE
                                1 = 1
                            AND so_3b18_2.oic_instance_id = p_instance_id
                    )
            )
        WHERE
            dr = 1
        GROUP BY
            header_order_number,
            header_ship_set_num;

        TYPE abort_error_record_type IS
            TABLE OF get_abort_error_details%rowtype INDEX BY BINARY_INTEGER;
        l_abort_error_record abort_error_record_type;
    BEGIN

		------Delete records where status is abort and error for older revision-----

        OPEN get_abort_error_details;
        FETCH get_abort_error_details
        BULK COLLECT INTO l_abort_error_record;
        CLOSE get_abort_error_details;
        IF l_abort_error_record.count > 0 THEN
            FOR i IN 1..l_abort_error_record.count LOOP
                BEGIN
	-----Insert records where status is abort and error into purge table-----
                    INSERT INTO napperp.napp_om_3b18_sales_order_details_075_retrofit_purge_tbl
                        (
                            SELECT
                                *
                            FROM
                                napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_3b18
                            WHERE
                                    1 = 1
                                AND so_3b18.header_order_number = l_abort_error_record(i).header_order_number
                                AND so_3b18.header_ship_set_num = l_abort_error_record(i).header_ship_set_num
								----*** --Commented as part of ADO 936760 ***-----
                                --AND nvl(so_3b18.line_hold_name, 'NULL') <> 'GTC EPCI/HR Hold'
                                --AND nvl(so_3b18.gtm_hold_applied, 'N') <> 'Y'
                                AND upper(so_3b18.status) IN ( 'ABORT', 'ERROR' )
                                AND ( ( l_abort_error_record(i).error_oic_instance_id IS NULL
                                        OR so_3b18.oic_instance_id <> l_abort_error_record(i).error_oic_instance_id )
                                      AND ( l_abort_error_record(i).abort_oic_instance_id IS NULL
                                            OR so_3b18.oic_instance_id <> l_abort_error_record(i).abort_oic_instance_id ) )
                        );

                    COMMIT;


	-----Delete records from 3b18 table-----
                    DELETE FROM napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_3b18
                    WHERE
                            1 = 1
                        AND so_3b18.header_order_number = l_abort_error_record(i).header_order_number
                        AND so_3b18.header_ship_set_num = l_abort_error_record(i).header_ship_set_num
                        AND upper(so_3b18.status) IN ( 'ABORT', 'ERROR' )
						----*** --Commented as part of ADO 936760 ***-----
                        --AND nvl(so_3b18.line_hold_name, 'NULL') <> 'GTC EPCI/HR Hold'
                        --AND nvl(so_3b18.gtm_hold_applied, 'N') <> 'Y'
                        AND ( ( l_abort_error_record(i).error_oic_instance_id IS NULL
                                OR so_3b18.oic_instance_id <> l_abort_error_record(i).error_oic_instance_id )
                              AND ( l_abort_error_record(i).abort_oic_instance_id IS NULL
                                    OR so_3b18.oic_instance_id <> l_abort_error_record(i).abort_oic_instance_id ) );

                    COMMIT;
                    INSERT INTO napperp.napp_om_so_ci1_purge_tbl
                        (
                            SELECT
                                *
                            FROM
                                napperp.napp_om_so_ci1_stg ci1
                            WHERE
                                    1 = 1
                                AND ci1.header_order_number = l_abort_error_record(i).header_order_number
                                AND ci1.line_shippable_set = l_abort_error_record(i).header_ship_set_num
                                AND ( ( l_abort_error_record(i).error_oic_instance_id IS NULL
                                        OR ci1.oic_instance_id <> l_abort_error_record(i).error_oic_instance_id )
                                      AND ( l_abort_error_record(i).abort_oic_instance_id IS NULL
                                            OR ci1.oic_instance_id <> l_abort_error_record(i).abort_oic_instance_id ) )
                                AND NOT EXISTS (
                                    SELECT
                                        1
                                    FROM
                                        napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_3b18
                                    WHERE
                                            1 = 1
                                        AND so_3b18.header_order_number = ci1.header_order_number
                                        AND so_3b18.header_ship_set_num = ci1.line_shippable_set
                                        AND so_3b18.oic_instance_id = ci1.oic_instance_id
                                )
                        );

                    COMMIT;


	-----Delete records from 3b18 table-----
                    DELETE FROM napperp.napp_om_so_ci1_stg ci2
                    WHERE
                            1 = 1
                        AND ci2.header_order_number = l_abort_error_record(i).header_order_number
                        AND ci2.line_shippable_set = l_abort_error_record(i).header_ship_set_num
                        AND ( ( l_abort_error_record(i).error_oic_instance_id IS NULL
                                OR ci2.oic_instance_id <> l_abort_error_record(i).error_oic_instance_id )
                              AND ( l_abort_error_record(i).abort_oic_instance_id IS NULL
                                    OR ci2.oic_instance_id <> l_abort_error_record(i).abort_oic_instance_id ) )
                        AND NOT EXISTS (
                            SELECT
                                1
                            FROM
                                napperp.napp_om_3b18_sales_order_details_075_retrofit_stg so_3b18
                            WHERE
                                    1 = 1
                                AND so_3b18.header_order_number = ci2.header_order_number
                                AND so_3b18.header_ship_set_num = ci2.line_shippable_set
                                AND so_3b18.oic_instance_id = ci2.oic_instance_id
                        );

                    COMMIT;
                EXCEPTION
                    WHEN OTHERS THEN
                        ROLLBACK;
                        DECLARE
                            l_err_msg VARCHAR2(4000);
                        BEGIN
                            l_err_msg := substr(('Purge data for abort and error records in 3B18 and CI STG1 table - '
                                                 || sqlerrm), 1, 4000);
                            UPDATE napperp.napp_om_3b18_sales_order_details_075_retrofit_stg s
                            SET
                                s.status = 'ERROR',
                                s.error_details = l_err_msg
                            WHERE
                                    s.oic_instance_id = p_instance_id
                                AND s.header_order_number = l_abort_error_record(i).header_order_number
                                AND ( s.header_ship_set_num = l_abort_error_record(i).header_ship_set_num
                                      OR s.header_ship_set_num IS NULL );

                            COMMIT;
                        END;

                END;
            END LOOP;
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            ROLLBACK;
            dbms_output.put_line('Error in napperp.napp_purge_abort_error_records ' || sqlerrm);
            RAISE;
			--add_order_ship_error(p_order_number => NULL, p_ship_set => NULL, p_step => 'BATCH_FATAL for napperp.napp_purge_abort_error_records', p_msg => sqlerrm);
    END napp_purge_abort_error_records;

END napp_om_3b18_salesorder_075_pkg;