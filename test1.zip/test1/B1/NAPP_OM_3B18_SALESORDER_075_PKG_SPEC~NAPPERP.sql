create or replace PACKAGE         NAPPERP.napp_om_3b18_salesorder_075_pkg AS
/*******************************************************************************************************
                         NetApp Inc. Sunnyvale California
********************************************************************************************************
File Name : napp_om_3b18_salesorder_075_pkg.pks
Object Name : 	NAPP_OM_3B18_SALESORDER_075_PKG
Description : To extract the serials from  3B2 serial geneology table & to sync napp_om_sales_order_details table 
Revision History:
Version     Date         Modified By              Description
--------    ---------    ------------             -----------------------------------------------------
1.0         01-Mar-2025  Sagar Arora              Initial Version.
1.1         22-Sep-2026  Ashwin Pai               ADO#948669 Added process dc change - Laredo Phase 2
*******************************************************************************************************/

    PROCEDURE napp_get_controller_serials (
        p_instance_id IN VARCHAR2
    );

     PROCEDURE napp_get_non_controller_serials (
        p_instance_id IN VARCHAR2
    );

     PROCEDURE napp_update_custom_line_num (
        p_instance_id IN VARCHAR2
    );
	 PROCEDURE napp_purge_abort_error_records (
        p_instance_id IN VARCHAR2
    );
	  PROCEDURE napp_update_revision_line_detail (
        p_instance_id IN VARCHAR2,
		p_trigger_mode IN VARCHAR2
    );
	PROCEDURE napp_update_ssd_cancelled_line (
        p_instance_id  IN VARCHAR2
    );
    PROCEDURE napp_process_dc_change (    --v1.1
        p_instance_id  IN VARCHAR2
    );
	/*PROCEDURE napp_assign_ship_set (
        p_instance_id  IN VARCHAR2
    );*/
	PROCEDURE napp_fetch_3b18_data_proc (
        p_fetchsize        IN  NUMBER,
        p_offset           IN  NUMBER,
        header_order_numberi IN varchar2,
        header_ship_set_numi IN varchar2,
        x_3b18_data          OUT SYS_REFCURSOR
    );
	PROCEDURE napp_dbms_scheduler_master_procedure (
        p_in_job_name  IN VARCHAR2,
        p_instance_id  IN VARCHAR2,
        p_trigger_mode IN VARCHAR2,
        p_status       OUT VARCHAR2,
        p_message      OUT VARCHAR2
    );
	PROCEDURE napp_run_master_procedure (
        p_instance_id  IN VARCHAR2,
        p_trigger_mode IN VARCHAR2
    );

END napp_om_3b18_salesorder_075_pkg;