create or replace TYPE NAPPERP.napp_om_ci_line_details_obj_type AS OBJECT (
        ord_qty            NUMBER,
        item               VARCHAR2(100 BYTE),
        cp_description     VARCHAR2(100 BYTE),
        cf_standard_desc   VARCHAR2(100 BYTE),
        cf_coo             VARCHAR2(20 BYTE),
        ci_htts            VARCHAR2(20 BYTE),
        ci_eccn            VARCHAR2(100 BYTE),
        cf_lic_no          VARCHAR2(100 BYTE),
        unit_selling_price NUMBER,
        cf_extended_amount NUMBER
);