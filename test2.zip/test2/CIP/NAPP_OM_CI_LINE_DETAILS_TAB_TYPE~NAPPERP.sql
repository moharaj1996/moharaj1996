create or replace TYPE napperp.napp_om_ci_line_details_tab_type AS
    TABLE OF napp_om_ci_line_details_obj_type;
