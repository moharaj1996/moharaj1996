create or replace PACKAGE napp_om_generate_ci_xml_dc_pkg

/*******************************************************************************************************
                         NetApp Inc. Sunnyvale California
********************************************************************************************************
File Name   : NAPP_OM_GENERATE_CI_XML_DC_PKG.pks
Object Name : NAPP_OM_GENERATE_CI_XML_DC_PKG

Description : Package to generate xml data mapping

Revision History:

Version     Date         Modified By              Description
--------    ---------    ------------             -----------------------------------------------------
1.0        15-Feb-2025  Sagar Arora     Initial Version.

*******************************************************************************************************/ AS
    PROCEDURE napp_om_generate_ci_xml_data_proc (
        p_ship_from_warehouse IN VARCHAR2,
        p_schedule_ship_date  IN VARCHAR2,
        p_ship_set            IN VARCHAR2,
        p_order_number        IN VARCHAR2,
        p_result              OUT napp_om_ci_xml_header_dtls_tab_type,
        p_status              OUT VARCHAR2,
        p_status_msg          OUT VARCHAR2,
        p_cf_sent_emails      IN VARCHAR2,
        p_ci_sent_to_email    IN VARCHAR2,
        p_ci_sent_from_email  IN VARCHAR2,
        p_cf_instance         IN VARCHAR2,
		p_CF_SINGLE_MULTIPLE    IN VARCHAR2,
		p_SINGLE_MULTIPLE_DOC   IN VARCHAR2
    );

END napp_om_generate_ci_xml_dc_pkg;

