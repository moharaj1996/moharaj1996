create or replace PACKAGE NAPPERP.NAPP_OM_GENERATE_CI_XML_DATA_PKG

/*******************************************************************************************************
                         NetApp Inc. Sunnyvale California
********************************************************************************************************
File Name   : NAPP_OM_GENERATE_CI_XML_DATA_PKG.pks
Object Name : NAPP_OM_GENERATE_CI_XML_DATA_PKG

Description : Package to generate xml data mapping

Revision History:

Version     Date         Modified By              Description
--------    ---------    ------------             -----------------------------------------------------
1.0        13-Feb-2025  Korangi Jyothi yasasvi     Initial Version.
1.0.1      12-Dec-2025  Korangi Jyothi yasasvi     Incident# INC4391401

*******************************************************************************************************/

AS
    PROCEDURE NAPP_OM_GENERATE_CI_XML_DATA_PROC (
        p_ship_from_warehouse IN VARCHAR2,
        p_schedule_ship_date IN VARCHAR2,
        p_ship_set IN VARCHAR2,
        p_order_number IN VARCHAR2,
		p_result       OUT   NAPP_OM_CI_HEADER_DETAILS_TAB_TYPE,
		p_status          		 OUT VARCHAR2,
        p_status_msg          OUT VARCHAR2
    );

-- INC4391401 Start
  PROCEDURE NAPP_OM_CI_VALIDATION_PROC (
        p_ship_from_warehouse IN VARCHAR2,
        p_schedule_ship_date IN VARCHAR2,
        p_ship_set IN VARCHAR2,
        p_order_number IN VARCHAR2,
        p_status                       OUT VARCHAR2,
        p_message                      OUT VARCHAR2
    );
-- INC4391401 End
END NAPP_OM_GENERATE_CI_XML_DATA_PKG;
/