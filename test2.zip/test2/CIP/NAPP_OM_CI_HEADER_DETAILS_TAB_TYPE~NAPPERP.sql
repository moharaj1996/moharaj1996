create or replace TYPE napperp.napp_om_ci_header_details_tab_type AS
    TABLE OF napp_om_ci_header_details_obj_type;