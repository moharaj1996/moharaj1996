CREATE OR REPLACE PACKAGE BODY napp_om_generate_ci_xml_dc_pkg
/*******************************************************************************************************************/
/* File Name       : napp_om_generate_ci_xml_dc_pkg.pks                                                                   */
/* Object Name      :napp_om_generate_ci_xml_dc_pkg                                                                          */
/* Description     : Generate CI XML on Adhoc basis                                       */
/*******************************************************************************************************************/
/* Revision History:                                                                                               */
/*  Ver       Date           Modified By       Revision Description                                                     */
/*  ===      ===========    ============      ====================                                                     */
/* 1.0        11-Feb-2025   Sagar Arora        C2C-NEW-EXT-022 / OF-INT-002      */
/* 1.0.1      05-Mar-2026  Korangi Jyothi yasasvi     ADO#911324*/
/*******************************************************************************************************************/ AS

    PROCEDURE napp_om_generate_ci_xml_data_proc (
        p_ship_from_warehouse IN VARCHAR2,
        p_schedule_ship_date  IN VARCHAR2,
        p_ship_set            IN VARCHAR2,
        p_order_number        IN VARCHAR2,
        p_result              OUT napp_om_ci_xml_header_dtls_tab_type,
        p_status              OUT VARCHAR2,
        p_status_msg          OUT VARCHAR2,
        p_cf_sent_emails      IN VARCHAR2,
        p_ci_sent_to_email    IN VARCHAR2,
        p_ci_sent_from_email  IN VARCHAR2,
        p_cf_instance         IN VARCHAR2,
        p_cf_single_multiple  IN VARCHAR2,
        p_single_multiple_doc IN VARCHAR2
    ) IS

        CURSOR c_get_header_rec (
            cp_ship_from_warehouse IN VARCHAR2,
            cp_schedule_ship_date  IN VARCHAR2,
            cp_ship_set            IN VARCHAR2,
            cp_order_number        IN VARCHAR2
        ) IS
        SELECT DISTINCT
            templ_document_header,
            decode(templ_sw_invoice_from, 'No', templ_pl_invoice_from, NULL)                      templ_pl_invoice_from,
            decode(templ_sw_invoice_from,
                   'No',
                   nvl(templ_pl_invoice_from, 'Invoice From')
                   || CHR(10)
                   || templ_invoice_from_address
                   || CHR(10)
                   || 'Phone : Fax :',
                   NULL)                                                                          cp_invoice_from,
            header_order_number,
            templ_document_number_label,
            ci_number                                                                             customs_invoice_num,
            header_customer_po_num,
            line_shippable_set,
            line_scheduled_ship_date,
            decode(templ_sw_payment_terms, 'No', templ_pl_payment_terms, NULL)                    templ_pl_payment_terms,
            decode(templ_sw_payment_terms,
                   'No',
                   nvl(templ_pl_payment_terms, 'Payment Terms')
                   || CHR(10)
                   || line_payment_terms,
                   NULL)                                                                          line_payment_terms,
            decode(templ_sw_freight_terms, 'No', templ_pl_freight_terms, NULL)                    templ_pl_freight_terms,
            decode(templ_sw_freight_terms, 'No', line_freight_term_code, NULL)                    line_freight_term_code,
            decode(templ_sw_ult_consignee_type, 'No', templ_pl_ult_consignee_type, NULL)          templ_pl_ult_consignee_type,
            decode(templ_sw_ult_consignee_type,
                   'No',
                   decode(templ_ult_consignee_type,
                          NULL,
                          NULL,
                          nvl(templ_pl_ult_consignee_type, 'Ultimate Consignee Type')
                          || CHR(10)
                          || templ_ult_consignee_type),
                   NULL)                                                                          templ_ult_consignee_type,
            decode(templ_sw_ship_from, 'No', templ_pl_ship_from, NULL)                            templ_pl_ship_from,
            decode(templ_sw_ship_from, 'No',(line_shipfrom_address), NULL)                        custom_cp_ship_from_address2,
            decode(templ_sw_ship_to, 'No', templ_pl_ship_to, NULL)                                templ_pl_ship_to,
            decode(templ_sw_ship_to,
                   'No',
                   header_shipto_customer
                   || CHR(10)
                   || header_shipto_address
                   || decode(header_shipto_contact_name,
                             NULL,
                             NULL,
                             CHR(10)
                             || templ_pl_ship_to_contact)
                   || ' '
                   || header_shipto_contact_name
                   || decode(header_shipto_contact_phone,
                             NULL,
                             NULL,
                             CHR(10)
                             || 'Phone:-')
                   || header_shipto_contact_phone,
                   NULL)                                                                          custom_cp_ship_to_address2,
            decode(templ_sw_bill_to, 'No', templ_pl_bill_to, NULL)                                templ_pl_bill_to,
            decode(templ_sw_bill_to,
                   'No',
                   header_billto_customer
                   || CHR(10)
                   || header_billto_address
                   || decode(header_billto_contact,
                             NULL,
                             NULL,
                             CHR(10)
                             || templ_pl_bill_to_contact)
                   || ' '
                   || header_billto_contact,
                   NULL)                                                                          custom_cp_bill_to_address2,
            decode(templ_sw_final_dest, 'No', templ_pl_final_dest, NULL)                          templ_pl_final_dest,
            decode(templ_sw_final_dest, 'No', templ_final_dest || templ_final_dest_address, NULL) templ_final_dest,
            decode(templ_sw_incoterm, 'No', templ_pl_incoterm, NULL)                              templ_pl_incoterm,
            decode(templ_sw_incoterm,
                   'No',
                   nvl(templ_pl_incoterm, 'Incoterms ')
                   || CHR(10)
                   || line_fob,
                   NULL)                                                                          line_fob,
            decode(templ_sw_carrier,
                   'No',
                   nvl(templ_pl_carrier, 'Carrier')
                   || CHR(10)
                   || templ_carrier,
                   NULL)                                                                          templ_pl_carrier,
            decode(templ_sw_carrier, 'No', templ_carrier, NULL)                                   templ_carrier,
            decode(templ_sw_mode_of_transportation, 'No', templ_pl_mode_of_transportation, NULL)  templ_pl_mode_of_transportation,
            decode(templ_sw_mode_of_transportation, 'No', templ_mode_of_transportation, NULL)     templ_mode_of_transportation,
            decode(templ_sw_country_of_provenance, 'No', templ_pl_country_of_provenance, NULL)    templ_pl_country_of_provenance,
            decode(templ_sw_country_of_provenance, 'No', templ_country_of_provenance, NULL)       templ_country_of_provenance,
            decode(templ_sw_country_of_dest, 'No', templ_pl_country_of_dest, NULL)                templ_pl_country_of_dest,
            decode(templ_sw_country_of_dest,
                   'No',
                   nvl(templ_pl_country_of_dest, 'Country of Destination')
                   || CHR(10)
                   || napp_om_ci_transformation_pkg.napp_om_country_func(templ_country_of_dest),
                   NULL)                                                                          templ_country_of_dest,
            decode(templ_sw_country_of_origin, 'No', templ_pl_country_of_origin, NULL)            templ_pl_country_of_origin,
            decode(templ_sw_currency, 'No', templ_pl_currency, NULL)                              templ_pl_currency,
            decode(templ_sw_eccn, 'No', templ_pl_eccn, NULL)                                      templ_pl_eccn,
            decode(templ_sw_hts_code, 'No', templ_pl_hts_code, NULL)                              templ_pl_hts_code,
            decode(templ_sw_signature_text, 'No', templ_signature_text, NULL)                     templ_signature_text,
            decode(templ_sw_footer_text, 'No', templ_footer_text, NULL)                           templ_footer_text,
            templ_std_desc,
            header_sub_total,
            header_grand_total,
            header_order_number                                                                   order_number,
            line_requested_ship_date                                                              requested_date,
            header_header_id                                                                      header_id,
            header_billto_tax_registration_number                                                 vat,
            header_shipto_contact_name                                                            ship_to_contact,
            line_fulfill_org_id                                                                   ship_from_org_id, -- Added as a part of CON0002775-719546
           -- decode(line_ship_from_warehouse, 'NMXGDL1R', '751', 'ASGSIN1R', '611',line_fulfill_org_id) ship_from_org_id,-- Commented as a part of CON0002775-719546
            header_billto_contact                                                                 bill_to_contact,
            templ_pl_final_dest                                                                   pl_final_dest,
            templ_pl_ship_from                                                                    pl_ship_from,
            templ_pl_ship_to_loc_id                                                               pl_ship_to_loc_id,
            templ_pl_mode_of_transportation                                                       pl_mode_of_transportation,
            decode(templ_sw_mode_of_transportation, 'Yes', 'Y', 'N')                              sw_mode_of_transportation,
            templ_mode_of_transportation                                                          mode_of_transportation,
            templ_pl_ship_to_contact                                                              pl_ship_to_contact,
            templ_pl_bill_to_contact                                                              pl_bill_to_contact,
            templ_pl_eccn                                                                         pl_eccn,
            templ_pl_bill_to_loc_id                                                               pl_bill_to_loc_id,
            decode(templ_sw_invoice_from, 'Yes', 'Y', 'N')                                        sw_invoice_from,
            decode(templ_sw_ship_from, 'Yes', 'Y', 'N')                                           sw_ship_from,
            decode(templ_sw_currency, 'Yes', 'Y', 'N')                                            sw_currency,
            decode(templ_sw_country_of_dest, 'Yes', 'Y', 'N')                                     sw_final_dest,
            decode(templ_sw_eccn, 'Yes', 'Y', 'N')                                                sw_eccn1,
            decode(templ_sw_ship_to, 'Yes', 'Y', 'N')                                             sw_ship_to_loc_id,
            decode(templ_sw_ship_to_contact, 'Yes', 'Y', 'N')                                     sw_ship_to_contact,
            templ_country_of_provenance                                                           pl_country_of_provenance,
            header_billto_country                                                                 bill_to_country,
            decode(templ_sw_bill_to, 'Yes', 'Y', 'N')                                             sw_bill_to_loc_id,
            decode(templ_sw_bill_to_contact, 'Yes', 'Y', 'N')                                     sw_bill_to_contact,
            templ_pl_signature_text                                                               pl_signature_text,
            templ_signature_text                                                                  signature_text,
            decode(templ_sw_signature_text, 'Yes', 'Y', 'N')                                      sw_signature_text,
            templ_pl_currency                                                                     pl_currency,
            header_sold_to_customer                                                               sold_to,
            templ_invoice_from                                                                    ci_invoice_from,
            header_order_currency                                                                 ci_currency,
            templ_final_dest                                                                      ci_final_dest,
            templ_pl_bill_to_loc_id                                                               ci_bill_to_loc_id,
            line_payment_terms                                                                    payment_terms,
            decode(templ_sw_payment_terms, 'Yes', 'Y', 'N')                                       sw_payment_terms,
            header_billto_contact                                                                 ci_bill_to_contact,
            templ_carrier                                                                         carrier,
            decode(templ_sw_carrier, 'Yes', 'Y', 'N')                                             sw_carrier,
            templ_pl_carrier                                                                      pl_carrier,
            header_shipto_contact_name                                                            ci_ship_to_contact,
            decode(templ_sw_hs_code, 'Yes', 'Y', 'N')                                             sw_hs_code,
            templ_pl_freight_terms                                                                pl_freight_terms,
            decode(templ_sw_freight_terms, 'Yes', 'Y', 'N')                                       sw_freight_terms,
            decode(templ_sw_incoterm, 'Yes', 'Y', 'N')                                            sw_incoterm,
            decode(templ_sw_country_of_provenance, 'Yes', 'Y', 'N')                               sw_country_of_provenance,
            templ_func_temp_name                                                                  ci_func_temp_name,
            templ_country_of_provenance                                                           ci_country_of_provenance,
            line_fob                                                                              fob,
            decode(templ_sw_ult_consignee_type, 'Yes', 'Y', 'N')                                  sw_uct,
            decode(templ_sw_bill_to,
                   'No',
                   header_billto_customer
                   || CHR(10)
                   || header_billto_address
                   || decode(header_billto_contact,
                             NULL,
                             NULL,
                             CHR(10)
                             || templ_pl_bill_to_contact)
                   || ' '
                   || header_billto_contact,
                   NULL)                                                                          cp_bill_to_address,
            decode(templ_sw_bill_to,
                   'No',
                   header_billto_customer
                   || CHR(10)
                   || header_billto_address
                   || decode(header_billto_contact,
                             NULL,
                             NULL,
                             CHR(10)
                             || templ_pl_bill_to_contact)
                   || ' '
                   || header_billto_contact,
                   NULL)                                                                          cf_bill_to_address,
            decode(templ_sw_ship_to,
                   'No',
                   header_shipto_customer
                   || CHR(10)
                   || header_shipto_address
                   || decode(header_shipto_contact_name,
                             NULL,
                             NULL,
                             CHR(10)
                             || templ_pl_ship_to_contact)
                   || ' '
                   || header_shipto_contact_name
                   || decode(header_shipto_contact_phone,
                             NULL,
                             NULL,
                             CHR(10)
                             || 'Phone:-')
                   || header_shipto_contact_phone,
                   NULL)                                                                          cf_ship_to_address,
            decode(templ_sw_ship_from,
                   'No',
                   (nvl(templ_pl_ship_from, 'Ship From')
                    || CHR(10)
                    || line_shipfrom_address),
                   NULL)                                                                          cf_ship_from_address,
            decode(templ_sw_ship_from,
                   'No',
                   (nvl(templ_pl_ship_from, 'Ship From')
                    || CHR(10)
                    || line_shipfrom_address),
                   NULL)                                                                          cp_ship_from_address,
            decode(templ_sw_ship_from, 'No',(line_shipfrom_address), NULL)                        cf_frieght_carriers1,
            header_order_type                                                                     cf_order_type,
            decode(templ_sw_invoice_from,
                   'No',
                   nvl(templ_pl_invoice_from, 'Invoice From')
                   || CHR(10)
                   || templ_invoice_from_address
                   || CHR(10)
                   || 'Phone : Fax :',
                   NULL)                                                                          cf_invoice_from,
            decode(templ_sw_final_dest,
                   'No',
                   nvl(templ_pl_final_dest, 'Final Destination ')
                   || CHR(10)
                   || nvl(templ_final_dest, header_end_cust_po_name)
                   || CHR(10)
                   || templ_final_dest_address,
                   NULL)                                                                          cf_final_des,
            templ_final_dest                                                                      custom_cf_final_des,
            decode(templ_sw_final_dest,
                   'No',
                   nvl(templ_pl_final_dest, 'Final Destination ')
                   || CHR(10)
                   || nvl(templ_final_dest, header_end_cust_po_name)
                   || CHR(10)
                   || templ_final_dest_address,
                   NULL)                                                                          cp_final_des,
            decode(templ_sw_currency,
                   'No',
                   nvl(templ_pl_currency, 'Amount')
                   || CHR(10)
                   || '('
                   || header_order_currency
                   || ')',
                   NULL)                                                                          cf_currency,
            decode(templ_sw_currency,
                   'No',
                   nvl(templ_pl_currency, 'Amount')
                   || CHR(10)
                   || '('
                   || header_order_currency
                   || ')',
                   NULL)                                                                          cp_currency1,
            decode(templ_sw_hts_code,
                   'No',
                   nvl(templ_pl_hts_code, 'Ship from HTS'),
                   NULL)                                                                          cf_hs_code,
            header_shipto_country                                                                 cf_country_code,
            header_shipto_customer                                                                cf_customer_ship_to,
            decode(templ_sw_country_of_origin, 'Yes', 'Y', 'N')                                   sw_coo1,
            templ_ship_from                                                                       ci_ship_from,
            line_shipping_method                                                                  shipping_method_code,
            line_actual_shipdate                                                                  actual_shipment_date,
            header_shipto_account_siteuse_id                                                      ship_to_org_id,
            header_sold_to_party_id,
            header_billto_account_siteuse_id,
            header_shipto_account_siteuse_id,
            decode(templ_sw_freight_terms,
                   'No',
                   nvl(templ_pl_freight_terms, 'Freight Terms')
                   || CHR(10)
                   || line_freight_term_code,
                   NULL)                                                                          cf_frieght_carriers,
            decode(templ_sw_final_dest,
                   'No',
                   nvl(templ_final_dest, header_end_cust_po_name)
                   || CHR(10)
                   || templ_final_dest_address,
                   NULL)                                                                          custom_cp_final_des2,
            decode(templ_sw_mode_of_transportation,
                   'No',
                   nvl(templ_pl_mode_of_transportation, 'Mode of Transportation')
                   || CHR(10)
                   || templ_mode_of_transportation,
                   NULL)                                                                          cf_mode_of_operation,
            'Date of Issue:'
            || CHR(10)
            || creation_date                                                                      cf_date_of_issue,
            line_actual_shipdate                                                                  cf_act_ship_date,
            header_grand_total                                                                    cf_ord_total,
            ( header_sub_total - nvl(header_service_amount, 0) )                                  cs_ext_amount,
            nvl(header_service_amount, '0')                                                       cf_serviceline_amt,
            decode(templ_sw_country_of_provenance,
                   'No',
                   nvl(templ_pl_country_of_provenance, 'Country of Provenance ')
                   || ' '
                   || templ_country_of_provenance,
                   NULL)                                                                          cf_country_pro,
            templ_pl_hs_code                                                                      pl_hs_code,
            templ_hs_code                                                                         ci_hs_code,
            header_attribute2                                                                     header_ci_bill_to_contact,
            header_attribute3                                                                     header_ci_ship_to_contact
        FROM
            napp_om_so_ci2_stg a
        WHERE
                1 = 1
    --trunc(line_scheduled_ship_date) = TO_DATE(:line_scheduled_ship_date, 'DD-MON-YY')
            AND a.line_scheduled_ship_date = to_char(TO_DATE(cp_schedule_ship_date, 'YYYY-MM-DD'),
                                                     'DD-MON-YY')
            AND ( ( cp_ship_set IS NULL
                    AND 1 = 1 )
                  OR ( cp_ship_set IS NOT NULL
                       AND a.line_shippable_set = cp_ship_set ) )
            AND ( ( cp_order_number IS NULL
                    AND 1 = 1 )
                  OR ( cp_order_number IS NOT NULL
                       AND a.header_order_number = cp_order_number ) )
            AND a.ci_revision = (
                SELECT
                    MAX(b.ci_revision)
                FROM
                    napperp.napp_om_so_ci2_stg b
                WHERE
                        b.header_order_number = a.header_order_number
                    AND b.line_shippable_set = a.line_shippable_set  --1.0.1
            )
--			AND ( SELECT COUNT(*) CNT
--              FROM
--             napp_om_3b18_sales_order_details_075_retrofit_stg parent
--             WHERE
--               parent.header_header_id = a.header_header_id
--           AND parent.line_line_id = a.line_line_id AND parent.order_revision_no = a.ci_revision and parent.line_cancelled_status is null) > 0
        GROUP BY
            templ_document_header,
            decode(templ_sw_invoice_from, 'No', templ_pl_invoice_from, NULL),
            decode(templ_sw_invoice_from,
                   'No',
                   nvl(templ_pl_invoice_from, 'Invoice From')
                   || CHR(10)
                   || templ_invoice_from_address
                   || CHR(10)
                   || 'Phone : Fax :',
                   NULL),
            header_order_number,
            templ_document_number_label,
            ci_number,
            header_customer_po_num,
            line_shippable_set,
            line_scheduled_ship_date,
            decode(templ_sw_payment_terms, 'No', templ_pl_payment_terms, NULL),
            decode(templ_sw_payment_terms,
                   'No',
                   nvl(templ_pl_payment_terms, 'Payment Terms')
                   || CHR(10)
                   || line_payment_terms,
                   NULL),
            decode(templ_sw_freight_terms, 'No', templ_pl_freight_terms, NULL),
            decode(templ_sw_freight_terms, 'No', line_freight_term_code, NULL),
            decode(templ_sw_ult_consignee_type, 'No', templ_pl_ult_consignee_type, NULL),
            decode(templ_sw_ult_consignee_type,
                   'No',
                   decode(templ_ult_consignee_type,
                          NULL,
                          NULL,
                          nvl(templ_pl_ult_consignee_type, 'Ultimate Consignee Type')
                          || CHR(10)
                          || templ_ult_consignee_type),
                   NULL),
            decode(templ_sw_ship_from, 'No', templ_pl_ship_from, NULL),
            decode(templ_sw_ship_from, 'No',(line_shipfrom_address), NULL),
            decode(templ_sw_ship_to, 'No', templ_pl_ship_to, NULL),
            decode(templ_sw_ship_to,
                   'No',
                   header_shipto_customer
                   || CHR(10)
                   || header_shipto_address
                   || decode(header_shipto_contact_name,
                             NULL,
                             NULL,
                             CHR(10)
                             || templ_pl_ship_to_contact)
                   || ' '
                   || header_shipto_contact_name
                   || decode(header_shipto_contact_phone,
                             NULL,
                             NULL,
                             CHR(10)
                             || 'Phone:-')
                   || header_shipto_contact_phone,
                   NULL),
            decode(templ_sw_bill_to, 'No', templ_pl_bill_to, NULL),
            decode(templ_sw_bill_to,
                   'No',
                   header_billto_customer
                   || CHR(10)
                   || header_billto_address
                   || decode(header_billto_contact,
                             NULL,
                             NULL,
                             CHR(10)
                             || templ_pl_bill_to_contact)
                   || ' '
                   || header_billto_contact,
                   NULL),
            decode(templ_sw_final_dest, 'No', templ_pl_final_dest, NULL),
            decode(templ_sw_final_dest, 'No', templ_final_dest || templ_final_dest_address, NULL),
            decode(templ_sw_incoterm, 'No', templ_pl_incoterm, NULL),
            decode(templ_sw_incoterm,
                   'No',
                   nvl(templ_pl_incoterm, 'Incoterms ')
                   || CHR(10)
                   || line_fob,
                   NULL),
            decode(templ_sw_carrier,
                   'No',
                   nvl(templ_pl_carrier, 'Carrier')
                   || CHR(10)
                   || templ_carrier,
                   NULL),
            decode(templ_sw_carrier, 'No', templ_carrier, NULL),
            decode(templ_sw_mode_of_transportation, 'No', templ_pl_mode_of_transportation, NULL),
            decode(templ_sw_mode_of_transportation, 'No', templ_mode_of_transportation, NULL),
            decode(templ_sw_country_of_provenance, 'No', templ_pl_country_of_provenance, NULL),
            decode(templ_sw_country_of_provenance, 'No', templ_country_of_provenance, NULL),
            decode(templ_sw_country_of_dest, 'No', templ_pl_country_of_dest, NULL),
            decode(templ_sw_country_of_dest,
                   'No',
                   nvl(templ_pl_country_of_dest, 'Country of Destination')
                   || CHR(10)
                   || napp_om_ci_transformation_pkg.napp_om_country_func(templ_country_of_dest),
                   NULL),
            decode(templ_sw_country_of_origin, 'No', templ_pl_country_of_origin, NULL),
            decode(templ_sw_currency, 'No', templ_pl_currency, NULL),
            decode(templ_sw_eccn, 'No', templ_pl_eccn, NULL),
            decode(templ_sw_hts_code, 'No', templ_pl_hts_code, NULL),
            decode(templ_sw_signature_text, 'No', templ_signature_text, NULL),
            decode(templ_sw_footer_text, 'No', templ_footer_text, NULL),
            templ_std_desc,
            header_sub_total,
            header_grand_total,
            header_order_number,
            line_requested_ship_date,
            header_header_id,
            header_billto_tax_registration_number,
            header_shipto_contact_name,
            line_fulfill_org_id,  -- Added as a apart of CON0002775-719546
           -- decode(line_ship_from_warehouse, 'NMXGDL1R', '751', 'ASGSIN1R', '611',  line_fulfill_org_id), -- Commented as apart of CON0002775-719546
            header_billto_contact,
            templ_pl_final_dest,
            templ_pl_ship_from,
            templ_pl_ship_to_loc_id,
            templ_pl_mode_of_transportation,
            decode(templ_sw_mode_of_transportation, 'Yes', 'Y', 'N'),
            templ_mode_of_transportation,
            templ_pl_ship_to_contact,
            templ_pl_bill_to_contact,
            templ_pl_eccn,
            templ_pl_bill_to_loc_id,
            decode(templ_sw_invoice_from, 'Yes', 'Y', 'N'),
            decode(templ_sw_ship_from, 'Yes', 'Y', 'N'),
            decode(templ_sw_currency, 'Yes', 'Y', 'N'),
            decode(templ_sw_country_of_dest, 'Yes', 'Y', 'N'),
            decode(templ_sw_eccn, 'Yes', 'Y', 'N'),
            decode(templ_sw_ship_to, 'Yes', 'Y', 'N'),
            decode(templ_sw_ship_to_contact, 'Yes', 'Y', 'N'),
            templ_country_of_provenance,
            header_billto_country,
            decode(templ_sw_bill_to, 'Yes', 'Y', 'N'),
            decode(templ_sw_bill_to_contact, 'Yes', 'Y', 'N'),
            templ_pl_signature_text,
            templ_signature_text,
            decode(templ_sw_signature_text, 'Yes', 'Y', 'N'),
            templ_pl_currency,
            header_sold_to_customer,
            templ_invoice_from,
            header_order_currency,
            templ_final_dest,
            templ_pl_bill_to_loc_id,
            line_payment_terms,
            decode(templ_sw_payment_terms, 'Yes', 'Y', 'N'),
            header_billto_contact,
            templ_carrier,
            decode(templ_sw_carrier, 'Yes', 'Y', 'N'),
            templ_pl_carrier,
            header_shipto_contact_name,
            decode(templ_sw_hs_code, 'Yes', 'Y', 'N'),
            templ_pl_freight_terms,
            decode(templ_sw_freight_terms, 'Yes', 'Y', 'N'),
            decode(templ_sw_incoterm, 'Yes', 'Y', 'N'),
            decode(templ_sw_country_of_provenance, 'Yes', 'Y', 'N'),
            templ_func_temp_name,
            templ_country_of_provenance,
            line_fob,
            decode(templ_sw_ult_consignee_type, 'Yes', 'Y', 'N'),
            decode(templ_sw_bill_to,
                   'No',
                   header_billto_customer
                   || CHR(10)
                   || header_billto_address
                   || decode(header_billto_contact,
                             NULL,
                             NULL,
                             CHR(10)
                             || templ_pl_bill_to_contact)
                   || ' '
                   || header_billto_contact,
                   NULL),
            decode(templ_sw_bill_to,
                   'No',
                   header_billto_customer
                   || CHR(10)
                   || header_billto_address
                   || decode(header_billto_contact,
                             NULL,
                             NULL,
                             CHR(10)
                             || templ_pl_bill_to_contact)
                   || ' '
                   || header_billto_contact,
                   NULL),
            decode(templ_sw_ship_to,
                   'No',
                   header_shipto_customer
                   || CHR(10)
                   || header_shipto_address
                   || decode(header_shipto_contact_name,
                             NULL,
                             NULL,
                             CHR(10)
                             || templ_pl_ship_to_contact)
                   || ' '
                   || header_shipto_contact_name
                   || decode(header_shipto_contact_phone,
                             NULL,
                             NULL,
                             CHR(10)
                             || 'Phone:-')
                   || header_shipto_contact_phone,
                   NULL),
            decode(templ_sw_ship_from,
                   'No',
                   (nvl(templ_pl_ship_from, 'Ship From')
                    || CHR(10)
                    || line_shipfrom_address),
                   NULL),
            decode(templ_sw_ship_from,
                   'No',
                   (nvl(templ_pl_ship_from, 'Ship From')
                    || CHR(10)
                    || line_shipfrom_address),
                   NULL),
            decode(templ_sw_ship_from, 'No',(line_shipfrom_address), NULL),
            header_order_type,
            decode(templ_sw_invoice_from,
                   'No',
                   nvl(templ_pl_invoice_from, 'Invoice From')
                   || CHR(10)
                   || templ_invoice_from_address
                   || CHR(10)
                   || 'Phone : Fax :',
                   NULL),
            decode(templ_sw_final_dest,
                   'No',
                   nvl(templ_pl_final_dest, 'Final Destination ')
                   || CHR(10)
                   || nvl(templ_final_dest, header_end_cust_po_name)
                   || CHR(10)
                   || templ_final_dest_address,
                   NULL),
            templ_final_dest,
            decode(templ_sw_final_dest,
                   'No',
                   nvl(templ_pl_final_dest, 'Final Destination ')
                   || CHR(10)
                   || nvl(templ_final_dest, header_end_cust_po_name)
                   || CHR(10)
                   || templ_final_dest_address,
                   NULL),
            decode(templ_sw_currency,
                   'No',
                   nvl(templ_pl_currency, 'Amount')
                   || CHR(10)
                   || '('
                   || header_order_currency
                   || ')',
                   NULL),
            decode(templ_sw_currency,
                   'No',
                   nvl(templ_pl_currency, 'Amount')
                   || CHR(10)
                   || '('
                   || header_order_currency
                   || ')',
                   NULL),
            decode(templ_sw_hts_code,
                   'No',
                   nvl(templ_pl_hts_code, 'Ship from HTS'),
                   NULL),
            header_shipto_country,
            header_shipto_customer,
            decode(templ_sw_country_of_origin, 'Yes', 'Y', 'N'),
            templ_ship_from,
            line_shipping_method,
            line_actual_shipdate,
            header_shipto_account_siteuse_id,
            header_sold_to_party_id,
            header_billto_account_siteuse_id,
            header_shipto_account_siteuse_id,
            decode(templ_sw_freight_terms,
                   'No',
                   nvl(templ_pl_freight_terms, 'Freight Terms')
                   || CHR(10)
                   || line_freight_term_code,
                   NULL),
            decode(templ_sw_final_dest,
                   'No',
                   nvl(templ_final_dest, header_end_cust_po_name)
                   || CHR(10)
                   || templ_final_dest_address,
                   NULL),
            decode(templ_sw_mode_of_transportation,
                   'No',
                   nvl(templ_pl_mode_of_transportation, 'Mode of Transportation')
                   || CHR(10)
                   || templ_mode_of_transportation,
                   NULL),
            'Date of Issue:'
            || CHR(10)
            || creation_date,
            line_actual_shipdate,
            header_grand_total,
            (
                header_sub_total - nvl(header_service_amount, 0)
            ),
            nvl(header_service_amount, '0'),
            decode(templ_sw_country_of_provenance,
                   'No',
                   nvl(templ_pl_country_of_provenance, 'Country of Provenance ')
                   || ' '
                   || templ_country_of_provenance,
                   NULL),
            templ_pl_hs_code,
            templ_hs_code,
            header_attribute2,
            header_attribute3;

        CURSOR c_get_line_rec (
            cp_shippable_set       IN VARCHAR2,
            cp_header_order_number IN VARCHAR2
        ) IS
        SELECT DISTINCT
            line_item_quantity,
            line_item_number,
            line_custom_description                             cf_standard_desc,
            templ_std_desc                                      std_desc,
            line_country_of_origin,
            line_hts_code,
            line_eccn,
            line_license_number                                 line_license_number,
            line_unit_selling_price,
            line_line_amount,
            line_item_type_code                                 item_type_code,
            header_order_currency                               from_currency,
            templ_price_type                                    price_code_3b11,
            replace(templ_price_markup, '-', '')                price_discount_3b11,
            header_submit_date                                  booked_date,
            templ_currency                                      to_cal_currency,
            unit_price                                          unit_list_price,
            templ_zero_amt_item_sentence                        zero_amt_item_sentence,
            NULL                                                zero_amt_item_default,
            '3B18'                                              b2b_source,
            line_eccn                                           eccn,
            NULL                                                attribute1,
            NULL                                                attribute2,
            NULL                                                attribute3,
            NULL                                                attribute4,
            templ_func_temp_name                                attribute5,
            templ_pl_country_of_dest                            pl_country_of_dest,
            templ_pl_footer_text                                pl_footer_text,
            NULL                                                pl_attribute1,
            NULL                                                pl_attribute2,
            NULL                                                pl_attribute3,
            NULL                                                pl_attribute4,
            NULL                                                pl_attribute5,
            decode(templ_sw_country_of_dest, 'Yes', 'Y', 'N')   sw_country_of_dest,
            decode(templ_sw_footer_text, 'Yes', 'Y', 'N')       sw_footer_text,
            NULL                                                sw_attribute1,
            NULL                                                sw_attribute2,
            NULL                                                sw_attribute3,
            decode(templ_sw_country_of_origin, 'Yes', 'Y', 'N') sw_coo,
            decode(templ_sw_eccn, 'Yes', 'Y', 'N')              sw_eccn,
            decode(templ_sw_hts_code, 'Yes', 'Y', 'N')          sw_htts,
            NULL                                                sw_attribute4,
            NULL                                                sw_attribute5,
            decode(templ_enabled_flag, 'Yes', 'Y', 'N')         enabled_flag,
            templ_country_of_dest                               ci_country_of_dest,
            line_country_of_origin                              ci_coo,
            line_fob                                            ci_incoterm,
            NULL                                                ci_lic_logic,
            line_root_parent_fulfill_line_id                    top_model_line_id,
            line_pricing_date                                   pricing_date,
            line_price_list_id                                  price_list_id,
            line_display_line_number                            line_number1,
            header_header_id                                    hdr_id,
            line_line_id                                        line_id,
            line_line_number                                    line,
            line_fulfill_org_id                                 organization_id, -- Added as apart of CON0002775-719546
           -- decode(line_ship_from_warehouse, 'NMXGDL1R', '751', 'ASGSIN1R', '611',line_fulfill_org_id)                         organization_id, --line_fulfill_org_id      -- Commented as a apart of CON0002775-719546
            line_item_desc                                      description,
            line_license_number                                 lic,
            nvl(line_shipped_quantity, 0)                       ship_qty,
            line_inventory_item_id                              inventory_item_id,
            extended_price                                      extended_amount,
            line_shippable_flag                                 shippable_item_flag,
            unit_price                                          cp_unit_price,
            line_eccn                                           cf_eccn,
            line_item_desc                                      cf_description,
            1                                                   custom_cf_rec_cnt,
            NULL                                                cf_zero_amt_logic_3b11
        FROM
            napp_om_so_ci2_stg a
        WHERE
                a.line_shippable_set = cp_shippable_set
            AND a.header_order_number = cp_header_order_number
            AND a.ci_revision = (
                SELECT
                    MAX(b.ci_revision)
                FROM
                    napperp.napp_om_so_ci2_stg b
                WHERE
                        b.header_order_number = a.header_order_number
                    AND b.line_shippable_set = a.line_shippable_set  --1.0.1
            );

        v_header              napperp.napp_om_ci_xml_header_dtls_obj_type;
        v_line                napperp.napp_om_ci_xml_line_dtls_obj_type;
        v_line_table          napperp.napp_om_ci_xml_line_dtls_tab_type;
        v_line_count          NUMBER;
        lv_status             VARCHAR2(100);
        lv_status_msg         VARCHAR2(1000);
        lv_ci_ship_to_contact VARCHAR2(100);
        lv_ci_bill_to_contact VARCHAR2(100);
        lv_cf_hs_code         VARCHAR2(100);
    BEGIN
        p_result := napperp.napp_om_ci_xml_header_dtls_tab_type();
        FOR i IN c_get_header_rec(p_ship_from_warehouse, p_schedule_ship_date, p_ship_set, p_order_number) LOOP

        -- Added below code as apart of CON0002775-719546
            IF ( ( p_ship_from_warehouse = 'NMXGDL1R' ) OR ( p_ship_from_warehouse = 'ASGSIN1R' ) ) THEN
                lv_cf_hs_code := NULL;
            ELSE
                SELECT
                    decode(i.sw_hs_code,
                           'N',
                           nvl(i.pl_hs_code, 'Tariff Heading / HS Code')
                           || CHR(10)
                           || i.ci_hs_code,
                           NULL)
                INTO lv_cf_hs_code
                FROM
                    dual;

            END IF;
            -- Added above code as apart of CON0002775-719546

        -- Commented below code as apart of CON0002775-719546
           /* IF ( ( i.ship_from_org_id = '751' ) OR ( i.ship_from_org_id = '611' ) ) THEN
                lv_cf_hs_code := NULL;
            ELSE
                SELECT
                    decode(i.sw_hs_code,
                           'N',
                           nvl(i.pl_hs_code, 'Tariff Heading / HS Code')
                           || CHR(10)
                           || i.ci_hs_code,
                           NULL)
                INTO lv_cf_hs_code
                FROM
                    dual;

            END IF;*/
          -- Commented above code as apart of CON0002775-719546

            v_line_table := napperp.napp_om_ci_xml_line_dtls_tab_type();
            v_line_count := 0;
            FOR j IN c_get_line_rec(i.line_shippable_set, i.header_order_number) LOOP
                v_line := napperp.napp_om_ci_xml_line_dtls_obj_type(j.line_item_quantity, j.line_item_number, j.cf_description, j.cf_standard_desc
                , j.line_country_of_origin,
                                                                   j.line_hts_code, j.line_eccn, j.line_license_number,
														   --NULL,
                                                                    j.line_unit_selling_price, j.extended_amount,
                                                                   j.item_type_code, j.from_currency, j.price_code_3b11, j.price_discount_3b11
                                                                   ,
                                                           --NULL,
                                                                    j.booked_date,
                                                                   j.to_cal_currency, j.unit_list_price, j.zero_amt_item_sentence, j.zero_amt_item_default
                                                                   , j.b2b_source,
                                                                   j.eccn, j.attribute1, j.attribute2, j.attribute3, j.attribute4,
                                                                   j.attribute5, j.pl_country_of_dest, j.pl_footer_text, j.pl_attribute1
                                                                   , j.pl_attribute2,
                                                                   j.pl_attribute3, j.pl_attribute4, j.pl_attribute5, j.sw_country_of_dest
                                                                   , j.sw_footer_text,
                                                                   j.sw_attribute1, j.sw_attribute2, j.sw_attribute3, j.sw_coo, j.sw_eccn
                                                                   ,
                                                                   j.sw_htts, j.sw_attribute4, j.sw_attribute5, j.enabled_flag, j.ci_country_of_dest
                                                                   ,
                                                                   j.ci_coo, j.ci_incoterm, j.ci_lic_logic, NULL, -- j.top_model_line_id,
                                                                    j.pricing_date,
                                                           --NULL,
                                                                   j.price_list_id, j.line_number1, j.hdr_id, j.line_id, j.line,
                                                                   j.organization_id, j.description, to_char(j.lic), j.ship_qty, j.inventory_item_id
                                                                   ,
                                                                   j.extended_amount, j.shippable_item_flag, j.cp_unit_price, j.cf_eccn
                                                                   , j.cf_description,
                                                                   j.custom_cf_rec_cnt, j.cf_zero_amt_logic_3b11);

                v_line_table.extend;
                v_line_table(v_line_table.last) := v_line;
                v_line_count := v_line_count + 1;
            END LOOP;

            v_header := napperp.napp_om_ci_xml_header_dtls_obj_type(i.templ_document_header, sysdate, i.templ_pl_invoice_from, i.cp_invoice_from
            , i.cf_date_of_issue,
                                                                   'Sales Order No.:' || i.header_order_number, i.templ_document_number_label
                                                                   , 'Customer Invoice No.:' || i.customs_invoice_num, 'Customer PO No.:'
                                                                   || i.header_customer_po_num, i.line_shippable_set,
                                                                   i.cf_act_ship_date,--i.line_scheduled_ship_date,
                                                                    i.templ_pl_payment_terms, i.line_payment_terms, --i.templ_pl_freight_terms,
                                                                    i.line_freight_term_code, i.templ_pl_ult_consignee_type,
                                                                   i.templ_ult_consignee_type, i.templ_pl_ship_from, i.custom_cp_ship_from_address2
                                                                   , i.templ_pl_ship_to, i.custom_cp_ship_to_address2,
                                                                   i.templ_pl_bill_to, i.custom_cp_bill_to_address2, nvl(i.templ_pl_final_dest
                                                                   , 'Final Destination'), i.custom_cp_final_des2, i.templ_pl_incoterm
                                                                   , i.line_fob, i.templ_pl_carrier,
                                                                   i.cf_mode_of_operation, --, i.templ_pl_mode_of_transportation, i.templ_mode_of_transportation, i.templ_pl_country_of_provenance
                                                                    i.cf_country_pro,  --, NULL,
                                                                    i.templ_pl_country_of_dest, i.templ_country_of_dest,   --- Check once
                                                                    i.templ_pl_country_of_origin,
                                                                   i.templ_pl_eccn, i.templ_pl_hts_code, i.cp_currency1, i.header_grand_total
                                                                   , i.templ_signature_text,
                                                                   i.templ_footer_text   --, i.templ_std_desc
                                                                   , v_line_table, v_line_count, i.actual_shipment_date, i.order_number
                                                                   ,
                                                                   i.requested_date, i.header_id, i.shipping_method_code, -- NULL,
                                                                    i.vat, i.ship_to_org_id, --NULL,
                                                                   i.customs_invoice_num, p_ci_sent_to_email, p_ci_sent_from_email, i.ship_to_contact
                                                                   , i.ship_from_org_id,
                                                                   i.bill_to_contact, i.header_customer_po_num, -- NULL,
                                                                    i.pl_final_dest, i.header_sold_to_party_id, -- NULL,
                                                                    i.pl_ship_from,
                                                                   i.templ_pl_ship_to, --i.pl_ship_to_loc_id,
                                                                    i.pl_mode_of_transportation, i.templ_pl_country_of_dest, i.sw_mode_of_transportation
                                                                   , i.mode_of_transportation,
                                                                   i.pl_ship_to_contact, i.pl_bill_to_contact, i.templ_pl_hts_code, i.templ_pl_country_of_origin
                                                                   , i.pl_eccn,
                                                                   i.templ_pl_bill_to, --i.pl_bill_to_loc_id,
                                                                    i.sw_invoice_from, i.sw_ship_from, i.sw_currency, i.sw_final_dest
                                                                   ,
                                                                   i.sw_coo1, i.sw_eccn1, i.sw_hs_code, i.sw_ship_to_loc_id, i.sw_ship_to_contact
                                                                   ,
                                                                   i.templ_pl_country_of_provenance, i.bill_to_country, i.sw_bill_to_loc_id
                                                                   , i.sw_bill_to_contact, i.pl_signature_text,
                                                                   'NAPP_CI_OPTIO_TEMPLATE_03', i.signature_text, i.sw_signature_text
                                                                   , i.pl_currency, i.sold_to,
                                                                   i.ci_invoice_from, i.ci_currency, NULL, -- i.ci_final_dest, -- To be shared by Rajesh
                                                                    i.header_billto_account_siteuse_id, -- NULL, --  i.ci_bill_to_loc_id,
                                                                    i.payment_terms,
                                                                   i.sw_payment_terms, i.header_ci_bill_to_contact, i.carrier, i.sw_carrier
                                                                   , i.pl_carrier,
                                                                   i.header_ci_ship_to_contact, i.header_shipto_account_siteuse_id,-- NULL,
                                                                    i.sw_hs_code, i.pl_freight_terms, i.sw_freight_terms,
                                                                   i.sw_incoterm, i.pl_hs_code, i.ci_hs_code, --i.ci_hts_code,
                                                                    i.ci_ship_from, i.sw_country_of_provenance,
                                                                   i.ci_func_temp_name, i.ci_country_of_provenance, i.fob, i.sw_uct, i.cp_bill_to_address
                                                                   ,
                                                                   '1', i.cf_bill_to_address, '1', i.cf_ship_to_address, i.cf_ship_to_address
                                                                   ,
                                                                   '1', i.cf_ship_from_address, i.cp_ship_from_address, i.cf_frieght_carriers
                                                                   , i.cf_order_type,
                                                                   i.cf_invoice_from, i.cf_final_des, '1',--, i.custom_cf_final_des,
                                                                    i.cp_final_des, i.cf_currency,
                                                                   lv_cf_hs_code, i.cf_country_code, p_cf_single_multiple, p_cf_sent_emails
                                                                   , p_cf_instance,
                                                                   NULL, NULL, to_char(v_line_count),  -- ask jyothi about line count
                                                                    NULL, i.cf_serviceline_amt,
                                                                   NULL, i.cf_customer_ship_to, i.cf_serviceline_amt, i.cf_ord_total,
                                                                   i.cs_ext_amount,
                                                                   NULL, NULL, i.line_freight_term_code);

            p_result.extend;
            p_result(p_result.last) := v_header;
        END LOOP;

        COMMIT;
        p_status := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            lv_status := 'ERROR';
            lv_status_msg := 'Exception while fetching data from staging table'
                             || sqlcode
                             || ' - '
                             || substr(sqlerrm, 1, 1000);

            COMMIT;
            p_status := lv_status;
            p_status_msg := lv_status_msg;
    END napp_om_generate_ci_xml_data_proc;

END napp_om_generate_ci_xml_dc_pkg;
/