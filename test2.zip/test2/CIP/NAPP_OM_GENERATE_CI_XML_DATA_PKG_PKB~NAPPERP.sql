create or replace PACKAGE BODY                 napp_om_generate_ci_xml_data_pkg 
/*******************************************************************************************************************/
/* File Name       : napp_om_generate_ci_xml_data_pkg.pks                                                                   */
/* Object Name      :napp_om_generate_ci_xml_data_pkg                                                                          */
/* Description     : Generate CI PDF data on Adhoc basis                                       */
/*******************************************************************************************************************/
/* Revision History:                                                                                               */
/*  Ver  Date           Modified By       Revision Description                                                     */
/*  ===  ===========    ============      ====================                                                     */
/* 1.0  11-Feb-2025   Jyothi  Korangi       C2C-NEW-EXT-036      */
/* 1.0.1      12-Dec-2025  Korangi Jyothi yasasvi     Incident# INC4391401*/
/* 1.0.2      06-Jan-2026  Korangi Jyothi yasasvi     Incident# INC4416949*/
/* 1.0.3      05-Feb-2026  Korangi Jyothi yasasvi     Incident# INC4448097*/
/* 1.0.4      05-Mar-2026  Korangi Jyothi yasasvi     ADO#911324*/
/*******************************************************************************************************************/
AS

    PROCEDURE napp_om_generate_ci_xml_data_proc (
        p_ship_from_warehouse IN VARCHAR2,
        p_schedule_ship_date  IN VARCHAR2,
        p_ship_set            IN VARCHAR2,
        p_order_number        IN VARCHAR2,
        p_result              OUT napp_om_ci_header_details_tab_type,
        p_status              OUT VARCHAR2,
        p_status_msg          OUT VARCHAR2
    ) IS

        CURSOR c_get_header_rec (
            cp_ship_from_warehouse IN VARCHAR2,
            cp_schedule_ship_date  IN VARCHAR2,
            cp_ship_set            IN VARCHAR2,
            cp_order_number        IN VARCHAR2
        ) IS
        SELECT
            templ_document_header,
            creation_date,
            decode(templ_sw_invoice_from, 'No', templ_pl_invoice_from, NULL)                     templ_pl_invoice_from,
                   -- decode(templ_sw_invoice_from, 'No', templ_invoice_from, NULL)                        templ_invoice_from,
            decode(templ_sw_invoice_from,
                   'No', templ_invoice_from_address,
                   NULL)                                                                         templ_invoice_from_address,
            header_order_number,
            templ_document_number_label,
            ci_number,
            header_customer_po_num,
            line_shippable_set,
            line_scheduled_ship_date,
            decode(templ_sw_payment_terms, 'No', templ_pl_payment_terms, NULL)                   templ_pl_payment_terms,
            decode(templ_sw_payment_terms, 'No', line_payment_terms, NULL)                       line_payment_terms,
            decode(templ_sw_freight_terms, 'No', templ_pl_freight_terms, NULL)                   templ_pl_freight_terms,
            decode(templ_sw_freight_terms, 'No', line_freight_term_code, NULL)                   line_freight_term_code,
            decode(templ_sw_ult_consignee_type, 'No', templ_pl_ult_consignee_type, NULL)         templ_pl_ult_consignee_type,
            decode(templ_sw_ult_consignee_type, 'No', templ_ult_consignee_type, NULL)            templ_ult_consignee_type,
            decode(templ_sw_ship_from, 'No', templ_pl_ship_from, NULL)                           templ_pl_ship_from,
            decode(templ_sw_ship_from,
                   'No',  line_shipfrom_address,
                   NULL)                                                                         custom_cp_ship_from_address2,
            decode(templ_sw_ship_to, 'No', templ_pl_ship_to, NULL)                               templ_pl_ship_to,
            decode(templ_sw_ship_to,
                   'No',
                   header_shipto_customer
                   || CHR(10)
                   || header_shipto_address                   
                   || decode(TEMPL_SW_SHIP_TO_CONTACT,'No',decode(header_shipto_contact_name,NULL,NULL, CHR(10) || TEMPL_PL_SHIP_TO_CONTACT)
                   ||' '
                   || header_shipto_contact_name
                   || decode(header_shipto_contact_phone,NULL,NULL, CHR(10) || 'Phone:-')
                   || header_shipto_contact_phone,NULL),
                   NULL)                                                                         custom_cp_ship_to_address2,
            decode(templ_sw_bill_to, 'No', templ_pl_bill_to, NULL)                               templ_pl_bill_to,
            decode(templ_sw_bill_to,
                   'No',
                   header_billto_customer
                   || CHR(10)
                   || header_billto_address
                   || decode(TEMPL_SW_BILL_TO_CONTACT,'No',
                   decode(header_billto_contact,NULL,NULL, CHR(10) || templ_pl_bill_to_contact)
                   ||' '
                   || header_billto_contact,NULL),
                   NULL)                                                                         custom_cp_bill_to_address2,
            decode(templ_sw_final_dest, 'No', templ_pl_final_dest, NULL)                         templ_pl_final_dest,
            decode(templ_sw_final_dest,
                   'No',
                   header_end_cust_po_name
                   || CHR(10)
                   || templ_final_dest_address,
                   NULL)                                                                         templ_final_dest,
            decode(templ_sw_incoterm, 'No', templ_pl_incoterm, NULL)                             templ_pl_incoterm,
            decode(templ_sw_incoterm, 'No', line_fob, NULL)                                      line_fob,
            decode(templ_sw_carrier, 'No', templ_pl_carrier, NULL)                               templ_pl_carrier,
            decode(templ_sw_carrier, 'No', templ_carrier, NULL)                                  templ_carrier,
            decode(templ_sw_mode_of_transportation, 'No', templ_pl_mode_of_transportation, NULL) templ_pl_mode_of_transportation,
            decode(templ_sw_mode_of_transportation, 'No', templ_mode_of_transportation, NULL)    templ_mode_of_transportation,
            decode(templ_sw_country_of_provenance, 'No', templ_pl_country_of_provenance, NULL)   templ_pl_country_of_provenance,
            decode(templ_sw_country_of_provenance, 'No', templ_country_of_provenance, NULL)      templ_country_of_provenance,
            decode(templ_sw_country_of_dest, 'No', templ_pl_country_of_dest, NULL)               templ_pl_country_of_dest,
            decode(templ_sw_country_of_dest, 'No', templ_country_of_dest, NULL)                  templ_country_of_dest,
            decode(templ_sw_country_of_origin, 'No', templ_pl_country_of_origin, NULL)           templ_pl_country_of_origin,
            decode(templ_sw_currency, 'No', templ_pl_currency, NULL)                             templ_pl_currency,
            decode(templ_sw_eccn, 'No', templ_pl_eccn, NULL)                                     templ_pl_eccn,
            decode(TEMPL_SW_HTS_CODE, 'No', templ_pl_hts_code, NULL)                              templ_pl_hts_code,
            decode(templ_sw_signature_text, 'No', templ_signature_text, NULL)                    templ_signature_text,
            decode(templ_sw_footer_text, 'No', templ_footer_text, NULL)                          templ_footer_text,
            line_custom_description,
            header_service_amount,
            templ_print_hts_desc,
            header_sub_total,
            header_grand_total,
            header_order_currency,
            ci_revision
-- TRUNC(line_scheduled_ship_date)
        FROM
            napperp.napp_om_so_ci2_stg stg
        WHERE
                line_ship_from_warehouse = cp_ship_from_warehouse
   -- AND TRUNC(line_scheduled_ship_date) = TO_DATE(:line_scheduled_ship_date,'DD-MON-YY')
            AND line_scheduled_ship_date = to_char(TO_DATE(cp_schedule_ship_date, 'YYYY-MM-DD'),
                                                   'DD-MON-YY')
            AND ( ( cp_ship_set IS NULL
                    AND 1 = 1 )
                  OR ( cp_ship_set IS NOT NULL
                       AND line_shippable_set = cp_ship_set ) )
            AND ( ( cp_order_number IS NULL
                    AND 1 = 1 )
                  OR ( cp_order_number IS NOT NULL
                       AND header_order_number = cp_order_number ) )
    AND ci_revision = (
        SELECT
            MAX(b.ci_revision)
        FROM
            napperp.napp_om_so_ci2_stg b
        WHERE
            b.header_order_number = stg.header_order_number
            and b.line_shippable_set=stg.line_shippable_set  --1.0.4
    )
--	   AND ( SELECT COUNT(*) CNT
--              FROM
--             napp_om_3b18_sales_order_details_075_retrofit_stg parent
--             WHERE
--               parent.header_header_id = stg.header_header_id
--           AND parent.line_line_id = stg.line_line_id AND parent.order_revision_no = stg.ci_revision and parent.line_cancelled_status is null) > 0
--    AND (
--        SELECT DISTINCT
--            gtm_screening_1_status
--        FROM
--            napp_om_3b18_sales_order_details_075_retrofit_stg parent
--        WHERE
--                parent.header_header_id = stg.header_header_id
--            AND parent.line_line_id = stg.line_line_id
--            AND parent.order_revision_no = stg.ci_revision
--    ) = 'Y'
and ROWNUM=1
        GROUP BY
            templ_document_header,
            creation_date,
            decode(templ_sw_invoice_from, 'No', templ_pl_invoice_from, NULL),
                --    decode(templ_sw_invoice_from, 'No', templ_invoice_from, NULL),
            decode(templ_sw_invoice_from,
                   'No', templ_invoice_from_address,
                   NULL),
            header_order_number,
            templ_document_number_label,
            ci_number,
            header_customer_po_num,
            line_shippable_set,
            line_scheduled_ship_date,
            decode(templ_sw_payment_terms, 'No', templ_pl_payment_terms, NULL),
            decode(templ_sw_payment_terms, 'No', line_payment_terms, NULL),
            decode(templ_sw_freight_terms, 'No', templ_pl_freight_terms, NULL),
            decode(templ_sw_freight_terms, 'No', line_freight_term_code, NULL),
            decode(templ_sw_ult_consignee_type, 'No', templ_pl_ult_consignee_type, NULL),
            decode(templ_sw_ult_consignee_type, 'No', templ_ult_consignee_type, NULL),
            decode(templ_sw_ship_from, 'No', templ_pl_ship_from, NULL),
            decode(templ_sw_ship_from,
                   'No',  line_shipfrom_address,
                   NULL),
            decode(templ_sw_ship_to, 'No', templ_pl_ship_to, NULL),
            decode(templ_sw_ship_to,
                   'No',
                   header_shipto_customer
                   || CHR(10)
                   || header_shipto_address                   
                   || decode(TEMPL_SW_SHIP_TO_CONTACT,'No',decode(header_shipto_contact_name,NULL,NULL, CHR(10) || TEMPL_PL_SHIP_TO_CONTACT)
                   ||' '
                   || header_shipto_contact_name
                   || decode(header_shipto_contact_phone,NULL,NULL, CHR(10) || 'Phone:-')
                   || header_shipto_contact_phone,NULL),
                   NULL)                                ,
            decode(templ_sw_bill_to, 'No', templ_pl_bill_to, NULL),
            decode(templ_sw_bill_to,
                   'No',
                   header_billto_customer
                   || CHR(10)
                   || header_billto_address
                   || decode(TEMPL_SW_BILL_TO_CONTACT,'No',
                   decode(header_billto_contact,NULL,NULL, CHR(10) || templ_pl_bill_to_contact)
                   ||' '
                   || header_billto_contact,NULL),
                   NULL) ,
            decode(templ_sw_final_dest, 'No', templ_pl_final_dest, NULL),
            decode(templ_sw_final_dest,
                   'No',
                   header_end_cust_po_name
                   || CHR(10)
                   || templ_final_dest_address,
                   NULL),
            decode(templ_sw_incoterm, 'No', templ_pl_incoterm, NULL),
            decode(templ_sw_incoterm, 'No', line_fob, NULL),
            decode(templ_sw_carrier, 'No', templ_pl_carrier, NULL),
            decode(templ_sw_carrier, 'No', templ_carrier, NULL),
            decode(templ_sw_mode_of_transportation, 'No', templ_pl_mode_of_transportation, NULL),
            decode(templ_sw_mode_of_transportation, 'No', templ_mode_of_transportation, NULL),
            decode(templ_sw_country_of_provenance, 'No', templ_pl_country_of_provenance, NULL),
            decode(templ_sw_country_of_provenance, 'No', templ_country_of_provenance, NULL),
            decode(templ_sw_country_of_dest, 'No', templ_pl_country_of_dest, NULL),
            decode(templ_sw_country_of_origin, 'No', templ_pl_country_of_origin, NULL),
            decode(templ_sw_currency, 'No', templ_pl_currency, NULL),
            decode(templ_sw_eccn, 'No', templ_pl_eccn, NULL),
            decode(TEMPL_SW_HTS_CODE, 'No', templ_pl_hts_code, NULL),
            decode(templ_sw_country_of_dest, 'No', templ_country_of_dest, NULL),
            decode(templ_sw_signature_text, 'No', templ_signature_text, NULL),
            decode(templ_sw_footer_text, 'No', templ_footer_text, NULL),
            line_custom_description,
            header_service_amount,
            templ_print_hts_desc,
            header_sub_total,
            header_grand_total,
            header_order_currency,
            ci_revision
        ORDER BY
            ci_revision DESC;

        CURSOR c_get_line_rec (
            cp_shippable_set       IN VARCHAR2,
            cp_header_order_number IN VARCHAR2,
            cp_revision_number     IN NUMBER
        ) IS
        SELECT
            line_item_quantity,
            line_item_number,
            line_item_desc,
            line_custom_description std_desc,
            line_country_of_origin,
            decode(TEMPL_SW_HTS_CODE, 'No', line_hts_code, NULL)line_hts_code,
           decode(templ_sw_eccn, 'No', line_eccn, NULL) line_eccn,
            line_license_number line_license_number,
            unit_price,
            extended_price
        FROM
            napperp.napp_om_so_ci2_stg
        WHERE
                line_shippable_set = cp_shippable_set
            AND header_order_number = cp_header_order_number
            AND ( ( cp_revision_number IS NULL
                    AND 1 = 1 )
                  OR ( cp_revision_number IS NOT NULL
                       AND ci_revision = cp_revision_number ) );
          --  AND ci_revision = cp_revision_number;

        v_header      napp_om_ci_header_details_obj_type;
        v_line        napp_om_ci_line_details_obj_type;
        v_line_table  napp_om_ci_line_details_tab_type;
        v_line_count  NUMBER;
        lv_status     VARCHAR2(100);
        lv_status_msg VARCHAR2(1000);
    BEGIN
        p_result := napp_om_ci_header_details_tab_type();
        FOR i IN c_get_header_rec(p_ship_from_warehouse, p_schedule_ship_date, p_ship_set, p_order_number) LOOP
            v_line_table := napp_om_ci_line_details_tab_type();
            v_line_count := 0;
            FOR j IN c_get_line_rec(i.line_shippable_set, i.header_order_number, i.ci_revision) LOOP
                v_line := napp_om_ci_line_details_obj_type(j.line_item_quantity, j.line_item_number, j.line_item_desc, j.std_desc, j.line_country_of_origin
                ,
                                                          j.line_hts_code, j.line_eccn, j.line_license_number, j.unit_price, j.extended_price
                                                          );

                v_line_table.extend;
                v_line_table(v_line_table.last) := v_line;
                v_line_count := v_line_count + 1;
            END LOOP;

            v_header := napp_om_ci_header_details_obj_type(i.templ_document_header, sysdate, i.templ_pl_invoice_from, i.templ_invoice_from_address
            , i.templ_invoice_from_address,
                                                          i.creation_date, i.header_order_number, i.templ_document_number_label, i.ci_number
                                                          , 'Customer PO No.',
                                                          i.header_customer_po_num, i.line_shippable_set, i.line_scheduled_ship_date,
                                                          i.templ_pl_payment_terms, i.line_payment_terms,
                                                          i.templ_pl_freight_terms, i.line_freight_term_code, i.templ_pl_ult_consignee_type
                                                          , i.templ_ult_consignee_type,  i.templ_pl_ship_from,
                                                          i.custom_cp_ship_from_address2, i.templ_pl_ship_to, i.custom_cp_ship_to_address2
                                                          , i.templ_pl_bill_to, i.custom_cp_bill_to_address2,
                                                          i.templ_pl_final_dest, i.templ_final_dest, i.templ_pl_incoterm, i.line_fob,
                                                          i.templ_pl_carrier,
                                                          i.templ_carrier, i.templ_pl_mode_of_transportation, i.templ_mode_of_transportation
                                                          , i.templ_pl_country_of_provenance, i.templ_country_of_provenance,
                                                          i.templ_pl_country_of_dest, i.templ_country_of_dest, i.templ_pl_country_of_origin
                                                          , i.templ_pl_eccn, i.templ_pl_hts_code,
                                                          i.header_order_currency, i.header_sub_total, i.header_grand_total, i.templ_signature_text
                                                          , i.templ_footer_text,
                                                          i.line_custom_description, nvl(i.header_service_amount, 0), i.templ_print_hts_desc
                                                          , v_line_table, v_line_count);

            p_result.extend;
            p_result(p_result.last) := v_header;
        END LOOP;

        IF p_result.count = 0 THEN
            lv_status := 'ERROR';
            lv_status_msg := 'No Data found for given input values';
            p_status := lv_status;
            p_status_msg := lv_status_msg;
            RETURN;
        END IF;

        p_status := 'SUCCESS';
    EXCEPTION
        WHEN OTHERS THEN
            lv_status := 'ERROR';
            lv_status_msg := 'Exception while fetching data from staging table'
                             || sqlcode
                             || ' - '
                             || substr(sqlerrm, 1, 1000);

            p_status := lv_status;
            p_status_msg := lv_status_msg;
    END napp_om_generate_ci_xml_data_proc;

-- INC4391401 Start
      PROCEDURE napp_om_ci_validation_proc (
        p_ship_from_warehouse IN VARCHAR2,
        p_schedule_ship_date  IN VARCHAR2,
        p_ship_set            IN VARCHAR2,
        p_order_number        IN VARCHAR2,
        p_status              OUT VARCHAR2,
        p_message             OUT VARCHAR2
    ) IS
        v_rec_count                 NUMBER;
        v_non_cancelled_lines_count NUMBER;
        v_gtm_flag                  VARCHAR2(2);
    BEGIN
   -- Initialize the status and message as success by default
        p_status := 'SUCCESS';
        p_message := 'Validation passed successfully';
   -- Query 1 ->Check If data exists in STG2 table     
        SELECT
            COUNT(1)
        INTO v_rec_count
        FROM
            napperp.napp_om_so_ci2_stg stg
        WHERE
                line_ship_from_warehouse = p_ship_from_warehouse
            AND line_scheduled_ship_date = to_char(TO_DATE(p_schedule_ship_date, 'YYYY-MM-DD'),
                                                   'DD-MON-YY')
            AND ( ( p_ship_set IS NULL
                    AND 1 = 1 )
                  OR ( p_ship_set IS NOT NULL
                       AND line_shippable_set = p_ship_set ) )
            AND ( ( p_order_number IS NULL
                    AND 1 = 1 )
                  OR ( p_order_number IS NOT NULL
                       AND header_order_number = p_order_number ) );

        IF v_rec_count = 0 THEN
            p_status := 'ERROR';
            p_message := 'No Data found for given input values';
            RETURN;
        END IF;
     -- Query 2 ->Check Cancelled Lines count
        SELECT
            COUNT(1)
        INTO v_non_cancelled_lines_count
        FROM
            napp_om_3b18_sales_order_details_075_retrofit_stg parent
        WHERE
                         ( ( p_order_number IS NULL
                    AND 1 = 1 )
                  OR ( p_order_number IS NOT NULL
                       AND parent.header_order_number  = p_order_number ) )
            AND parent.line_cancelled_status IS NULL
            AND order_revision_no = (
                SELECT
                    MAX(parent1.order_revision_no)
                FROM
                    napperp.napp_om_3b18_sales_order_details_075_retrofit_stg parent1
                WHERE
                    parent1.header_order_number = parent.header_order_number
					and parent1.header_ship_set_num = parent.header_ship_set_num
            )
            AND substr(parent.line_promise_date, 1, 10) = p_schedule_ship_date;

--"Lines are Cancelled , CI XML/PDF will not be generated"(if cnt=0)

        IF v_non_cancelled_lines_count = 0 THEN
            p_status := 'ERROR';
            p_message := 'Lines are Cancelled , CI XML/PDF will not be generated';
            RETURN;
        END IF;
 -- Query 3 ->Check GTM Status
        SELECT 
            max(parent.gtm_screening_1_status)  --1.0.3
         --  max(parent.gtm_screening_2_status)  --1.0.3
        INTO v_gtm_flag
        FROM
            napp_om_3b18_sales_order_details_075_retrofit_stg parent,
            napp_om_so_ci2_stg                                stg
        WHERE
                parent.header_header_id = stg.header_header_id
            AND parent.line_line_id = stg.line_line_id
            AND parent.order_revision_no = stg.ci_revision
            AND ( ( p_order_number IS NULL
                    AND 1 = 1 )
                  OR ( p_order_number IS NOT NULL
                      AND stg.header_order_number  = p_order_number ) )

            AND parent.header_ship_set_num IS NOT NULL
            AND ( ( upper(parent.status) NOT IN ( 'ABORT' )   --1.0.3
                    AND parent.gtm_screening_1_status = 'Y'
                   -- AND parent.gtm_screening_2_status = 'Y'    --1.0.3
                    )
                  OR NOT EXISTS (
                SELECT
                    1
                FROM
                    napp_om_3b18_sales_order_details_075_retrofit_stg t2
                WHERE
                        parent.header_header_id = t2.header_header_id
                    AND parent.header_ship_set_num = t2.header_ship_set_num
                    AND parent.oic_instance_id = t2.oic_instance_id
                    AND t2.send_in_gtm_flag = 'Y'
            ) )
            AND parent.order_revision_no = (
                SELECT
                    MAX(parent1.order_revision_no)
                FROM
                    napperp.napp_om_3b18_sales_order_details_075_retrofit_stg parent1
                WHERE
                        parent1.header_order_number = parent.header_order_number
                    AND parent1.status NOT IN ( 'ABORT' )   --1.0.3
            );

       IF v_gtm_flag IS NOT NULL THEN --INC4416949 CODE CHANGE
            p_status := 'SUCCESS';
            p_message := 'Validation passed successfully';
        ELSE
            p_status := 'ERROR';
            p_message := 'GTM Screening Pending CI will not be generated';
            RETURN;
        END IF;

    EXCEPTION
        WHEN OTHERS THEN
            p_status := 'ERROR';
            p_message := 'Unexpected Error'
                         || sqlcode
                         || ' - '
                         || substr(sqlerrm, 1, 1000);

    END napp_om_ci_validation_proc;
-- INC4391401 End
END napp_om_generate_ci_xml_data_pkg;
/